%% script: Test reduction based on voltage sensitivity.
%

%% Setup parameters
para.Method       = 'vSensitivity';
para.Model        = [pwd '\' 'Feeder_8.dss'];
para.TargetFolder = [pwd '\' 'ReducedModel'];
para.KeepBuses    = {'B80000p','B80010P','B80060P'};

%% Reduction process 
r = sg_DispatchReduction(para);