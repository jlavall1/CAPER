%% genFigures: Feeder 1
%
% Loads results and plots selected analysis/results.
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% August 31, 2014

%%  Load results and PV profile data
fnResults = 'Results';
Fprofile  = 'Feeder_1_Profile.xlsx';

r = load(fnResults); r = r.r;
[Tprof,nvTprof] = sg_loadTable(Fprofile,'returnType','cell');

%% Settings
% for figures
FONTSIZE = 16;
LWD = 2;
MARKERSIZE = 14;
%  time vector
t = r.t/3600;
timelab = 'Time (hours)';

%% Post-processing and plotting
qv   = [1 .95 .5 .05 0];
Mq   = quantile(r.Bus.Vpu.val',qv)';
PVidx  = sg_rgrep('Generator',nvTprof);
Ppv  = sum(Tprof(:,PVidx),2);
Stot = abs(sum(r.Load.S1.val+r.Load.S2.val+r.Load.S3.val,2));
Snet = Stot-Ppv;

%  Illustrate the bus voltages: quantiles of magnitues
legText = sg_stringjoin(qv,'del',';','fs','%0.2f');
sg_plotStandard(t,Mq,'fontsize',FONTSIZE,'xlab',timelab,'ylab','Voltage (pu)',...
    'title','Quantiles for Bus Voltages','lwd',LWD,'legendText',legText);

%  Generate a figure illustrating the PV power and bus voltages.
colv = 'kx;bx;rx;mx;gx';
sg_plotStandard(Ppv',Mq,'fontsize',FONTSIZE,'xlab','PV Power (kW)','ylab','Voltage (pu)',...
    'title','Quantiles for Bus Voltages','markerSize',MARKERSIZE,'legendText',legText,...
    'colorv',colv);

%  Generate a figure illustrating the bus voltages vs. the total load.
colv = 'kx;bx;rx;mx;gx';
sg_plotStandard(Stot,Mq,'fontsize',FONTSIZE,'xlab','Total Load Power (kW)','ylab','Voltage (pu)',...
    'title','Quantiles for Bus Voltages','markerSize',MARKERSIZE,'legendText',legText,...
    'colorv',colv);

%  Generate a figure illustrating the PV power and total load vs. time.
legText = 'PV;Load';
sg_plotStandard(t,{Ppv,Stot},'fontsize',FONTSIZE,'xlab',timelab,'ylab','Power (kW)',...
    'title','PV Power and Load','lwd',LWD,'legendText',legText);

%  Generate a figure illustrating the PV power and the net load.
colv = 'kx;bx;rx;mx;gx';
legText = sg_stringjoin(qv,'del',';','fs','%0.2f');
sg_plotStandard(abs(Snet),Mq,'fontsize',FONTSIZE,'xlab','Net Load Power (kW)','ylab','Voltage (pu)',...
    'title','Quantiles for Bus Voltages','markerSize',MARKERSIZE,'legendText',legText,...
    'colorv',colv);