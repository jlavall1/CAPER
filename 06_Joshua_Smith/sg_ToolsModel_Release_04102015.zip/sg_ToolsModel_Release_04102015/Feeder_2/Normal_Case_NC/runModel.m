%% runModel: Feeder 2
%
% Excute model: solves power flow for data available in feeder profile.
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% August 31, 2014

%% Feeder case setup
% Data/result files
y.Feeder.model     = [pwd '\Feeder_2_NC.dss'];
y.Feeder.profile   = [pwd '\Feeder_2_NC_Profile.xlsx'];
y.Feeder.fnResults = 'Results_NC';
% Configure results to be saved
y.Feeder.resultExt = @(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N,'RegControlExpr','None','CapacitorExpr','None'); 
y.Feeder.resultExt = @(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N); % keep data for post-processing

%% Open and configure OpenDSS connection
try
    DSSObj = sg_startOpenDSS;
catch
    % in case helper functions are not on the path yet
    startup;
    DSSObj = sg_startOpenDSS;
end

%% Execute model
tic;
% [r,DSSObj,time] = sg_runOpenDSSSim(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,'resultExt',y.Feeder.resultExt);
[r,DSSObj,time] = sg_runOpenDSSSim(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,'resultExt',y.Feeder.resultExt,'profilePoints',0);
if r.status
    r.Tel = toc;
    r.t   = time;
    r.Feeder = y.Feeder;
else
    fprintf(' No power flow results computed by OpenDSS.\n');
    return
end

%return % while testing

%% Save results
if ~isempty(dir([r.Feeder.fnResults '.mat']))
    r.Feeder.fnResults = [r.Feeder.fnResults '_' datestr(now,'yyyymmddTHHMMSS')];
end
save(r.Feeder.fnResults,'r');

%% Show selected results
sg_plotMaxMinVoltageProfile(r); % extreme voltage profiles experienced
sg_plotFeeder(r);               % feeder structure and status (at first point in time)