%% Startup script
%
% Add supporting functions to path.
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% August 31, 2014

% Add as absolute path after removing last subfolder of current location
cwd = pwd;
fsc = filesep;
addpath([cwd fsc 'Functions']);
addpath([cwd fsc 'Functions' fsc 'helpers_m']);
addpath([cwd fsc 'Functions' fsc 'ImpactAssessment']);
addpath([cwd fsc 'Functions' fsc 'Controls']);
addpath([cwd fsc 'Functions' fsc 'sg_Reduction']);