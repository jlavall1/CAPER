%% runReduction: Setup for model reduction. This script is based on Feeder 6.
%
% Feeder reduction (setup) example. Can be reused for other feeders be
% editing base file and folder information. 
%
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% January 26, 2015

clc
% clear/reset global vars
clear global INFO_LOAD INFO_GEN INFO_LINE INFO_TR INFO_LOADRATIO

%% Feeder case setup
% Data/result files
y.Feeder.model     = [pwd '\Feeder_6s_CC.dss']; % symmetric Feeder 6, constant current loads

y.Feeder.profile   = [];
y.Feeder.fnResults = '';
y.Feeder.resultExt = @(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N);

%% Open and configure OpenDSS connection
try
    DSSObj = sg_startOpenDSS;
catch
    % in case helper functions are not on the path yet
    startup;
    DSSObj = sg_startOpenDSS;
end

%% Setup model
tic;
[r,DSSObj] = sg_FeederReductionSetup(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,'resultExt',y.Feeder.resultExt,'profilePoints',1);
if r.status
    r.Tel = toc;
    r.Feeder = y.Feeder;
else
    fprintf(' No power flow results computed by OpenDSS.\n');
    return
end