%% runModel: Feeder 6 example using profile data 
%
% Excutes model abd extracts selected data point for comparison to reduced model.
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% February, 2015

%% Feeder case setup
% Data/result files
y.Feeder.model     = [pwd '\Feeder_6s_CC.dss'];
y.Feeder.profile   = [pwd '\Feeder_6_Profile_02.csv'];
y.Feeder.fnResults = 'Results_F6_Report_FullProfile02';
% Configure results to be saved
%y.Feeder.resultExt = @(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N,'RegControlExpr','None','CapacitorExpr','None');
y.Feeder.resultExt = @(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N);
% y.Feeder.resultExt = @(DSSObj,N) sg_resultExtBase_gv(DSSObj,N);

%% Open and configure OpenDSS connection
try
    DSSObj = sg_startOpenDSS;
catch
    % in case helper functions are not on the path yet
    startup;
    DSSObj = sg_startOpenDSS;
end

%% Execute model
tic;
% [r,DSSObj,time] = sg_runOpenDSSSim(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,'resultExt',y.Feeder.resultExt);
[r,DSSObj,time] = sg_runOpenDSSSim(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,'resultExt',y.Feeder.resultExt,'profilePoints',-1);
% [r,DSSObj,time] = sg_runOpenDSSSim_gv(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,'resultExt',y.Feeder.resultExt,'profilePoints',0);
if r.status
    r.Tel = toc;
    r.t   = time;
    r.Feeder = y.Feeder;
else
    fprintf(' No power flow results computed by OpenDSS.\n');
    return
end

%% Save results
if ~isempty(dir([r.Feeder.fnResults '.mat']))
    r.Feeder.fnResults = [r.Feeder.fnResults '_' datestr(now,'yyyymmddTHHMMSS')];
end
save(r.Feeder.fnResults,'r');

%% Show selected results
% sg_plotMaxMinVoltageProfile(r,'vscale',[0.9 1.1]); % extreme voltage profiles experienced
% sg_plotFeeder(r);               % feeder structure and status (at first point in time)

%% Start plots to compare results (adding reduced model's data lateron)
fno = 0;
BVidx = [3  8  11]; % bus voltages indices: 20 70 100
BIidx = [1];        % bus index for feeder current: 00
Prows = size(r.Bus.V1.val,1);

lw = 1;

fno = fno + 1;
figure(fno)
plot(abs(r.Bus.V1.val(:,BVidx)*sqrt(3))/1e3,'-x','linewidth',lw)
xlabel('profile data point')
ylabel('line-line voltage (kV)')
set(gca,'xtick',[1:Prows])
set(gcf,'name','F6 full bus voltages')
legend('Bus 20','Bus 70','Bus 100')

fno = fno + 1;
figure(fno)
plot(abs(r.Line.I1.val(:,BIidx)),'-x','linewidth',lw)
xlabel('profile data point')
ylabel('feeder current (A)')
set(gca,'xtick',[1:Prows])
set(gcf,'name','F6 full current')
