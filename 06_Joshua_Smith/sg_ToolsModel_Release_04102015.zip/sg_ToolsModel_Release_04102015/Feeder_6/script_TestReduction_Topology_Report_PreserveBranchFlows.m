%% script: Example script to test reduction based on topology
%          Feeder 6, preserving branch flow information
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%
% February 2015

%% Default setup and handling of options
para.Model       = [pwd '\Feeder_6s_CC.dss'];
para.Method      = 'topology';
para.KeepBuses   = {'B60000P' 'B60020P' 'B60070P' 'B60100P' 'B60080P' 'B60040P' 'B60120P'};
para.RemoveBuses = {};
para.KeepConPoints = 1; % shift lines if encountering connection point (more than one out-going branch)
para.IDkeyBuses    = 0; % all are listed
para.TargetFolder      = [pwd '\F6a_CC_MR_Topology_Report_PreserveBranchFlows'];
para.ActionFile        = 'ActionList.txt';
para.ActionUnDoFile    = 'ActionListUnDo.txt';
para.ActionCommentFile = 'ActionComments.txt';
para.profile    = [pwd '\Feeder_6_Profile_01.xlsx'];
para.profile    = [];
para.ActDisp   = 1;    % display actions taken (command line)
para.DispFlag  = 1;    % progress display (window)
para.fno       = 1000; % progress window number

r = sg_DispatchReduction(para);