
function y=sg_getLineFlow(varargin)

%  y=sg_getLineFlow(DSSObj)
%  Options:
%    LineExpr - a string treated as a regular expression used to match names (default=.*')
%    LineMeasPoint - an integer indicating the end of the line at which to
%      measure power flow (default = 1, indicating the sending end).
%    caseSensitive - an integer indicating whether the pattern LineExpr is to be
%      treated as case sensitive (1) or not (0).  Default is 1.
%
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

DSSObj=varargin{1};

opts=struct('LineMeasPoint',1,'caseSensitive',1);
opts.LineExpr='.*';

opts=sg_updateOpts(opts,varargin,1);

y=struct();

DSSCircuit  = DSSObj.ActiveCircuit;

N=1;

%  Line power values.
y.Line = struct();
linev = DSSCircuit.Lines.AllNames;
i0 = sg_rgrep(opts.LineExpr,linev,'caseSensitive',opts.caseSensitive);
y.Line.S1.names = linev(i0);
y.Line.S1.index = i0;
y.Line.S1.val = zeros(N,length(i0));
y.Line.S1.incl = zeros(1,length(i0));
y.Line.I1.val = zeros(size(y.Line.S1.val));
y.Line.V11.val = zeros(size(y.Line.S1.val));
y.Line.V12.val = zeros(size(y.Line.S1.val));
y.Line.kVbase = zeros(1,length(i0));

y.Line.S2.names = linev(i0);
y.Line.S2.index = i0;
y.Line.S2.val = zeros(N,length(i0));
y.Line.S2.incl = zeros(1,length(i0));
y.Line.I2.val = zeros(size(y.Line.S2.val));
y.Line.V21.val = zeros(size(y.Line.S2.val));
y.Line.V22.val = zeros(size(y.Line.S2.val));

y.Line.S3.names = linev(i0);
y.Line.S3.index = i0;
y.Line.S3.val = zeros(N,length(i0));
y.Line.S3.incl = zeros(1,length(i0));
y.Line.I3.val = zeros(size(y.Line.S3.val));
y.Line.V31.val = zeros(size(y.Line.S3.val));
y.Line.V32.val = zeros(size(y.Line.S3.val));

for n = 1:length(y.Line.S1.names)
    x = DSSCircuit.CktElements(['Line.' y.Line.S1.names{n}]);
    xx = x.get('NodeOrder');
    Nxx = length(xx);
    if(opts.LineMeasPoint==1)
        xx((Nxx/2+1):end) = zeros(1,Nxx/2);
    else
        xx(1:(Nxx/2)) = zeros(1,Nxx/2);
    end
    %  xx = xx(1:(length(xx)/2));
    i1 = find(xx==1);
    if ~isempty(i1)
        y.Line.S1.incl(n) = i1;
    end
    i1 = find(xx==2);
    if ~isempty(i1)
        y.Line.S2.incl(n) = i1;
    end
    i1 = find(xx==3);
    if ~isempty(i1)
        y.Line.S3.incl(n)=i1;
    end
end

y.n=1;

%  Update line power flows.
for n = 1:length(y.Line.S1.names)
    x = DSSCircuit.CktElements(['Line.' y.Line.S1.names{n}]);
    xx = x.get('Powers');
    xxI = x.get('Currents');
    xxV = x.get('Voltages');
    % determine base kV for line
    bn = x.BusNames{1};
    idx = strfind(bn,'.');
    if ~isempty(idx)
        bn = bn(1:idx(1)-1);
    end
    y.Line.kVbase(n) = DSSObj.ActiveCircuit.Buses(bn).kVBase;
    ix = y.Line.S1.incl(n);
    ix = 2*ix-1;
    if(ix>0)
        y.Line.S1.val(y.n,n) = xx(ix)+1i*xx(ix+1);
        y.Line.I1.val(y.n,n) = xxI(ix)+1i*xxI(ix+1);
        y.Line.V11.val(y.n,n) = xxV(ix)+1i*xxV(ix+1);
        y.Line.V12.val(y.n,n) = xxV(ix+6)+1i*xxV(ix+1+6);
    elseif(ix==-1)
        y.Line.S1.val(y.n,n) = xx(1)+1i*xx(2);
        y.Line.I1.val(y.n,n) = xxI(1)+1i*xxI(2);
        y.Line.V11.val(y.n,n) = xxV(1)+1i*xxV(2);
        y.Line.V12.val(y.n,n) = xxV(1+6)+1i*xxV(2+6);
    end
    ix = y.Line.S2.incl(n);
    ix = 2*ix-1;
    if(ix>0)
        y.Line.S2.val(y.n,n) = xx(ix)+1i*xx(ix+1);
        y.Line.I2.val(y.n,n) = xxI(ix)+1i*xxI(ix+1);
        y.Line.V21.val(y.n,n) = xxV(ix)+1i*xxV(ix+1);
        y.Line.V22.val(y.n,n) = xxV(ix+6)+1i*xxV(ix+7);
    elseif(ix==-1)
        y.Line.S2.val(y.n,n) = xx(3)+1i*xx(4);
        y.Line.I2.val(y.n,n) = xxI(3)+1i*xxI(4);
        y.Line.V21.val(y.n,n) = xxV(3)+1i*xxV(4);
        y.Line.V22.val(y.n,n) = xxV(9)+1i*xxV(10);
    end
    ix = y.Line.S3.incl(n);
    ix = 2*ix-1;
    if(ix>0)
        y.Line.S3.val(y.n,n) = xx(ix)+1i*xx(ix+1);
        y.Line.I3.val(y.n,n) = xxI(ix)+1i*xxI(ix+1);
        y.Line.V31.val(y.n,n) = xxV(ix)+1i*xxV(ix+1);
        y.Line.V32.val(y.n,n) = xxV(ix+6)+1i*xxV(ix+7);
    elseif(ix==-1)
        y.Line.S3.val(y.n,n) = xx(5)+1i*xx(6);
        y.Line.I3.val(y.n,n) = xxI(5)+1i*xxI(6);
        y.Line.V31.val(y.n,n) = xxV(5)+1i*xxV(6);
        y.Line.V32.val(y.n,n) = xxV(11)+1i*xxV(12);
    end
end