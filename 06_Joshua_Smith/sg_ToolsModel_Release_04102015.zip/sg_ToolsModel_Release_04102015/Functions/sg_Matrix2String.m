function y = sg_Matrix2String(m)
% Convert a numeric matrix into its (OpenDSS) string form.
% function y = sg_Matrix2String(m)
%
% Convert a numeric matrix into its (OpenDSS) string form, treating real 
% and imaginary part separately.
%
% Input:  m - matrix
%
% Output: y. - structure
%         .re - string of real part
%         .im - string of imaginary part
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

y.re = '';
y.im = '';

y.re = '[';
for jj = 1:size(m,1)
    for kk = 1:size(m,2)
        y.re = sprintf('%s %f ',y.re,real(m(jj,kk)));
    end
    if jj < size(m,1)
        y.re = [y.re '|'];
    else
        y.re = [y.re ']'];
    end
end
    
if ~isreal(m)
    y.im = '[';
    for jj = 1:size(m,1)
        for kk = 1:size(m,2)
            y.im = sprintf('%s %f ',y.im,imag(m(jj,kk)));
        end
        if jj < size(m,1)
            y.im = [y.im '|'];
        else
            y.im = [y.im ']'];
        end
    end
end