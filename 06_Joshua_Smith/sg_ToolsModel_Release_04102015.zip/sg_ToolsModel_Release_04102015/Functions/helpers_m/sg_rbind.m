function y=sg_rbind(x1,x2)

%  Row Bind Function
%  y=sg_rbind(x1,x2)
%  Combines two data frame-like structures (similar to R rbind function).
%  Returns y, the combined structure.
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

nv=fieldnames(x1);

y=struct();

for(n=1:length(nv))
    nm=nv{n};
    if(iscell(x1.(nm))==0)
        try
            y.(nm)=[x1.(nm) x2.(nm)];
        catch
            y.(nm)=[x1.(nm);x2.(nm)];
        end
    else
        try
            y.(nm)={x1.(nm) x2.(nm)};
        catch
            y.(nm)={x1.(nm);x2.(nm)};
        end
    end
end