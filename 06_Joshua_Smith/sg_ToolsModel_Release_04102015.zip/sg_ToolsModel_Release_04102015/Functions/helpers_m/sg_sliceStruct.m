function snew=sg_sliceStruct(varargin)

%  Slice Structure Function
%  snew=sg_sliceStruct(s,rowIndices)
%  This function is intended to be used on structures in which all of the
%  elements are vectors of the same length.  The function is used to return
%  a structure containing specific indices from each of the vectors.
%  Parameters:
%    s - a structure to be sliced
%    rowIndices - a vector of indices to retain in the returned structure
%
%  snew=sliceStruct(s,fieldname,fromValue,toValue)
%  This form of the function returns a structure in which the indices
%  returned for each vector are in the range of fromValue to toValue for
%  the element given by the string fieldname
%
%  Returns snew, a structure containing the specific indices from each of
%  the element vectors.
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

Nargs=length(varargin);

s=varargin{1};

if(Nargs==2)
    rowIndices=varargin{2};
else
    fieldname=varargin{2};
    fromValue=varargin{3};
    toValue=varargin{4};
    
    v1=s.(fieldname);
    rowIndices=find((v1>=fromValue)&(v1<=toValue));
end




snew=struct();

k=fieldnames(s);

for(n=1:length(k))
    temp=s.(k{n});
    if(length(temp)>1)
        snew.(k{n})=temp(rowIndices);
    else
        snew.(k{n})=temp; 
    end
end
