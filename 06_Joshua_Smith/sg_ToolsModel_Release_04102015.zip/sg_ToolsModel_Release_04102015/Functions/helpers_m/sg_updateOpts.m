function uo = sg_updateOpts(varargin)
%  Function Options Updating Function
%  uo = updateOpts(defaults,options)
%
%  This function simply provides a convenient way to parse options passed
%  to a function.  The function utilizing this function must create a
%  structure with fields specifying default values for each option.  This
%  structure, defaults, is passed to this function, along with the cell
%  array containing additional options.  The function simply updates the
%  values of the fields for any options passed in by the user and returns
%  the updated structure.
%
%  uo = updateOptions(defaults,options,Nmandatory)
%
%  Inputs:
%    Nmandatory - if specified, determines the number of cells to consider
%                 as mandatory arguments (these are stripped off)
%    defaults   - structure of default options
%    options    - user provided list (cell array) of mandatory parameters and 
%                 parameter names/values (note: names are matched (case
%                 insensitive), unmatched options are added as new entries.
%  Output:
%    uo         - updated options structure
%
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

Nargs    = length(varargin);
defaults = varargin{1};
defaultFields = fieldnames(defaults);
UserOptions = varargin{2};
Nmandatory = 1;
if (Nargs > 2)
    Nmandatory = varargin{3};
end

if (length(UserOptions) > Nmandatory)
    options = UserOptions(Nmandatory+1:end);
    for n = 1:length(options)/2
        OptIdx =  find(strcmpi(options{(2*n-1)},defaultFields));
        if ~isempty(OptIdx)
            % found a (case insensitive) match: updating value
            defaults.(defaultFields{OptIdx}) = options{(2*n)};
        else
            % new option
            defaults.(options{(2*n-1)}) = options{(2*n)};
        end
    end
end    

uo = defaults;