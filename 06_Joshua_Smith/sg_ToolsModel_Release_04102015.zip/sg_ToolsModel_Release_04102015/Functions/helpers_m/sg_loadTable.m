function [y,varnames,EventLog] = sg_loadTable(varargin)
%  Load Table
%  function [y,varnames,EventLog] = sg_LoadTable(filename)
%
%  This function is used to read a text file or spreadsheet and return a
%  structure containing the results.  In particular, this is intended to be
%  used with a file in which the first line specifies the names associated
%  with the columns in the file, and is intended to be used for cases in
%  which the columns may be any mixture of numeric and string data.
%  Options
%    'commentChar' - Indicates the character used for comments (default is '%')
%    'num' - If set to 1, indicates that an attempt should be made to convert
%      all elements from cell arrays to matrices (default is 1).
%    'sheet' - The sheet number (default=1).
%    'returnType' - A string indicating the type for the return value y
%    ('cell' for cell array or matrix, 'struct' for structure) (default='struct');
%    'DispFlag' - display flag
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% October 30, 2014

%% Settings
y = 0;
DispFlag = 1;
EventLog = {};

opts = struct('commentChar','%','num',1,'sheet',1,'returnType','struct');
opts = sg_updateOpts(opts,varargin,1);

commentChar = opts.commentChar;
numOpt = opts.num;

%  Extract the function parameters and options.
filename = varargin{1};

%  Use xlsread() to read in the file.
try
    [numeric,txt,raw] = xlsread(filename,opts.sheet);
catch
    le = lasterror;
    if DispFlag
        fprintf('\n Error: Could not load profile data.\n');
        fprintf('\n  Message:  %s\n',le.message);
        fprintf('\n  File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
    end
    EventLog{end+1} = 'Error: Could not load profile data.';
    return
end

%%  Build data structure
try
    %  Load in as usual, assuming the first row specifies the variable names.
    dataStart = 0;
    Nstart = 1;
    while(dataStart==0)
        if(raw{Nstart,1}(1)==commentChar)
            Nstart = Nstart+1;
        else
            dataStart = 1;
        end
    end
    
    varnames = raw(Nstart,:);
    [Nr,Nc] = size(raw);
    raw = raw((Nstart+1):Nr,:);
    
    if(strcmp(opts.returnType,'cell')==1)
        y = raw;
        if(numOpt==1)
            try
                y = cell2mat(y);
            end
        end
    else
        y = struct();
        for n = 1:length(varnames)
            if(numOpt==0)
                y.(varnames{n}) = raw(:,n);
            else
                try
                    y.(varnames{n}) = cell2mat(raw(:,n));
                catch
                    y.(varnames{n}) = raw(:,n);
                end
            end
        end
    end
catch
    le = lasterror;
    if DispFlag
        fprintf('\n Error: Could not process profile data.\n');
        fprintf('\n  Message:  %s\n',le.message);
        fprintf('\n  File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
    end
    EventLog{end+1} = 'Error: Could not process profile data.';
    return
end