function y=sg_writeTable(varargin)

%  Write Table Function (Structures)
%  y=sg_writeTable(fn,d)
%  Writes the structure d to a file specified by fn.  The
%  structure is written to the file, with the names of the structure
%  elements written as a header in the file.
%  Options:
%    'suppressHeader' - if a value of 1 is specified, the header is
%      suppressed (default value is 0)
%    'num' - if a value of 1 is specified, it is assumed that all elements
%      of the structure is numeric, and a more efficient method for writing
%      the data is used (default value is 0).
%    'precision' - format specifier (default='%15.9f')
%  Returns y, (0 indicating success).
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

fn=varargin{1};
d=varargin{2};

opts=struct('suppressHeader',0,'num',0,'precision','%15.9f');

opts=sg_updateOpts(opts,varargin,2);

if(opts.num==1)
    names=fieldnames(d); 
    Nc=length(names);
    Nr=length(d.(names{1}));
    M=zeros(Nr,Nc);
    fid=fopen(fn,'wt');
    s1=names{1};
    for(n2=2:length(names))
        s1=[s1 ',' names{n2}];
    end
    s1=[s1 '\n'];
    if(opts.suppressHeader==0)
        fprintf(fid,s1);
    end
    fclose(fid);
    for(n2=1:length(names))
        name=names{n2};
        M(:,n2)=d.(name);
    end
    %csvwrite(fn,M);
    dlmwrite(fn,M,'-append','precision',opts.precision);
     
else
    names=fieldnames(d);
    Nc=length(names);
    Nr=length(d.(names{1}));
    
    %  If necessary, convert all fields to cell arrays.
    for(n=1:Nc)
         if(iscell(d.(names{n}))==0)
             d.(names{n})=num2cell(d.(names{n}));
         end
    end
    
    fid=fopen(fn,'wt');
    s1=names{1};
    for(n2=2:length(names))
        s1=[s1 ',' names{n2}];
    end
    s1=[s1 '\n'];
    if(opts.suppressHeader==0)
        fprintf(fid,s1);
    end
    
    
    for(n=1:Nr)
       %fprintf(1,'%d ',n);
       if(ischar(d.(names{1}){n})==1)
           s1=d.(names{1}){n};
       else
           s1=sprintf(opts.precision,d.(names{1}){n});
       end
       for(n2=2:Nc)
           if(ischar(d.(names{n2}){n})==1)
               s1=[s1 ', ' d.(names{n2}){n}];
           else
               s1=sprintf(['%s,' opts.precision],s1,d.(names{n2}){n});
           end 
       end
       s1=[s1 '\n'];
       fprintf(fid,s1);
    end
    
%     for(n=1:Nr)
%        s1=sprintf('%s',d.(names{1}){n});
%        for(n2=2:Nc)
%            s1=sprintf('%s,%s',s1,d.(names{n2}){n});
%        end
%        s1=[s1 '\n'];
%        fprintf(fid,s1);
%     end
    
    fclose(fid);
    
end

