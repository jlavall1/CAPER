function [results,DSSObj,time] = sg_runOpenDSSSim_gv(varargin)
% OpenDSS Simulation
% function [results,DSSObj,time] = sg_runOpenDSSSim_gv(model)
%
% Main file for executing a time series study. This version is based on a
% global variable for data extraction.
%
% Inputs: 	model	... a string indicating the name of an OpenDSS model file.
% 		  'DSSObj' 	... OpenDSS COM interface connection (default = '' 
%      					indicating that a new connection should be created.
%    	  'profile' ... a structure with profiles for component parameters over time.
%      					Alternatively, this can be a string, specifying the name of a file
%      					to read in for the profile.  (default = '', indicating that a single
%      					snapshot is to be taken.
%   'profilePoints'	... an integer indicating the number of points in the
%      					profile to run (default = -1, indicating run all points).
%    	'resultExt'	... a handle to a function of the form
%       				ynew = f(DSSObj,y,N), where y is a data structure (updated with new
%       				data after each run), and DSSObj is the OpenDSS COM interface
%       				connection.  This function will be called after each run, so that
%       				the function can update the structure y, with new data, and return
%       				this.  The function should expect y to be a scalar value of zero
%       				after the initial run.  N is the total number of runs.  
%       				(Default is '', indicating that a standard data structure 
%						should be returned).
%    'initParams'	... a cell array specifying the names of parameters to be
%      					set prior to the first snapshot (default is is an empty cell
%      					array, indicating that no parameters need to be set).
%    	'initVals' 	... a cell array specifying the values to which the parameters
%      					specified in initParmams should be set (default is an empty cell array).
%    'initValsFmt' 	... a cell array specifying the format string to use for the
%      					values in initVals (e.g. %f).  By default, this is an empty cell
%      					array, in which case, '%.0f' is used for all values.  A single
%      					format string can also be supplied, in which case, this will be used
%      					for all values in initVals
%    	'controls' 	... a cell array of control objects.
%   'controlsFile'  ... a string specifying the name of a file containing
%                       contructor calls for control classes.  The default
%                       value is an empty string, indicating that such a
%                       file should not be included.
%    	'DispFlag' 	... display events/messages (0/1), default: 1
%    'AllowForms'	... an option to allow (1) or block (0) dialogue boxes from
%      					OpenDSS (default=0).
%    'Niterations'  ... Specifies the number of solution iterations to be used for
%                       each time step.  The default value is 1, which
%                       should be sufficient, unless control classes taking action
%                       based on solution results have been included.  If a
%                       positive value is specified for the 'dVmax'
%                       parameter, the value of the 'Niterations' option
%                       is interpeted as a maximum number of iterations for each
%                       time step.
%         'dVmax'   ... Specifies a voltage tolerance to be used for
%                       iterative solutions.  If control classes taking
%                       action based on solution results are included, an
%                       iterative solution can be used for each time step.
%                       The iterative loop will end for a time step when
%                       either the number of iterations reaches the limit
%                       specified by 'Niterations' or the maximum per unit deviation
%                       between bus voltages on successive iterations is
%                       less than the value specified by the 'dVmax'
%                       option.  The default value is -1, indicating that
%                       the number of iterations specified by the 'Niterations'
%                       option will be used.
%
% Outputs: results	...
%		   DSSObj	...
%		   time		...
%
% Example Call(s):
%   % Solve the model specified in the 'Feeder_1.dss' file.
% 	[results,DSSObj,time] = sg_runOpenDSSSim('Feeder_1.dss');
%
%   % Solve for the model currently loaded in the DSSObj connection.
%   [results,DSSObj,time] = sg_runOpenDSSSim('','DSSObj',DSSObj);  
%
%   % Solve the model specified in the 'Feeder_1.dss' file using the time
%   % profile specified in 'profile.csv'.
% 	[results,DSSObj,time] = sg_runOpenDSSSim('Feeder_1.dss','profile','profile.csv');
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%
% Note:  This function is still under development.
%

%% Default setup and handling of options
model = varargin{1};
EventLog = {};   % keeps track of warning/error messages (cell array)
DispFlag = 1;    % turn on/off console display (0/1)
status   = 0;    % power flow solution status (0/1)
LoadScale = 1;   % scaling factor for loads in profile
GenScale  = 1;   % scaling factor for generators in profile

opts = struct('DSSObj','','profile','','resultExt','','profilePoints',-1,...
    'DispFlag',DispFlag,'LoadScale',LoadScale,'GenScale',GenScale,'AllowForms',0,...
    'Niterations',1,'dVmax',-1);
opts.initParams={};
opts.initVals={};
opts.initValsFmt={};
opts.controls={};
opts = sg_updateOpts(opts,varargin,1);

results = [];
time = [];

% clear/reset global variable (for data extraction)
clear global DATA_RESULTS
global DATA_RESULTS

if(ischar(opts.resultExt)==1)
    opts.resultExt = @sg_resultExtBase_gv; 
end

if(ischar(opts.DSSObj)==1)
    % Instantiate the OpenDSS Object
    DSSObj = actxserver('OpenDSSEngine.DSS');
    DSSObj.AllowForms=opts.AllowForms;
    % Start up the Solver
    if ~DSSObj.Start(0),
        EventLog{end+1} = 'Error: Unable to start the OpenDSS Engine';
        if opts.DispFlag
            disp('Unable to start the OpenDSS Engine')
        end
        results.status   = status;
        results.EventLog = EventLog;
        return
    else
        EventLog{end+1} = 'Started OpenDSS Engine';
    end
else
    DSSObj = opts.DSSObj;
end

%% Handles to OpenDSS 
DSSText     = DSSObj.Text;
DSSCircuit  = DSSObj.ActiveCircuit;
DSSSolution = DSSCircuit.Solution;
DSSloads    = DSSCircuit.Loads;


%% Compile the model (and check for errors in circuit/OpenDSS setup).

%  If an empty string is passed for the model, assume that a model has
%  already been loaded and compiled in the DSSObj.
if(strcmp(model,'')==0)
    fsc = filesep;
    if isempty(strfind(model,fsc))
        % check for fully qualified file name based on file separation character
        model = [pwd fsc model];
    end
    str1 = sprintf('Compile (%s)',model);
    DSSText.command = str1;
    if ~isempty(DSSText.Result)
        txt = DSSText.Result;
        EventLog{end+1} = sprintf('Error: OpenDSS: %s',txt);
        if opts.DispFlag
            fprintf(' OpenDSS: %s\n',DSSText.Result);
        end
        results.status   = status;
        results.EventLog = EventLog;
        return
    end
end

% 'Compile' silently keeps processing data files: Need to use a command to
% check for errors in setup
DSSText.command = 'Calcv';
if ~isempty(DSSText.Result)
    EventLog{end+1} = sprintf(['Error: OpenDSS: %s\n',DSSText.Result]);
    if opts.DispFlag
        fprintf(' OpenDSS: %s\n',DSSText.Result);
    end
    results.status   = status;
    results.EventLog = EventLog;
    return
end

%% Load PV and load profile data
if(ischar(opts.profile)==1)
    if(strcmp(opts.profile,'')==0)
        %  Read in the profile for the file.
        [Tprof,nvTprof,EventLogPD] = sg_loadTable(opts.profile,'returnType','cell');

        if ~isempty(EventLogPD)
            results.status   = status;
            results.EventLog = EventLogPD;
            return
        end
        opts.profile = struct();
        opts.profile.time = Tprof(:,1);
        opts.profile.param = nvTprof(2:end);
        opts.profile.val = Tprof(:,2:end);
        opts.profile.fmt = {};
        for n = 1:length(opts.profile.param)
            opts.profile.fmt{n} = '%f'; 
        end
    end
end

if(isstruct(opts.profile)==1)
    % Check if elements listed in profile actually exist and warn if not
    ElementList = DSSCircuit.AllElementNames;
    ProfileElements = {};
    for ii = 1:length(opts.profile.param)
        % Expecting 'Element.name Property': extract Element.name
        ProfileElement = opts.profile.param{ii};
        idx = strfind(ProfileElement,' ');
        ProfileElement = ProfileElement(1:idx(1)-1);
        ProfileElements{end+1} = ProfileElement;
        index = strcmpi(ElementList,ProfileElement);
        jj = 1;
        while (jj <= length(index)) & ~index(jj)
            jj = jj + 1;
        end
        if jj > length(index)
            EventLog{end+1} = sprintf('Warning: OpenDSS: Profile element %s not in OpenDSS circuit.',ProfileElement);
        end
    end

    % Option of scaling loads and generation (uniformly)
    if opts.LoadScale ~= 1
        % scale all loads
        sg_ScaleElements('load',opts.LoadScale,ProfileElements,ElementList,DSSText);
    end
    if opts.GenScale ~= 1
        % scale all generators
        sg_ScaleElements('generator',opts.GenScale,ProfileElements,ElementList,DSSText);
    end
end

%%  Initialize any specified parameters.

if(length(opts.initParams)>0)
    Ni=length(opts.initParams);
    if(length(opts.initValsFmt)==1)
        opts.initValsFmt=repmat(opts.initValsFmt,1,Ni);
    elseif(length(opts.initValsFmt)==0)
        opts.initValsFmt=repmat({'%.0f'},1,Ni);
    end
    for(n2=1:length(opts.initParams))
       str1=sprintf(['edit %s=' opts.initValsFmt{n2}],opts.initParams{n2},opts.initVals{n2});
       % fprintf(1,'%s\n',str1);
       DSSText.Command=str1;
    end
end

%% Power flow: for single snapshot or time series
if(isstruct(opts.profile)==0)
    %  Solve the model.
    DSSText.command = 'Calcv';
    if ~isempty(DSSText.Result)
        EventLog{end+1} = sprintf('Error: OpenDSS: %s\n',DSSText.Result);
        if opts.DispFlag
            fprintf(' OpenDSS: %s\n',DSSText.Result);
        end
        results.status   = status;
        results.EventLog = EventLog;
        return
    end
	time = 0;
    DSSSolution.Solve;
    try
        opts.resultExt(DSSObj,1);
        status = 1;
    catch
        % data extraction failed: providing error message
        le = lasterror;
        EventLog{end+1} = sprintf('Error: Extracting result data:\n  %s\nFile: %s, Line: %.0f\n',le.message,le.stack(1).name,le.stack(1).line);
        if opts.DispFlag
            fprintf('\n Error extracting result data:\n  %s\n',le.message);
            fprintf('\n File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
        end
    end
else
    profile = opts.profile;
    if(opts.profilePoints>0)
        profile.time = profile.time(1:opts.profilePoints); 
    end
    N = length(profile.time);
    DSSSolution.Solve;         % run full power flow and have controls adjust to load conditions
    DSSText.command = 'Calcv'; % recompute base-kV (initial regulator settings may have caused wrong values)
    if ~isempty(DSSText.Result)
        EventLog{end+1} = sprintf('Error: OpenDSS: %s\n',DSSText.Result);
        if opts.DispFlag
            fprintf(' OpenDSS: %s\n',DSSText.Result);
        end
        results.status   = status;
        results.EventLog = EventLog;
        return
    end
    DSSSolution.Solve;         % calcv resets solution (zero currents for kV calc) --> redo power flow
    str1 = sprintf('Set ControlMode = Time'); % switch mode to include (control) timing 
    DSSText.Command = str1;
    for n = 1:length(profile.time)
        hour = floor(profile.time(n)/3600);
        second = profile.time(n)-3600*hour;
        str1 = sprintf('Set time = (%.0f,%.0f)',hour,second);
        DSSText.Command = str1;
        
        for n2 = 1:length(profile.param)
            str1 = sprintf(['edit %s = ' profile.fmt{n2}],profile.param{n2},profile.val(n,n2));
            DSSText.Command = str1;
            % catch errors (e.g., unknown parameters)
            if ~isempty(DSSText.Result)
                txt = DSSText.Result;
                EventLog{end+1} = sprintf('Error: OpenDSS: %s',txt);
                if opts.DispFlag
                    fprintf(' OpenDSS: %s\n',DSSText.Result);
                end
                results.status   = status;
                results.EventLog = EventLog;
                return
            end
        end
        
        %  Call control objects.
        if(length(opts.controls)>0)
            for(n2=1:length(opts.controls))
                opts.controls{n2}.operate(DSSObj,profile.time(n));
            end
        end
        
        DSSSolution.Solve;
        Vv0=DSSObj.ActiveCircuit.AllBusVmagPu;
        if(opts.Niterations>1)
            for(nx=2:opts.Niterations)
                %  Call control objects.
                if(length(opts.controls)>0)
                    for(n2=1:length(opts.controls))
                        opts.controls{n2}.operate(DSSObj,profile.time(n));
                    end
                end
                DSSSolution.Solve;
                if(opts.dVmax>0)
                    Vv1=DSSObj.ActiveCircuit.AllBusVmagPu;
                    dVv=Vv1-Vv0;
                    %fprintf('After iteration %d, dVmax=%f.\n',nx,max(abs(dVv)));
                    if(max(abs(dVv))<opts.dVmax) break; end
                    Vv0=Vv1;
                    if(nx==opts.Niterations)
                       fprintf(1,'Failed to converge at t=%f within %d iterations.\n',profile.time(n),nx); 
                    end
                end
            end
        end
        
        try
            opts.resultExt(DSSObj,N);
            status = 1;
        catch
            % data extraction failed: providing error message
            le = lasterror;
            EventLog{end+1} = sprintf('Error: Extracting result data:\n  %s\nFile: %s, Line: %.0f\n',le.message,le.stack(1).name,le.stack(1).line);
            if opts.DispFlag
                fprintf('\n Error extracting result data:\n  %s\n',le.message);
                for ii = 1:length(le.stack)
                    fprintf('  File: %s, Line: %.0f\n',le.stack(ii).name,le.stack(ii).line);
                end
            end
         end
        time = profile.time;
    end
end
results = DATA_RESULTS;
% Add topology information
results.Topology = sg_GetTopologyTree(DSSObj);
results.status   = status;
results.EventLog = EventLog;
% clear/reset global variable (for data extraction)
clear global DATA_RESULTS

function sg_ScaleElements(type,factor,Elements,ElementList,DSSText)
% function sg_ScaleElements(type,factor,Elements,DSSText)
%
% Scale rating of loads and generators (including interconnecting transformer)

% determine list of transformers
Tidx = [];
for ii = 1:length(ElementList)
    idx = strfind(lower(ElementList{ii}),'transformer.');
    if ~isempty(idx)
        Tidx = [Tidx ii];
    end
end

% scale elements
for ii = 1:length(Elements)
    if ~isempty(strfind(lower(Elements{ii}),[type '.']))
        % scale elements itself
        str1 = sprintf('? %s.XFkVA',Elements{ii});
        DSSText.Command = str1;
        XFkVA = str2num(DSSText.Result);
        str1 = sprintf('edit %s XFkVA = %f',Elements{ii},XFkVA*factor);
        DSSText.Command = str1;
        % catch errors
        if ~isempty(DSSText.Result)
            txt = DSSText.Result;
            EventLog{end+1} = sprintf('Error: OpenDSS: %s',txt);
            if opts.DispFlag
                fprintf(' OpenDSS: %s\n',DSSText.Result);
            end
            results.status   = status;
            results.EventLog = EventLog;
            return
        end
        % find and scale corresponding transformers
        idx = strfind(Elements{ii},'.');
        ElementName = Elements{ii}(idx(1)+1:end);
        idx = strfind(lower(ElementList(Tidx)),lower(ElementName));
        for jj = 1:length(idx)
            if ~isempty(idx{jj})
                str1 = sprintf('? %s.kvas',ElementList{Tidx(jj)});
                DSSText.Command = str1;
                kvas = str2num(DSSText.Result);
                str1 = sprintf('edit %s kvas = (%f %f)',ElementList{Tidx(jj)},kvas*factor);
                DSSText.Command = str1;
                % catch errors
                if ~isempty(DSSText.Result)
                    txt = DSSText.Result;
                    EventLog{end+1} = sprintf('Error: OpenDSS: %s',txt);
                    if opts.DispFlag
                        fprintf(' OpenDSS: %s\n',DSSText.Result);
                    end
                    results.status   = status;
                    results.EventLog = EventLog;
                    return
                end
            end
        end
    end
end