function messages=sg_scaleParam(varargin)

%  Scale Parameter of OpenDSS Model
%  function sg_scaleParam(DSSObj,param,val)
%  Inputs:
%    DSSObj - a connection to an OpenDSS object with a loaded model
%    param - a string specifying the name of the
%      parameter for which a value is to be scaled.
%    val - a numeric value by which the parameters specified by name are
%      to be scaled.  If val is a cell array of the same length as param,
%      each parameter specified by param is scaled by the associated
%      element of val.
%  Options:
%    scale - an integer specifying that the parameter is to be scaled by
%      the value given in val.  If this option is set to zero, rather
%      than scaling the value, the parameter is directly set to the value given by
%      val (default=1).
%    verify - an option indicating whether or not verification of the
%      operation should be done.  If set to 1, the function retrieves the
%      value of the parameter after each set operation to verify that it
%      reflects the value to which it was intended to be set.  If the value
%      is not correct, a warning message is included in the return value 
%      for the function.  If this option is set to zero, no verification is 
%      done. (default=1) 
%  Returns messages, a cell array of strings indicating issues encountered.
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% November 21, 2014

DSSObj=varargin{1};
param=varargin{2};
val=varargin{3};

opts=struct('scale',1,'verify',1);
opts=sg_updateOpts(opts,varargin,3);

messages={};
Nmessages=0;

if(iscell(param)==0)
    param = {param}; 
end

if(iscell(val)==0)
    val={val};
end

if((length(param)>1)&(length(val)==1))
    val2={};
    for(n=1:length(param))
        val2{n}=val{1}; 
    end
    val=val2;
    %val=val*ones(1,length(param));
end

for(n=1:length(param))
    param1=strrep(param{n},' ','.');
    if(opts.scale==1)  %  Get current value to be scaled.
        str1 = sprintf('? %s',param1);
        DSSObj.Text.Command = str1;
        currentval=str2num(DSSObj.Text.Result);
    else  %  Value will be set to val.
        currentval=1; 
    end
    targetval=currentval*val{n};
    strtargetval=sg_numToText(targetval);
    str1 = sprintf('edit %s = %s',param{n},strtargetval);
    DSSObj.Text.Command = str1;
    if(opts.verify==1)
        str1 = sprintf('? %s',param1);
        DSSObj.Text.Command = str1;
        valactual=str2num(DSSObj.Text.Result);
        check=all(targetval==valactual);
        if(check==0)
            Nmessages=Nmessages+1;
            messages{Nmessages}=sprintf('Verification of parameter %s failed (target = %f, reported = %f)',param{n},targetval,valactual);
        end
    end
end

end

%  Converts a numeric value (possibly a vector) to a string of the form
%  expected by OpenDSS.
function strv=sg_numToText(val)
    N=length(val);
    if(N==1)
        strv=num2str(val);
    else
        strv='(';
        for(n=1:N)
            strv = sprintf('%s%f,',strv,val(n));
        end
        strv=strv(1:(end-1));
        strv = [strv ')'];
    end
end