function y = sg_getPQ_VI(V,I)
% Helper function to compute complex power from 'raw' OpenDSS voltage and current.
% function [P,Q] = sg_getPQ_VI(V,I)
%
% V ... real numbers (retrieved from solved model) of phase voltages, (V)
% I ... real numbers (retrieved from solved model) of phase currents, (A)
%
% y.
%  .S  ... 3-phase complex power (VA)
%  .S1 ... single-phase complex power values (VA)
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

n = 6;
y.Vc = [V(1:2:n) + 1i*V(2:2:n)].';
y.Ic = [I(1:2:n) + 1i*I(2:2:n)].';

y.S1 = y.Vc .* conj(y.Ic);
y.S  = sum(y.S1);
