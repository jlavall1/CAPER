function [y,varargout] = sg_plotVoltageProfile(varargin)
% Plot feeder voltage profile
% function y = sg_plotVoltageProfile(varargin)
%
% Plot feeder voltage profile using OpenDSS provided feeder data, i.e.,
% feeder has energy meter that triggers distance computations.
% Uses distances and pu-voltage to plot tree of feeder voltages; based on
% per phase information.
%
% Input: 'data'    	... feeder data structure
%        'limits'  	... upper and lower pu-limit (default = [1.05 0.95]),
%					   	use empty [] to not plot
%        'figno'   	... figure number for plot (default = 13)
%        'vfeeder' 	... min/max voltages added as horizontal lines (default: [])
%        'index'   	... index into result matrices/vectors to be plotted
%					   	(e.g., for animations), default: 1
%        'step'    	... step taken in index, default: 0, and 'index'
%					   	determines points shown, otherwise index(1):step:index(end)
%        'animate' 	... 0-no/1-yes
%        'pause'   	... pause time in seconds between plot updates
%        'vscale'  	... absolute y-min/y-max used for plot(s), default: [],
%					   	automatically scaling to zoom-in
%        'avi'    	... frame rate for exporting animation to avi-file, 0-no avi,
%					   	default: 0, file name: 'Feeder_vprofile.avi'
%        'clf'     	... clear figure before starting to plot, default: 1
%        'c'       	... add capacitor status (off/on) along feeder, color code:
%					   	red-on/energized, green-off/not energized
%       'cdistoff' 	... shifting x-position of capacitor labels by this amount,
%					   	default: zero-vector
%      'cdistoffy'	... shifting y-position of capacitor labels by this amount,
%						default: zero-vector
%        'units'   	... units used to plot distance ('mi' or 'km', default: 'mi')
%
% Outputs: y.        ... data (results) structure
%          .titlestr ... plot title string
%          .EventLog ... Event log entries
%
% Examples:
%   	y = sg_plotVoltageProfile('data',r); % plots one (first) power flow results
%		...
%   	y = sg_plotVoltageProfile('data',r,'vscale',[0.94 1.1],'animate',1,...
%							'index',1:5:r.n,'figno',10); % show every 5th results
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under
% Awards DE-EE0002063 and DE-EE0004682
%

%% defaults
figNo    = 13;  % figure number
vlimits  = [0.95 1.05]; % target voltage limits (lower and upper, e.g., ANSI)
vfeeder  = []; % absolute max/min of feeder voltages (add to plot as lines)
index    = 1;  % index into results matrix to be plotted (use, e.g., to down-sample in animations)
istep    = 0;  % step taken in index (between two plots), 0: use 'index'
animate  = 1;  % animate figures (allows for pause between updates)
pausev   = 0;  % time to pause (s)
vscale   = []; % default: zoom-in close, otherwise: [y-min y-max]
aviRate  = 0;  % save sequence of figure as avi-video file if >0, frame rate per second (e.g., 4)
clfFlag  = 1;  % clear plot
y.titlestr = ''; % automatically created for structure-based plots
Cstatus  = 0;  % >0: add capacitors' status to plots, 1-OpenDSS Name, 2-Integer Index
CDistOff = []; % custom offset to x-location (distance) coordinates
CDistOffy= []; % custom offset to y-location (distance) coordinates
EventLog = {}; % Event messages
fname    = '';  % path\file name to data file (*.mat)
units    = 'mi';
km2mi    = 1/1.609344; % converts km to miles
unitsf   = km2mi;
DispFlag = 1;
nout = max(nargout,1)-1;
if nout == 1
    varargout{1} = [];
end
r = [];

% Plot options: line styles for phases a, b, c
linecolor   = {'b' 'r' 'k'};
linestyle   = {'-' '-' '-'};
linecolorLV = {'k' 'k' 'k'};
linestyleLV = {':' ':' ':'};
ConCol      = [1 0 0];  % red (energized)
CoffCol     = [0 .5 0]; % green (not energized)

cudir = pwd;

%% Options
if isempty(varargin)
    %% Use GUI in case of no data
    fsc = filesep;
    % select data file using GUI
    [filename,pathname] = uigetfile('*.mat','Select a SUNGRIN results file ...');
    if pathname == 0
        if DispFlag
            fprintf('\n You must select a valid (*.mat) file! Terminating.\n');
        end
        EventLog{end+1} = 'Error: No valid data file selected.';
        y.EventLog = EventLog;
        return
    end
    cudir = pwd;
    cd(pathname);
    r = load(filename);
    %     cd(cudir);
    strName = fieldnames(r);
    r = r.(strName{1});
elseif isstruct(varargin{1})
    r = varargin{1};
    if length(varargin) > 1
        varargin = varargin(2:end);
    else
        varargin = [];
    end
end
if ~isempty(varargin)
    for ii=1:2:length(varargin)
        switch lower(varargin{ii})
            case 'figno'
                figNo = varargin{ii+1};
            case 'data'
                r = varargin{ii+1};
            case 'fname'
                fname = varargin{ii+1};
            case 'limits'
                vlimits = varargin{ii+1};
            case 'vfeeder'
                vfeeder = varargin{ii+1};
            case 'index'
                index = varargin{ii+1};
            case 'step'
                istep = varargin{ii+1};
            case 'animate'
                animate = varargin{ii+1};
            case 'pause'
                pausev = varargin{ii+1};
            case 'vscale'
                vscale = varargin{ii+1};
            case 'avi'
                aviRate = varargin{ii+1};
            case 'clf'
                clfFlag = varargin{ii+1};
            case 'c'
                Cstatus = varargin{ii+1};
            case 'cdistoff'
                CDistOff = varargin{ii+1};
            case 'cdistoffy'
                CDistOffy = varargin{ii+1};
            case 'dispflag'
                DispFlag = varargin{ii+1};
            case 'units'
                switch varargin{ii+1}
                    case {'mi','mile','miles'}
                        unitsf = km2mi;
                    case 'km'
                        unitsf   = 1;
                    otherwise
                        unitsf   = km2mi;
                end
            otherwise
                fprintf(' Unknown option: %s\n',varargin{ii});
        end
    end
end
% load data if necessary
if ~isempty(fname)
    try
        r = load(fname,'-mat');
        strName = fieldnames(r);
        r = r.(strName{1});
    catch
        le = lasterror;
        EventLog{end+1} = sprintf('Error: Plotting voltage profile:  %s, File: %s, Line: %.0f',le.message,le.stack(1).name,le.stack(1).line);
        if DispFlag
            fprintf('\n Error loading results data:\n  %s\n',le.message);
            fprintf('\n File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
        end
        y.EventLog = EventLog;
        r.EventLog = EventLog;
        if nout == 1
            varargout{1} = r;
        end
        return
    end
end
if isempty(r)
    % e.g., empty string --> load using GUI
    fsc = filesep;
    % select data file using GUI
    [filename,pathname] = uigetfile('*.mat','Select a SUNGRIN results file ...');
    if pathname == 0
        if DispFlag
            fprintf('\n You must select a valid (*.mat) file! Terminating.\n');
        end
        EventLog{end+1} = 'Error: No valid data file selected.';
        y.EventLog = EventLog;
        return
    end
    cd(pathname);
    r = load(filename);
    strName = fieldnames(r);
    r = r.(strName{1});
    
    fsc = filesep;
    if isfield(r,'Feeder')
        if isstruct(r.Feeder)
            idx = strfind(r.Feeder.model,fsc);
            if ~isempty(idx)
                r.Feeder.model = [pathname r.Feeder.model(idx(end)+1:end)];
            else
                r.Feeder.model = [pathname r.Feeder.model];
            end
        elseif ischar(r.Feeder)
            r.Feeder.model = [pathname r.Feeder];
        end
        if isfield(r.Feeder,'profile')
            idx = strfind(r.Feeder.profile,fsc);
            if isempty(idx)
                FeederProfile = r.Feeder.profile;
            else
                FeederProfile = r.Feeder.profile(idx(end)+1:end);
            end
        else
            r.Feeder.profile = '';
        end
    else
        r.Feeder.model = [pathname filename];
    end
    %     cd(cudir);
end

% x-shift in case capacitors are displayed
if Cstatus && isempty(CDistOff)
    CDistOff  = zeros(size(r.Capacitor.State.val,2),1);
end
if Cstatus && isempty(CDistOffy)
    CDistOffy = zeros(size(r.Capacitor.State.val,2),1);
end
if size(r.Capacitor.busidx,1)>1 & length(CDistOff)==1
    CDistOff  = ones(size(r.Capacitor.State.val,2),1)*CDistOff;
end
if size(r.Capacitor.busidx,1)>1 & length(CDistOffy)==1
    CDistOffy  = ones(size(r.Capacitor.State.val,2),1)*CDistOffy;
end

%% Plot voltages along feeder
figure(figNo)
set(gcf,'Name','Voltage profile');
% result taken from OpenDSS/MATLAB study, data in structure format
Th = floor(r.t/3600); % expecting time in seconds, starting at zero
Tm = round((r.t-Th*3600)/60);
idx = find(Tm >= 60);
if ~isempty(idx)
    Th(idx) = Th(idx) + 1;
    Tm(idx) = Tm(idx) - 60;
end
Td = floor(Th/24)+1;
Th = Th - 24*(Td-1);
if clfFlag
    clf;
    xlims = [];
    ylims = [];
else
    xlims = xlim;
    ylims = ylim;
end
if aviRate
    fsc = filesep;
    idxF = strfind(r.Feeder.model,fsc);
    idxE = strfind(r.Feeder.model,'.');
    if ~isempty(idxF)
        pathname = r.Feeder.model(1:idxF(end)-1);
        aviName = [r.Feeder.model(idxF(end)+1:idxE(end)-1) '.avi'];
    else
        pathname = pwd;
        aviName = [r.Feeder.model(1:idxE(end)-1) '.avi'];
    end
    cudir = pwd;
    cd(pathname);
    % aviName = 'Feeder_vprofile.avi';
    if ~isempty(dir(aviName))
        aviName = [aviName(1:end-4) '_' datestr(now,'yyyymmddTHHMMSS') '.avi'];
    end
    vidObj = VideoWriter([pathname fsc aviName],'Motion JPEG AVI');
    vidObj.FrameRate = aviRate; % frames per second
    open(vidObj);
end
if istep ~= 0
    if length(index) > 1
        % use index bounds
        index = index(1):istep:index(end);
    else
        % index(1) until end
        index = index(1):istep:r.n;
    end
end
for jj = 1:length(index)
    hold on
    % Lines
    V11pu = abs(r.Line.V11.val(index(jj),:)) ./ r.Line.kVbase / 1e3;
    V12pu = abs(r.Line.V12.val(index(jj),:)) ./ r.Line.kVbase / 1e3;
    V21pu = abs(r.Line.V21.val(index(jj),:)) ./ r.Line.kVbase / 1e3;
    V22pu = abs(r.Line.V22.val(index(jj),:)) ./ r.Line.kVbase / 1e3;
    V31pu = abs(r.Line.V31.val(index(jj),:)) ./ r.Line.kVbase / 1e3;
    V32pu = abs(r.Line.V32.val(index(jj),:)) ./ r.Line.kVbase / 1e3;
    for ii = 1:length(V11pu)
        if r.Line.S1.incl(ii)
            phase = 1;
            if ~r.Line.LVflag(ii)
                plot([r.Line.Distance(1,ii) r.Line.Distance(2,ii)]*unitsf,...
                    [V11pu(ii) V12pu(ii)],...
                    'LineWidth',2,'Color',linecolor{phase},'LineStyle',linestyle{phase})
            else
                plot([r.Line.Distance(1,ii) r.Line.Distance(2,ii)]*unitsf,...
                    [V11pu(ii) V12pu(ii)],...
                    'LineWidth',2,'Color',linecolorLV{phase},'LineStyle',linestyleLV{phase})
            end
        end
        if r.Line.S2.incl(ii)
            phase = 2;
            if ~r.Line.LVflag(ii)
                plot([r.Line.Distance(1,ii) r.Line.Distance(2,ii)]*unitsf,...
                    [V21pu(ii) V22pu(ii)],...
                    'LineWidth',2,'Color',linecolor{phase},'LineStyle',linestyle{phase})
            else
                plot([r.Line.Distance(1,ii) r.Line.Distance(2,ii)]*unitsf,...
                    [V21pu(ii) V22pu(ii)],...
                    'LineWidth',2,'Color',linecolorLV{phase},'LineStyle',linestyleLV{phase})
            end
        end
        if r.Line.S3.incl(ii)
            phase = 3;
            if ~r.Line.LVflag(ii)
                plot([r.Line.Distance(1,ii) r.Line.Distance(2,ii)]*unitsf,...
                    [V31pu(ii) V32pu(ii)],...
                    'LineWidth',2,'Color',linecolor{phase},'LineStyle',linestyle{phase})
            else
                plot([r.Line.Distance(1,ii) r.Line.Distance(2,ii)]*unitsf,...
                    [V31pu(ii) V32pu(ii)],...
                    'LineWidth',2,'Color',linecolorLV{phase},'LineStyle',linestyleLV{phase})
            end
        end
    end
    % Transformers
    for ii = 1:length(r.Transformer.x1.val)
        if r.Transformer.S1.incl(ii)
            phase = 1;
            if ~r.Transformer.LVflag(ii)
                plot([r.Transformer.Distance(ii) r.Transformer.Distance(ii)]*unitsf,...
                    [abs(r.Transformer.V11.val(index(jj),ii))/r.Transformer.kVbase(1,ii)/1e3 abs(r.Transformer.V12.val(index(jj),ii))/r.Transformer.kVbase(2,ii)/1e3],...
                    'LineWidth',2,'Color',linecolor{phase},'LineStyle',linestyle{phase})
            else
                % at least one bus at low-voltage (< 1kV)
                plot([r.Transformer.Distance(ii) r.Transformer.Distance(ii)]*unitsf,...
                    [abs(r.Transformer.V11.val(index(jj),ii))/r.Transformer.kVbase(1,ii)/1e3 abs(r.Transformer.V12.val(index(jj),ii))/r.Transformer.kVbase(2,ii)/1e3],...
                    'LineWidth',2,'Color',linecolorLV{phase},'LineStyle',linestyleLV{phase})
            end
        end
        if r.Transformer.S2.incl(ii)
            phase = 2;
            if ~r.Transformer.LVflag(ii)
                plot([r.Transformer.Distance(ii) r.Transformer.Distance(ii)]*unitsf,...
                    [abs(r.Transformer.V21.val(index(jj),ii))/r.Transformer.kVbase(1,ii)/1e3 abs(r.Transformer.V22.val(index(jj),ii))/r.Transformer.kVbase(2,ii)/1e3],...
                    'LineWidth',2,'Color',linecolor{phase},'LineStyle',linestyle{phase})
            else
                % at least one bus at low-voltage (< 1kV)
                plot([r.Transformer.Distance(ii) r.Transformer.Distance(ii)]*unitsf,...
                    [abs(r.Transformer.V21.val(index(jj),ii))/r.Transformer.kVbase(1,ii)/1e3 abs(r.Transformer.V22.val(index(jj),ii))/r.Transformer.kVbase(2,ii)/1e3],...
                    'LineWidth',2,'Color',linecolorLV{phase},'LineStyle',linestyleLV{phase})
            end
        end
        if r.Transformer.S3.incl(ii)
            phase = 3;
            if ~r.Transformer.LVflag(ii)
                plot([r.Transformer.Distance(ii) r.Transformer.Distance(ii)]*unitsf,...
                    [abs(r.Transformer.V31.val(index(jj),ii))/r.Transformer.kVbase(1,ii)/1e3 abs(r.Transformer.V32.val(index(jj),ii))/r.Transformer.kVbase(2,ii)/1e3],...
                    'LineWidth',2,'Color',linecolor{phase},'LineStyle',linestyle{phase})
            else
                % at least one bus at low-voltage (< 1kV)
                plot([r.Transformer.Distance(ii) r.Transformer.Distance(ii)]*unitsf,...
                    [abs(r.Transformer.V31.val(index(jj),ii))/r.Transformer.kVbase(1,ii)/1e3 abs(r.Transformer.V32.val(index(jj),ii))/r.Transformer.kVbase(2,ii)/1e3],...
                    'LineWidth',2,'Color',linecolorLV{phase},'LineStyle',linestyleLV{phase})
            end
        end
    end
    % plot boundaries
    xmin = min(r.Bus.V1.distance)*unitsf;
    xmax = max(r.Bus.V1.distance)*unitsf;
    ymin = min(min(min(r.Bus.V1pu.val(index(jj),:)),min(r.Bus.V2pu.val(index(jj),:))),min(r.Bus.V3pu.val(index(jj),:)));
    ymax = max(max(max(r.Bus.V1pu.val(index(jj),:)),max(r.Bus.V2pu.val(index(jj),:))),max(r.Bus.V3pu.val(index(jj),:)));
    
    if ~isempty(vlimits)
        % add lines to indicate voltage limits (lower and upper)
        plot([xmin xmax], [vlimits(2) vlimits(2)],...
            'LineWidth',2,'Color','g','LineStyle',':')
        plot([xmin xmax], [vlimits(1) vlimits(1)],...
            'LineWidth',2,'Color','g','LineStyle',':')
    end
    if ~isempty(vfeeder)
        % add lines (to indicate absolute max./min. voltages)
        plot([xmin xmax], [vfeeder(1) vfeeder(1)],...
            'LineWidth',2,'Color','m','LineStyle',':')
        plot([xmin xmax], [vfeeder(2) vfeeder(2)],...
            'LineWidth',2,'Color','m','LineStyle',':')
    end
    xlim([xmin-.1 xmax+.1])
    if isempty(vscale) && isempty(xlims)
        % 'zoom-in' to just below and above plotted (rounded to 0.01 pu) data
        ylim([floor(ymin*100)/100 ceil(ymax*100)/100])
    elseif isempty(vscale)
        % 'zoom-in' but consider limits of existing plot
        ylim([min(floor(ymin*100)/100,ylims(1)) max(ceil(ymax*100)/100,ylims(2))])
    else
        % custom y-axis limits
        ylim(vscale)
    end
    % Capacitor status
    if Cstatus
        yl = ylim;
        xl = xlim;
        for ii = 1:size(r.Capacitor.busidx,1)
            if r.Capacitor.State.val(index(jj),ii)
                if Cstatus == 1
                    text((r.Bus.V1.distance(r.Capacitor.busidx(ii,1))+CDistOff(ii))*unitsf,yl(2)-diff(yl)/18+diff(yl)*CDistOffy(ii),r.Capacitor.names{ii},'Color',ConCol);
                elseif Cstatus == 2
                    text((r.Bus.V1.distance(r.Capacitor.busidx(ii,1))+CDistOff(ii))*unitsf,yl(2)-diff(yl)/18+diff(yl)*CDistOffy(ii),['C' num2str(ii)],'Color',ConCol);
                end
            else
                if Cstatus == 1
                    text((r.Bus.V1.distance(r.Capacitor.busidx(ii,1))+CDistOff(ii))*unitsf,yl(2)-diff(yl)/18+diff(yl)*CDistOffy(ii),r.Capacitor.names{ii},'Color',CoffCol);
                elseif Cstatus == 2
                    text((r.Bus.V1.distance(r.Capacitor.busidx(ii,1))+CDistOff(ii))*unitsf,yl(2)-diff(yl)/18+diff(yl)*CDistOffy(ii),['C' num2str(ii)],'Color',CoffCol);
                end
            end
        end
    end
    hold off
    xlabel('distance (mi)')
    ylabel('p.u. voltage, Phase A-blue, B-red, C-black')
    y.titlestr = ['Day ' num2str(Td(index(jj))) ':  ' num2str(Th(index(jj)),'%02.0f') ':' num2str(Tm(index(jj)),'%02.0f')];
    title(y.titlestr)
    grid on
    drawnow;
    if aviRate
        % add/save current figure to movie
        try
            currFrame = getframe(gcf);
            writeVideo(vidObj,currFrame);
        catch
            le = lasterror;
            EventLog{end+1} = sprintf('Error: Saving video: %s, File: %s, Line: %.0f',le.message,le.stack(1).name,le.stack(1).line);
            close(vidObj);
            y.EventLog = EventLog;
            return
        end
    end
    if animate && (jj~=length(index))
        % multiple figures/animation: allow for pause between plot updates
        if pausev
            pause(pausev)
        end
        clf;
    end
end

% close avi-file
if aviRate
    close(vidObj);
    EventLog{end+1} = ['Saved ' aviName ' to ' pathname '.'];
end
y.EventLog = EventLog;
r.EventLog = EventLog;
if nout == 1
    varargout{1} = r;
end