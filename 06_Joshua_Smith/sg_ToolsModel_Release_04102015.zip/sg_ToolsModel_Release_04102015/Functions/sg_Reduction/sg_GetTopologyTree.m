function f = sg_GetTopologyTree(varargin)
% Determines topology tree.
% function f = sg_GetTopologyTree(DSSObj)
%
% Iterates over feeder circuit to determine topology tree (a linked list
% of branches).
%
% Inputs: DSSObj 	... OpenDSS COM interface connection
%
% Outputs: f. 	... structure with the following fields:
%     		.Tree. 	... Linked list with entries
%          		.ID         ... unique identifier
%          		.BranchName ... name (taken from OpenDSS model)
%          		.Level      ... number of steps from root (substation)
%          		.PrevID     ... previous branch ID (always: one and only one)
%          		.NextID     ... next branch ID(s) (may be multiple)
%          		.pBus       ... upstream branch bus (towards root)
%          		.nBus       ... downstream branch bus (towards leaves)
%     		.status ... success flag (0/1)
%
%  Examples:
%    f = sg_GetTopologyTree(DSSObj); % get tree for the model active in OpenDSS
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682


% Input arguments and defaults
DSSObj  = varargin{1};

% Init
DispFlag = 0;    % turn on/off console display (0/1)
f = struct();    % returning a structure
f.status = 0;    % success status (0/1)
f.EventLog = {}; % keeps track of warning/error messages (cell array)
f.Tree   = [];   % topology tree

% Iterate over OpenDSS Topology
T = DSSObj.ActiveCircuit.Topology;
T.First;

% First element: root (VSource-object)
ID = 1;
f.Tree(ID).ID = ID;
f.Tree(ID).BranchName  = T.BranchName;
f.Tree(ID).IsLine = ~isempty(strfind(lower(T.BranchName),'line'));
f.Tree(ID).ActiveLevel = T.ActiveLevel;
f.Tree(ID).PrevID = [];
f.Tree(ID).NextID = [];
f.Tree(ID).pBus = [];
f.Tree(ID).nBus = [];
Bus = DSSObj.ActiveCircuit.CktElements(f.Tree(ID).BranchName).BusNames{1};
idx = strfind(Bus,'.');
if ~isempty(idx)
    Bus = Bus(1:idx(1)-1);
end
f.Tree(1).nBus = Bus;
% Link all others, leaves will have .NextID = []
while T.Next > 0
    ID = ID + 1;
    f.Tree(ID).ID = ID;
    f.Tree(ID).BranchName  = T.BranchName;
    f.Tree(ID).IsLine = ~isempty(strfind(lower(T.BranchName),'line'));
    f.Tree(ID).ActiveLevel = T.ActiveLevel;
    f.Tree(ID).PrevID = [];
    f.Tree(ID).NextID = [];
    f.Tree(ID).pBus = [];
    f.Tree(ID).nBus = [];
    
    % remove node/wire info
    Buses = DSSObj.ActiveCircuit.CktElements(f.Tree(ID).BranchName).BusNames;
    for ii = 1:length(Buses)
        idx = strfind(Buses{ii},'.');
        if ~isempty(idx)
            Buses{ii} = Buses{ii}(1:idx(1)-1);
        end
    end
    
    % search for connection at another element/bus
    IDp = ID - 1;
    while (f.Tree(ID).ActiveLevel - f.Tree(IDp).ActiveLevel)~=1 || ~any(strcmpi(f.Tree(IDp).nBus,Buses))
        IDp = IDp - 1;
    end
    f.Tree(IDp).NextID = [f.Tree(IDp).NextID ID];
    f.Tree(ID).PrevID  = [f.Tree(ID).PrevID  IDp];
    bidx = strcmpi(f.Tree(IDp).nBus,Buses);
    f.Tree(ID).pBus = Buses(bidx);
    f.Tree(ID).nBus = Buses(~bidx);
end
f.status = 1;