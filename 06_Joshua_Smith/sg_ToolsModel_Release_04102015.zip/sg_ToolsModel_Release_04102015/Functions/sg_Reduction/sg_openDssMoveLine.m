function r = sg_openDssMoveLine(varargin)
% Move Line (connection) from a bus to another.
% function r = sg_openDssMoveLine(DSSObj,bus)
%
% Move a line from a bus to another. Impedance of line shifted across is added to the 
% reconnected line segment and need for additional load-generation pairs to compensate 
% for associated voltage drops. 
% Note:
% Solution only valid for one data point, i.e., cannot be combined/used to scale profile data
% correctly.
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%    busName - a string (cell array) indicating the name of the original 
%              line connection point
%    busNameTo - cell array (list of cell arrays) of buses to connect to
%                (where line is moved to) and line To-buses. After reconnected,
%                the line section will connect these two buses and the
%                original busName may be removed from the circuit.
%
%  Options:
%  Returns [r]
%    r - a structure with the following fields
%      Actions - a string of the actions taken.
%      ActComment - a string summarizing the actions taken.
%      ActUnDo - a string of actions that reverse the actions taken.
%
%  Examples:
%    r = sg_openDssMoveLine(DSSObj,{{'Bus101'} {'Bus100' 'Bus102'});
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% February 15, 2015

% Defaults / choices
% load scaling
ch.Scaling.posseq = 1;  % positive sequence impedance
ch.Scaling.ims    = 2;  % impedance matrix scalar

Scaling   = ch.Scaling.posseq;

% Input arguments
DSSObj    = varargin{1};
busName   = varargin{2}{1};
busNameTo = varargin{2}{2};
if length(varargin{2}) > 2
    for ii = 3:2:length(varargin)
        switch lower(varargin{ii})
            case 'scaling'
                Scaling = varargin{ii+1};
        end
    end
end

% conver to lower case bus names and remove node-info
for ii = 1:length(busName)
    idx = strfind(busName{ii},'.');
    if ~isempty(idx)
        busName{ii} = lower(busName{ii}(1:idx(1)-1));
    else
        busName{ii} = lower(busName{ii});
    end
end
for ii = 1:length(busNameTo)
    for jj = 1:2
        idx = strfind(busNameTo{ii}{jj},'.');
        if ~isempty(idx)
            busNameTo{ii}{jj} = lower(busNameTo{ii}{jj}(1:idx(1)-1));
        else
            busNameTo{ii}{jj} = lower(busNameTo{ii}{jj});
        end
    end
end


% Init
DispFlag   = 0;    % turn on/off console display (0/1)
r  = struct();     % returning a structure
r.status   = 0;    % success status (0/1)
r.EventLog = {};   % keeps track of warning/error messages (cell array)
r.Actions  = {};   % actions taken
r.ActComment = {}; % summary of actions taken
r.ActUnDo  = {};   % undo-actions

%% Globals
global INFO_LINE INFO_TR INFO_LOAD INFO_GEN

if isempty(INFO_LINE)
    INFO_LINE = sg_openDssGetLineInfo(DSSObj);
end
if isempty(INFO_LOAD)
    INFO_LOAD = sg_openDssGetLoadInfo(DSSObj);
end


% handle one bus at a time
for ii = 1:length(busName)
    % Bus info
    % nominal voltage (phase)
    BuskV   = DSSObj.ActiveCircuit.Buses(busName{ii}).kVBase;
    BuskVps = DSSObj.ActiveCircuit.Buses(busName{ii}).CplxSeqVoltages(3:4);
    BuskVpsFrom = sqrt(sum(BuskVps.^2));
    BuskVps = DSSObj.ActiveCircuit.Buses(busNameTo{ii}{1}).CplxSeqVoltages(3:4);
    BuskVpsTo(1) = sqrt(sum(BuskVps.^2));
    BuskVps = DSSObj.ActiveCircuit.Buses(busNameTo{ii}{2}).CplxSeqVoltages(3:4);
    BuskVpsTo(2) = sqrt(sum(BuskVps.^2));
    
    i11 = sg_rgrep(['^' busName{ii}],INFO_LINE.Bus(:,1));      % current location
    i12 = sg_rgrep(['^' busName{ii}],INFO_LINE.Bus(:,2));
    i21 = sg_rgrep(['^' busNameTo{ii}{1}],INFO_LINE.Bus(:,1)); % New bus #1
    i22 = sg_rgrep(['^' busNameTo{ii}{1}],INFO_LINE.Bus(:,2));
    i31 = sg_rgrep(['^' busNameTo{ii}{2}],INFO_LINE.Bus(:,1)); % New bus #2
    i32 = sg_rgrep(['^' busNameTo{ii}{2}],INFO_LINE.Bus(:,2));
     % only include enabled lines
    enabi11 = find(INFO_LINE.enab(i11) > 0);
    enabi12 = find(INFO_LINE.enab(i12) > 0);
    enabi21 = find(INFO_LINE.enab(i21) > 0);
    enabi22 = find(INFO_LINE.enab(i22) > 0);
    enabi31 = find(INFO_LINE.enab(i31) > 0);
    enabi32 = find(INFO_LINE.enab(i32) > 0);
    i11 = i11(enabi11);
    i12 = i12(enabi12);
    i21 = i21(enabi21);
    i22 = i22(enabi22);
    i31 = i31(enabi31);
    i32 = i32(enabi32);
    % Identify lines
    ElemIdx = [];
    Element = {};
    % Identify 1st line
    if ~isempty(i11) && ~isempty(i22),
        LineNo = intersect(i11,i22);
        if ~isempty(LineNo)
            % bus found at From- and To-ends for at least one line: in case
            % of parallel lines: assuming they have the same
            % characteristics
            ElemIdx(1) = LineNo(1);
            Element{1} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(1)}]).Name;
            ElemBusFromTo(1,:) = [1 2];
        end
    end
    if ~isempty(i12) && ~isempty(i21),
        LineNo = intersect(i12,i21);
        if ~isempty(LineNo)
            ElemIdx(1) = LineNo(1);
            Element{1} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(1)}]).Name;
            ElemBusFromTo(1,:) = [2 1];
        end
    end
    BusTokV(1) = DSSObj.ActiveCircuit.Buses(busNameTo{ii}{1}).kVBase*sqrt(3);
    if isempty(Element)
        r.EventLog{end+1} = sprintf('Warning: Reducing circuit: Could not find 1st line to shift across: %s - %s.',...
            busName{ii},busNameTo{ii}{1});
        if DispFlag, fprintf('%s\n',r.EventLog{end}); end;
        return
    end
    % Identify 2nd line
    if ~isempty(i11) && ~isempty(i32),
        LineNo = intersect(i11,i32);
        if ~isempty(LineNo)
            % bus found at From- and To-ends for at least one line
            ElemIdx(2) = LineNo(1);
            Element{2} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(2)}]).Name;
            ElemBusFromTo(2,:) = [1 2];
        end
    end
    if ~isempty(i12) && ~isempty(i31),
        LineNo = intersect(i12,i31);
        if ~isempty(LineNo)
            ElemIdx(2) = LineNo(1);
            Element{2} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(2)}]).Name;
            ElemBusFromTo(2,:) = [2 1];
        end
    end
    BusTokV(2) = DSSObj.ActiveCircuit.Buses(busNameTo{ii}{2}).kVBase*sqrt(3);
    if length(Element)~=2
        r.EventLog{end+1} = sprintf('Warning: Reducing circuit: Could not find 2nd line (which is to be reconnected): %s - %s.',...
            busName{ii},busNameTo{ii}{2});
        if DispFlag, fprintf('%s\n',r.EventLog{end}); end;
        return
    end
    % Identify remaining lines (to consider flows that need to be
    % redistributed): needs update for different phasing
	% based on power flow current: approximation, could also trace connected loads (ratings) to be accurate
    LineRemain1 = setdiff(i11,ElemIdx); % at To-End
    LineRemain2 = setdiff(i12,ElemIdx); % at From-End
    Ic = 0;
    for jj = 1:length(LineRemain1)
        % add all flows: assuming constant current loads
        I = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{LineRemain1(jj)}]).Currents;
        Ic = Ic + I(1:2:end/2) + 1i*I(2:2:end/2);
    end
    for jj = 1:length(LineRemain2)
        % add all flows: assuming constant current loads
        I = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{LineRemain2(jj)}]).Currents;
        Ic = Ic + I(1:2:end/2) + 1i*I(2:2:end/2);
    end
    Sc = BuskV * [1; exp(1i*-2*pi/3); exp(1i*2*pi/3)] .* Ic'; % outflowing kVA
    
    % compensate for moved line section: add as load/generation to
    % busName/busnameTo(1)
    I = DSSObj.ActiveCircuit.CktElements(Element{2}).Currents;
    if ElemBusFromTo(2,1) == 1
        Ic0 = I(1:2:end/2) + 1i*I(2:2:end/2);
    else
        Ic0 = I(end/2+1:2:end) + 1i*I(end/2:2:end);
    end
    Sc0 =  BuskV * [1; exp(1i*-2*pi/3); exp(1i*2*pi/3)] .* Ic0';
    
    % in case of load at busName: need to add to moved section (considering
    % impedance ratio)
    idx =  sg_rgrep(['^' busName{ii}],INFO_LOAD.Bus); % load at current location
    PL = 0;
    QL = 0;
    if ~isempty(idx)
        PL = sum(INFO_LOAD.kW(idx));
        QL = sum(INFO_LOAD.kVAR(idx));
    end
    % Get wire-node relationship for From and To ends (in
    % this order --> used below)
    for kk = 1:2 % line segments
        for jj = 1:2 % buses
            Bus = DSSObj.ActiveCircuit.CktElements(Element{kk}).Bus{ElemBusFromTo(kk,jj)};
            idx = strfind(Bus,'.');
            if isempty(idx)
                % default wire-phase connections
                WirePhase{kk,jj} = 1:DSSObj.ActiveCircuit.CktElements(Element{kk}).NumPhases;
            else
                % use existing wire-phase info
                WirePhase{kk,jj} = str2num(strrep(Bus(idx(1):end),'.',' '));
            end
        end
    end
    
    % line-impedance information
%     llen = INFO_LINE.llen(ElemIdx(1)) + INFO_LINE.llen(ElemIdx(2));
    llen  = sg_sumLengths([INFO_LINE.llen(ElemIdx(1)) INFO_LINE.llen(ElemIdx(2))],{INFO_LINE.unit{ElemIdx(1)} INFO_LINE.unit{ElemIdx(2)}});
    for jj = 1:2
        zm{jj} = (INFO_LINE.rmatrix{ElemIdx(jj)} + 1i*INFO_LINE.xmatrix{ElemIdx(jj)}) * INFO_LINE.llen(ElemIdx(jj));
        z1{jj} = (INFO_LINE.r1{ElemIdx(jj)} + 1i*INFO_LINE.x1{ElemIdx(jj)}) * INFO_LINE.llen(ElemIdx(jj));
    end
    if ~isempty(z1{1}) & ~isempty(z1{2})
        z1sum = (z1{1} + z1{2})/llen.l;
        z1str = sg_Matrix2String(z1sum);
    else
        z1sum = [];
        z1str = '';
    end
    zmsum = (zm{1} + zm{2})/llen.l;
    zmstr  = sg_Matrix2String(zmsum); % new line
    zmstr2 = sg_Matrix2String(INFO_LINE.rmatrix{ElemIdx(jj)} + 1i*INFO_LINE.xmatrix{ElemIdx(jj)}); % original line
    
    
    % find info for reconnecting 2nd line (shifted across 1st line)
    node = [];
    if length(WirePhase{2,1}) <= length(WirePhase{1,1})
        for kk = 1:length(WirePhase{2,1})
            idx = find(WirePhase{2,1}(kk) == WirePhase{1,1}); % determine wire at connecting node
            node(kk) = WirePhase{1,2}(idx);                   % node for this wire at new bus
        end
    else
        for kk = 1:length(WirePhase{1,1})
            idx = find(WirePhase{2,1} == WirePhase{1,1}(kk));
            node(kk) = WirePhase{1,2}(idx);
        end
        % appending remaining connections
        node = [node WirePhase{2,1}(length(WirePhase{1,1})+1:end)];
    end
    NewBus = [busNameTo{ii}{1} sprintf('.%.0f',node)];
    
    % changes: first bus name and line impedance
    if ~isempty(z1str.re) 
        str1 = sprintf('edit Line.%s bus%.0f=%s r1=%s x1=%s length=%f units=%s',INFO_LINE.Name{ElemIdx(2)}, ElemBusFromTo(2,1),...
            NewBus, z1str.re, z1str.im,llen.l,llen.u);
        str2 = sprintf('edit Line.%s bus%.0f=%s r1=%f x1=%f length=%f units=%s',INFO_LINE.Name{ElemIdx(2)}, ElemBusFromTo(2,1),...
            [busName{ii} sprintf('.%.0f',WirePhase{1,1})], INFO_LINE.r1{ElemIdx(2)},INFO_LINE.x1{ElemIdx(2)},...
            INFO_LINE.llen(ElemIdx(2)),INFO_LINE.unit{ElemIdx(2)});
        if sum(Sc) ~= 0
            S = sum(Sc) * z1{1} / (z1{1} + z1{2});
        end
    else
        str1 = sprintf('edit Line.%s bus%.0f=%s rmatrix=%s xmatrix=%s length=%f units=%s',INFO_LINE.Name{ElemIdx(2)}, ElemBusFromTo(2,1),...
            NewBus, zmstr.re, zmstr.im,llen.l,llen.u);
        str2 = sprintf('edit Line.%s bus%.0f=%s rmatrix=%s xmatrix=%s length=%f units=%s',INFO_LINE.Name{ElemIdx(2)}, ElemBusFromTo(2,1),...
            [busName{ii} sprintf('.%.0f',WirePhase{1,1})], zmstr2.re, zmstr2.im, INFO_LINE.llen(ElemIdx(2)),INFO_LINE.unit{ElemIdx(2)});
        if sum(Sc) ~= 0
            S = sum(Sc) * inv(zm{1} + zm{2}) * zm{1};
        end
    end
    DSSObj.Text.Command = str1;
    r.Actions{end+1} = str1;
    r.ActComment{end+1} = sprintf('Move line: Line.%s: from bus%.0f=%s to bus%.0f=%s',...
        INFO_LINE.Name{ElemIdx(2)},ElemBusFromTo(2,1),busName{ii},ElemBusFromTo(1,2),NewBus);
    r.ActUnDo{end+1} = str2;
    % update global data (only setup for r1/x1 for now)
    INFO_LINE.Bus{ElemIdx(2),ElemBusFromTo(2,1)} = NewBus;
    INFO_LINE.r1{ElemIdx(2)} = real(z1sum);
    INFO_LINE.x1{ElemIdx(2)} = imag(z1sum);
    INFO_LINE.llen(ElemIdx(2)) = llen.l;
    INFO_LINE.unit{ElemIdx(2)} = llen.u;
    INFO_LINE.rmatrix{ElemIdx(2)} = [];
    INFO_LINE.xmatrix{ElemIdx(2)} = [];
    INFO_LINE.cmatrix{ElemIdx(2)} = [];
    
    % Note: the following compensates for the moved connection point but
    % only for 3-phase loads (and wye-connected). Also, the compensation is based on the actual
    % power flow and does NOT allow to recompute the profile data, which
    % would require to trace all loads and compute the rated/connected downstream demand.
    %
    % 1. Add additional load-generation pair to compensate for other line sections' flows
    if sum(Sc) ~= 0
        str1 = sprintf('new Load.%s_Sc_p1 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{2}, real(S), imag(S), BuskV*sqrt(3));
        DSSObj.Text.Command = str1;
        r.Actions{end+1} = str1;
        r.ActComment{end+1} = sprintf('Move line: Added load to compensate for other branch flows. Load.%s_Sc_p1 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{2}, real(S), imag(S), BuskV*sqrt(3));
        r.ActUnDo{end+1} = ['Disable Load.' INFO_LINE.Name{ElemIdx(2)} '_Sc_p1'];
        str1 = sprintf('new Load.%s_Sc_p2 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{1}, -real(S), -imag(S), BuskV*sqrt(3));
        DSSObj.Text.Command = str1;
        r.Actions{end+1} = str1;
        r.ActComment{end+1} = sprintf('Move line: Added new (negative) load to compensate for other branch flows. Load.%s_Sc_p2 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{1}, -real(S), -imag(S), BuskV*sqrt(3));
        r.ActUnDo{end+1} = ['Disable Load.' INFO_LINE.Name{ElemIdx(2)} '_Sc_p2'];
        % add to global data
		% warning: MATLAB changed syntax of how to add to cell arrays, the following worked in 2011a but not in 2013a

        INFO_LOAD.Name(end+[1:2]) = {[INFO_LINE.Name{ElemIdx(2)} '_Sc_p1'] [INFO_LINE.Name{ElemIdx(2)} '_Sc_p2']}
        INFO_LOAD.Bus(end+[1:2])  = {busNameTo{ii}{2} busNameTo{ii}{1}};
        INFO_LOAD.NumPhases(end+[1:2])   = [3 3];
        INFO_LOAD.kW(end+[1:2])   = [1 -1]*real(S);
        INFO_LOAD.kVAR(end+[1:2]) = [1 -1]*imag(S);
        INFO_LOAD.kV(end+[1:2])   = [1  1]*BuskV*sqrt(3);
        INFO_LOAD.pf(end+[1:2])   = [0 0];
        INFO_LOAD.kVA(end+[1:2])  = [0 0];
        INFO_LOAD.XFkVA(end+[1:2])  = [0 0];
        INFO_LOAD.conn(end+[1:2]) = {'wye' 'wye'};
        INFO_LOAD.enab(end+[1:2]) = [1 1];
        INFO_LOAD.Ratio(end+[1:2]) = [1 1];
        LoadCount = length(INFO_LOAD.Ratio);
        INFO_LOAD.iNameIdx(end+[1:2]) = LoadCount+[1:2];
    end
    % 2. Compensate for moved connection: add additional load-generation
    % pair to compensate for additional voltage drop due to original line connection 
    if sum(Sc0) ~= 0
        str1 = sprintf('new Load.%s_Sc_p3 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busName{ii}, real(sum(Sc0)), imag(sum(Sc0)), BuskV*sqrt(3));
        DSSObj.Text.Command = str1;
        r.Actions{end+1} = str1;
        r.ActComment{end+1} = sprintf('Move line: Added new load to compensate for moved branch. Load.%s_Sc_p3 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busName{ii}, real(sum(Sc0)), imag(sum(Sc0)), BuskV*sqrt(3));
        r.ActUnDo{end+1} = ['Disable Load.' INFO_LINE.Name{ElemIdx(2)} '_Sc_p3'];
        str1 = sprintf('new Load.%s_Sc_p4 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{1}, -real(sum(Sc0)), -imag(sum(Sc0)), BuskV*sqrt(3));
        DSSObj.Text.Command = str1;
        r.Actions{end+1} = str1;
        r.ActComment{end+1} = sprintf('Move line: Added new (negative) load to compensate for moved branch. Load.%s_Sc_p4 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{1}, -real(sum(Sc0)), -imag(sum(Sc0)), BuskV*sqrt(3));
        r.ActUnDo{end+1} = ['Disable Load.' INFO_LINE.Name{ElemIdx(2)} '_Sc_p4'];
        % add to global data
        INFO_LOAD.Name(end+[1:2]) = {[INFO_LINE.Name{ElemIdx(2)} '_Sc_p3'] [INFO_LINE.Name{ElemIdx(2)} '_Sc_p4']};
        INFO_LOAD.Bus(end+[1:2])  = {busName{ii} busNameTo{ii}{1}};
        INFO_LOAD.NumPhases(end+[1:2])   = [3 3];
        INFO_LOAD.kW(end+[1:2])   = [1 -1]*real(sum(Sc0));
        INFO_LOAD.kVAR(end+[1:2]) = [1 -1]*imag(sum(Sc0));
        INFO_LOAD.kV(end+[1:2])   = [1  1]*BuskV*sqrt(3);
        INFO_LOAD.pf(end+[1:2])   = [0 0];
        INFO_LOAD.kVA(end+[1:2])  = [0 0];
        INFO_LOAD.XFkVA(end+[1:2])  = [0 0];
        INFO_LOAD.conn(end+[1:2]) = {'wye' 'wye'};
        INFO_LOAD.enab(end+[1:2]) = [1 1];
        INFO_LOAD.Ratio(end+[1:2]) = [1 1];
        LoadCount = length(INFO_LOAD.Ratio);
        INFO_LOAD.iNameIdx(end+[1:2]) = LoadCount+[1:2];
    end
    % 3. In case of connected load at busName: add to moved section at To-end
    % and compensating generation part at new connection point
    if PL~=0 | QL~=0
        SL = (PL + 1i*QL) * z1{1} / (z1{1} + z1{2});
        str1 = sprintf('new Load.%s_Sc_p5 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{2}, real(SL), imag(SL), BuskV*sqrt(3));
        DSSObj.Text.Command = str1;
        r.Actions{end+1} = str1;
        r.ActComment{end+1} = sprintf('Move line: Added new load to compensate for load at original bus. Load.%s_Sc_p5 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{2}, real(SL), imag(SL), BuskV*sqrt(3));
        r.ActUnDo{end+1} = ['Disable Load.' INFO_LINE.Name{ElemIdx(2)} '_Sc_p5'];
        str1 = sprintf('new Load.%s_Sc_p6 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{1}, -real(SL), -imag(SL), BuskV*sqrt(3));
        DSSObj.Text.Command = str1;
        r.Actions{end+1} = str1;
        r.ActComment{end+1} = sprintf('Move line: Added new (negative) load to compensate for load at original bus. Load.%s_Sc_p6 bus=%s mode=5 kW=%s kVAR=%s phases=3 conn=wye kV=%f',...
            INFO_LINE.Name{ElemIdx(2)}, busNameTo{ii}{1}, -real(SL), -imag(SL), BuskV*sqrt(3));
        r.ActUnDo{end+1} = ['Disable Load.' INFO_LINE.Name{ElemIdx(2)} '_Sc_p6'];
        % add to global data
        INFO_LOAD.Name(end+[1:2]) = {[INFO_LINE.Name{ElemIdx(2)} '_Sc_p5'] [INFO_LINE.Name{ElemIdx(2)} '_Sc_p6']};
        INFO_LOAD.Bus(end+[1:2])  = {busNameTo{ii}{2} busNameTo{ii}{1}};
        INFO_LOAD.NumPhases(end+[1:2]) = [3 3];
        INFO_LOAD.kW(end+[1:2])   = [1 -1]*real(SL);
        INFO_LOAD.kVAR(end+[1:2]) = [1 -1]*imag(SL);
        INFO_LOAD.kV(end+[1:2])   = [1  1]*BuskV*sqrt(3);
        INFO_LOAD.pf(end+[1:2])   = [0 0];
        INFO_LOAD.kVA(end+[1:2])  = [0 0];
        INFO_LOAD.XFkVA(end+[1:2])= [0 0];
        INFO_LOAD.conn(end+[1:2]) = {'wye' 'wye'};
        INFO_LOAD.enab(end+[1:2]) = [1 1];
        INFO_LOAD.Ratio(end+[1:2])= [1 1];
        LoadCount = length(INFO_LOAD.Ratio);
        INFO_LOAD.iNameIdx(end+[1:2]) = LoadCount+[1:2];
    end
end
r.status = 1;
end