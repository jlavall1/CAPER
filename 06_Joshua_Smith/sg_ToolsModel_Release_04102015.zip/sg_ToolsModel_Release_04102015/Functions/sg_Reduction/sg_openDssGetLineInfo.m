function y = sg_openDssGetLineInfo(varargin)

%  Get Line Information
%  function y = sg_openDssGetLineInfo(DSSObj)
%
%  Returns information about line sections in an openDSS model.
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%  Options;
%    Lines - Either a cell array of strings or a single string.  If a cell
%      array, this is interpreted as a list of line names for which to get
%      information.  If a string, this is interpreted as a regular
%      expression pattern used to match line names.  The default value is the
%      regular expression '.*', indicating that information for all lines
%      should be returned. 
%  Returns y
%    y - a structure of information.
%
%  Examples:
%    y=sg_openDSSGetLineInfo(DSSObj);
%    y=sg_openDSSGetLineInfo(DSSObj,'Lines',{'Line101','Line102'});
%    y=sg_openDSSGetLineInfo(DSSObj,'Lines','Line\d+');
%
%   Note:  This function is still under development.
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% January, 2015

DSSObj = varargin{1};

opts = struct('Lines','.*');
opts = sg_updateOpts(opts,varargin,1);

y = struct();

if (iscell(opts.Lines) == 0)
    lv = DSSObj.ActiveCircuit.Lines.AllNames;
    i1 = sg_rgrep(opts.Lines,lv);
    opts.Lines = lv(i1);
end

N = length(opts.Lines);
y.Name = opts.Lines;
y.Bus = repmat({'Bus1'},N,2);
y.NumPhases = zeros(1,N);
y.r1 = cell(1,N);
y.x1 = cell(1,N);
y.r0 = cell(1,N);
y.x0 = cell(1,N);
y.C1 = cell(1,N);
y.C0 = cell(1,N);
y.rmatrix = cell(1,N);
y.xmatrix = cell(1,N);
y.cmatrix = cell(1,N);
y.llen = zeros(1,N);
y.unit = cell(1,N);
y.enab = zeros(1,N);

for n = 1:length(opts.Lines)
    x = DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]);
    y.enab(n) = str2num(DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('enabled').Val);
    y.Bus{n,1} = x.BusNames{1};
    y.Bus{n,2} = x.BusNames{2};
    y.NumPhases(n) = x.NumPhases;
    y.r1{n} = str2num(DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('r1').Val);
    y.x1{n} = str2num(DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('x1').Val);
    y.r0{n} = str2num(DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('r0').Val);
    y.x0{n} = str2num(DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('x0').Val);
    y.C1{n} = str2num(DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('c1').Val);
    y.C0{n} = str2num(DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('c0').Val);
    rm = DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('rmatrix').Val;
    xm = DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('xmatrix').Val;
    cm = DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('cmatrix').Val;
    y.rmatrix{n} = sg_LT2matrix(rm);
    y.xmatrix{n} = sg_LT2matrix(xm);
    y.cmatrix{n} = sg_LT2matrix(cm);
    y.llen(n) = str2num(DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('length').Val);
    y.unit{n} = DSSObj.ActiveCircuit.CktElements(['Line.' y.Name{n}]).Properties('units').Val;
end
return

function val = sg_LT2matrix(LTstring)
% function val = sg_LT2matrix(LTstring)
% Convert lower-triangular matrix text string into numerical array.
LTstring = LTstring(2:end-1);
idx = [0 strfind(LTstring,'|') length(LTstring)];
n   = length(idx)-1;
val = zeros(n,n);

for ii = 2:n+1
    val(ii-1,1:ii-1) = str2num(LTstring(idx(ii-1)+1:idx(ii)-1));
end
val = val + val.' - diag(diag(val));
return

