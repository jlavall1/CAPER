function y = sg_getObjectProperties(varargin)
% Return name/value pairs of OpenDSS-object properties.
% function y = sg_getObjectProperties(DSSObj,'Element.Name',varargin)
%
% Inputs: DSSObj		... OpenDSS COM interface connection
%    	  Element.Name 	... Fully qualified name of object
%    	  'Choice' 		... 'all' (default): returns all properties
%             				'basic': returns pre-selected (basic) properties
%    	  'VChoice'		... 'all': all properties
%           'ne'  		... only return properties that are not empty (have not been set)
%
% Outputs: y		... results structure containing:
%     	   .nv 		... structure array of name-value pairs
%     	   .nvstr	... all property name=value pairs in one string
%     	   .flag	... function success flag (0/1)
% 
% Example Call(s):
%      y = sg_getObjectProperties(DSSObj,'load.name','choice','basic');
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%% Setup
y.flag = 0;
% Parameters
if ~isempty(varargin)
    DSSObj    = varargin{1};
    ObjName   = lower(varargin{2});
end

% Handle options: Property choice
enum.PC.All   = 1;
enum.PC.Basic = 2;
Choice = 'all';
% Property value choice
enum.PVC.All = 1;
enum.PVC.NotEmpty = 2;
VChoice = 'ne';

if length(varargin) > 2
    for ii = 3:2:length(varargin)
        switch lower(varargin{ii})
            case 'choice'
                Choice = varargin{ii+1};
            case 'vchoice'
                VChoice = varargin{ii+1};
        end
    end
end
switch lower(Choice)
    case {'all'}
        Choice = enum.PC.All;
    case {'basic'}
        Choice = enum.PC.Basic;
    otherwise
        Choice = enum.PC.All;
end
switch lower(VChoice)
    case {'all'}
        VChoice = enum.PVC.All;
    case {'ne','notempty'}
        VChoice = enum.PVC.NotEmpty;
    otherwise
        VChoice = enum.PVC.NotEmpty;
end

%% Output
y = struct();
y.nv    = [];   % structure array of name-value pairs
y.nvstr = ' ';  % all in one string

% Default/list of basic properties returned
enum.BP.Transformers = 1;
enum.BP.Loads        = 2;
enum.BP.Lines        = 3;
BasicProp{enum.BP.Transformers} = {'phases' 'windings' 'Rneut' 'Xneut' 'buses' 'conns' 'kVs' ...
    'kVAs' 'taps' 'Xhl' 'Xht' 'Xlt' '%loadloss' '%noloadloss' 'MaxTap' ...
    'MinTap' 'NumTaps' '%imag' '%Rs' 'XfmrCode' 'enabled'};
BasicProp{enum.BP.Loads} = {'phases' 'bus1' 'kV' 'kW' 'pf' 'model' 'yearly' 'daily' 'duty' ...
    'growth' 'conn' 'kvar' 'Rneut' 'Xneut' 'status' 'class' 'Vminpu'  'Vmaxpu' 'xfkVA' ...
     'enabled' 'ZIPV'}; %'allocationfactor' 'kVA'
BasicProp{enum.BP.Lines} = {'bus1' 'bus2' 'length' 'phases' 'r1' 'x1' ...
    'r0' 'x0' 'C1' 'C0' 'rmatrix' 'xmatrix' 'cmatrix' 'Switch' 'Rg' 'Xg' 'rho' 'units' ...
    'enabled'};
    
%% Iterate over properties
ObjInst  = DSSObj.ActiveCircuit.CktElements(ObjName);
PropList = ObjInst.AllPropertyNames;
idx = strfind(ObjName,'.');
if ~isempty(idx)
    ObjType = lower(ObjName(1:idx(1)-1));
else
   error(['Need fully qualified object name: ' ObjName]); 
end
count = 0;
for ii = 1:length(PropList)
    % in case of 'basic:' check if to be returned
    if Choice == enum.PC.Basic
        switch ObjType
            case 'transformer'
                selected = sum(strcmpi(BasicProp{enum.BP.Transformers},PropList{ii}));
            case 'load'
                selected = sum(strcmpi(BasicProp{enum.BP.Loads},PropList{ii}));
            otherwise
                error(['Object type not handled: ' ObjType]);
        end
    elseif Choice == enum.PC.All
        selected = 1;
    end
    % in case of 'NotEmpty:' check for value
    if selected
        if VChoice == enum.PVC.NotEmpty
            value = ObjInst.Properties(PropList{ii}).val;
            if isempty(value)
                selected = 0;
            end
        end
    end
    if selected
        count = count + 1;
        y.nv(count).name  = PropList{ii};
        y.nv(count).value = ObjInst.Properties(PropList{ii}).Val;
        if ~isempty(str2num(y.nv(count).value))
            y.(PropList{ii}) = str2num(y.nv(count).value);
        else
            y.(PropList{ii}) = ObjInst.Properties(PropList{ii}).Val;
        end
        if ~isempty(y.nv(count).value)
            if isnumeric(y.nv(count).value)
                y.nvstr = [nvstr ' ' PropList{ii} '=(' num2str(y.nv(count).value) ')'];
            else
                y.nvstr = [y.nvstr ' ' PropList{ii} '=(' y.nv(count).value ')'];
            end
        end
    end
end
y.flag = 1;