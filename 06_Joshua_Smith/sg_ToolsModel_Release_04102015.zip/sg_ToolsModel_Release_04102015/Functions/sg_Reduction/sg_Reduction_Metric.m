function r = sg_Reduction_Metric(varargin)
%  Performs model reduction on an OpenDSS model using a specified metric.
%  r = sg_Reduction_Metric(DSSObj)
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%  Options:
%    metric - A function handle to a function of the form
%      r=metric(DSSObj,bus) (where DSSObj is a connection to an OpenDSS
%      object, and bus is a string specifying a bus to be evaluated for
%      removal, and the function returns a positive real value, with the
%      value closest to zero indicating the best candidate for removal)
%      (default = '', in which case a default metric is used).
%    solve - An integer specifying whether an attempt should be made to
%      solve the power flow after each reduction (1) or not (0) (default=0).
%  Options for bus retention:
%   1- Buses - buses explicitly identified by the user (a cell array of
%   names) - DEFAULT = {}
%   2- BusExpr - buses with names matching a regular expression provided by
%   the user (could be used with naming conventions to easily select
%   portions of a feeder that need to be retained) - DEFAULT = '', empty
%   string means no specific expression
%   3- CBkvar - capacitor bank rating threshold (buses having capacitor banks
%   with ratings higher than the threshold are retained)(default = -1,
%   indicating that this option is not used)
%   4- TapXFMR - retain buses with tap changing transformer (default=0)
%   5- TransKVA - transformer KVA rating threshold (buses having
%   ratings higher than the threshold are retained)
%   5a- TransKV - transformer KV rating threshold (buses having
%   ratings higher than the threshold are retained)
%   6- GenKVA - generator kVA rating threshold (buses having generator units
%   with ratings higher than the threshold are retained)
%   7- LoadKVA - load KVA rating (buses with load KVA higher than the
%   threshold are retained)
%   8- ThreePhaseBus - option to retain all three phase buses
%   9- kVRating - all buses with voltage rating above this threshold are
%   retained
%   10- VRatingEnd - threshold voltage rating (buses at the end of a feeder
%   segment with voltage rating above this threshold will be retained)
%   11- puVDev - per unit voltage deviation (all buses within the solved
%   model having voltages that differ from nominal by more than this
%   threshold value will be retained)
%   12- target - traget folder path
%
%  Returns:
%    r.     ... results structure
%    .actions  - a cell array of strings of operations.
%    .status   - success flag (0/1)
%    .EventLog - event messages
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
% 
% January 2015

% clear/reset global vars
clear global INFO_LOAD INFO_GEN INFO_LINE INFO_TR INFO_LOADRATIO

% defaults and options
DSSObj=varargin{1};
opts = struct('metric','','solve',0,'BusExpr','','CBkvar',-1,'TapXFMR',0,'TransKVA',1e12,'TransKV',1e12,'GenKVA',1e12,...
    'LoadKVA',1e12,'ThreePhaseBus',0,'kVRating',1e12,'VRatingEnd',1e12,'puVDev',1e12,'target',[pwd filesep 'ReducedModel']);
opts.Buses={};
opts = sg_updateOpts(opts,varargin,1);

if(ischar(opts.metric))
    opts.metric = @sg_voltageDropMetric; 
end
opts.Buses=sg_capply(@lower,opts.Buses);

txt={};
r.status = 0;
r.EventLog = {};

busvee=opts.Buses;

%  Get a list of candidate and excluded buses.
[busve, busvc] = sg_IDkeyBuses(DSSObj,'Buses',busvee,'BusExpr',opts.BusExpr,...
      'CBkvar',opts.CBkvar,'TapXFMR',opts.TapXFMR,'TransKVA',opts.TransKVA,...
      'TransKV',opts.TransKV,'GenKVA',opts.GenKVA,'LoadKVA',opts.LoadKVA,...
      'ThreePhaseBus',opts.ThreePhaseBus,'kVRating',opts.kVRating,...
      'VRatingEnd',opts.VRatingEnd,'puVDev',opts.puVDev);

% Iterate over candidates
while(length(busvc)>0)
    %  Assess the suitability of each bus according to the selected metric.
    vv=-1*ones(1,length(busvc));
    for(n=1:length(busvc))
         vv(n)=opts.metric(DSSObj,busvc{n});
    end   
    
    %  Attempt to remove a bus.
    if(any(vv>=0))
        i1=find(vv>=0);
        vvmin=min(vv(i1));
        ii=min(find(vv==vvmin));
        i1=ii;
        busv=sg_findAdjacentBuses(DSSObj,busvc{i1});
        if(length(busv)==2)
            fprintf(1,'Removing bus %s.\n',busvc{i1});
            r1=sg_openDssSplitBus(DSSObj,{busvc(i1),{busv}});
            txt{end+1}=r1.Actions;
            r1=sg_openDssRemoveBus(DSSObj,busvc(i1));
            txt{end+1}=r1.Actions;
        elseif(length(busv)==1)
            fprintf(1,'Removing bus %s.\n',busvc{i1});
            r1=sg_openDssMoveElements(DSSObj,{busvc(i1),busv});
            txt{end+1}=r1.Actions;
            r1=sg_openDssRemoveBus(DSSObj,busvc(i1));
            txt{end+1}=r1.Actions;
        else
            %  Move the buse from the list of candidates to the list of
            %  explicitly excluded buses.
            fprintf(1,'Removing bus %s from consideration.\n',busvc{i1});
            busvee{end+1}=busvc{i1};
        end
        %  Remove the bus from the list of candidates.
        ix1=1:length(busvc);
        ix2=sg_rgrep(busvc{i1},busvc,'caseSensistive',0);
        ix1(ix2)=[];
        busvc=busvc(ix1);
    end
    
    if(opts.solve==1);
        r=sg_runOpenDSSSim('','DSSObj',DSSObj);
    end
    
    % Update list of candidate and excluded buses.
    [busve, busvc] = sg_IDkeyBuses(DSSObj,'Buses',busvee,'BusExpr',opts.BusExpr,...
      'CBkvar',opts.CBkvar,'TapXFMR',opts.TapXFMR,'TransKVA',opts.TransKVA,...
      'TransKV',opts.TransKV,'GenKVA',opts.GenKVA,'LoadKVA',opts.LoadKVA,...
      'ThreePhaseBus',opts.ThreePhaseBus,'kVRating',opts.kVRating,...
      'VRatingEnd',opts.VRatingEnd,'puVDev',opts.puVDev);    
end

%% Save feeder circuit
DSSObj.Text.Command=['save circuit dir=' opts.target];
% reopen master.dss and add base voltage information
DSSObj.Text.Command = 'get voltagebases';
val = DSSObj.Text.Result;
fn  = sprintf('%s%sMaster.DSS',opts.target,filesep);
str1 = sprintf('\n\nSet voltagebases = %s\nCalcv\n\n',val);
fid = fopen(fn,'a');
if fid ~= -1
    fprintf(fid,str1);
    fclose(fid);
else
    % feeder not saved
    r.EventLog{end+1} = 'Could not save reduced circuit.';
end

r.status  = 1;
r.actions = txt;
