function r = sg_voltageDropMetric(varargin)
% Evaluates a bus for the voltage drop metric.
% r=sg_voltageDropMetric(DSSObj,bus)
% 
% Evaluates a bus for the voltage drop metric in case it is a radial bus,
% i.e., has only one or two connections. 
%
% Parameters:
%    DSSObj - OpenDSS COM interface connection
%    bus - a string indicating the name of a bus for which the metric is to
%      be evaluated.
%
% Output:
%    r ... metric, i.e., max(|S||Z1|,|S||Z2|) or -1 if not applicable
%
% Example: r = sg_voltageDropMetric(DSSObj,'Bus101');
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
% 
% January 2015

DSSObj = varargin{1};
bus = varargin{2};

r = -1;

%%  Find the number or lines connected to the bus and
%  verify that the bus is a radial bus (only 1 or 2 connected branches).
%% Globals
global INFO_LINE INFO_LOAD
if isempty(INFO_LINE)
    INFO_LINE = sg_openDssGetLineInfo(DSSObj);
end
if isempty(INFO_LOAD)
    INFO_LOAD = sg_openDssGetLoadInfo(DSSObj);
end

i1 = find(INFO_LINE.enab==1);

i1l = sg_rgrep(['^' bus],INFO_LINE.Bus(i1,1),'caseSensitive',0);
i2l = sg_rgrep(['^' bus],INFO_LINE.Bus(i1,2),'caseSensitive',0);

Nlines = length(i1l)+length(i2l);

if((Nlines)>2)
    fprintf(1,'\nError: The specified bus, Bus %s, has more than two branches.\n\n',bus);
    return;
end

%%  Find the maximum impedance of the connected lines.

nv = [INFO_LINE.Name(i1(i1l)); INFO_LINE.Name(i1(i2l))];

nm = nv{1};
str1 = sprintf('Line.%s.R1',nm);
R1 = str2num(sg_getParam(DSSObj,str1));
str1 = sprintf('Line.%s.X1',nm);
X1 = str2num(sg_getParam(DSSObj,str1));

Z = abs(R1+1i*X1);

if(length(nv)>1)
    nm = nv{2};
    str1 = sprintf('Line.%s.R1',nm);
    R1 = str2num(sg_getParam(DSSObj,str1));
    str1 = sprintf('Line.%s.X1',nm);
    X1 = str2num(sg_getParam(DSSObj,str1));
    Z1 = abs(R1+1i*X1);
    Z = max([Z Z1]);
end

%%  Find the total load on the bus.
Sload = 0;

i1  = sg_rgrep(bus,INFO_LOAD.Bus,'caseSensitive',0);
i1e = find(INFO_LOAD.enab(i1)==1);

if length(i1(i1e)) > 0
    for(n = 1:length(i1(i1e)))
        Sload = Sload + INFO_LOAD.kVA(i1(i1e(n)));
    end
end

r = Sload*Z;