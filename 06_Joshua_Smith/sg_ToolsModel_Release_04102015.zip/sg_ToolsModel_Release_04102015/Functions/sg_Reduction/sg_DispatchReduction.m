function r = sg_DispatchReduction(varargin)
% Master function for model reduction.
% function r = sg_DispatchReduction(varargin)
%
% Sets up model reduction (loads/solves circuit) and dispatches model reduction
% process.
%
% Inputs: para	... 
%         .Model       ... model to be reduced, path/file name
%         .Method      ... reduction method: 'topology'
%         .KeepBuses   ... cell array of bus names
%         .RemoveBuses ... cell array of bus names
%         .KeepConPoints ... 0/1, allow shifting lines/loads if encountering branching point
%         .IDkeyBuses  ... use key bus identification function (0-no, 1-with default settings, 2-custom settings);
%         .TargetFolder   ... folder path for reduced model
%         .ActionFile     ... name of action list file, 'ActionList.txt';
%         .ActionUnDoFile ... name of UnDo-action list file, 'ActionListUnDo.txt';
%         .ActionCommentFile ... name of Action-comment file, 'ActionComments.txt';
%         .ActDisp    ... display action window
%         .profile    ... path-name of associated profile file (.csv or.xlx), output will be a .xls
%         .DispFlag ... command line display flag
%         .fno      ... acttion window (figure) number
%
% Outputs: r	... data (results) structure of reduced model
%          .status ... status (success) flag)
%          .Events ... list of events
%
% Example Call(s):
%       r = sg_DispatchReduction(para);
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%
% February 2015

%% Setup
para = varargin{1};

y.Feeder.model     = para.Model;
if isfield(para,'profile')
    y.Feeder.profile   = para.profile;
else
    y.Feeder.profile   = [];
end
y.Feeder.fnResults = '';
y.Feeder.resultExt = @(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N);

y.EventLog = {};   % keeps track of warning/error messages (cell array)
y.status   = 0;    % power flow solution status (0/1)

%% Open and configure OpenDSS connection
try
    DSSObj = sg_startOpenDSS;
catch
    % in case helper functions are not on the path yet
    startup;
    DSSObj = sg_startOpenDSS;
end

%% Execute model: one power flow
tic
[r,DSSObj] = sg_FeederReductionSetup(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,'resultExt',y.Feeder.resultExt,'profilePoints',-1);
if r.status
    r.Tel = toc;
    r.Feeder = y.Feeder;
else
    return
end

%% Save results
if ~isempty(y.Feeder.fnResults)
    if ~isempty(dir([r.Feeder.fnResults '.mat']))
        r.Feeder.fnResults = [r.Feeder.fnResults '_' datestr(now,'yyyymmddTHHMMSS')];
    end
    save(r.Feeder.fnResults,'r');
end

%% Dispatch model reduction
switch lower(para.Method)
    case 'topology'
        r = sg_Reduction_Topology(DSSObj,para);
    case 'vsensitivity' % defaults to v-sensitivity as metric
        r = sg_Reduction_Metric(DSSObj,'Buses',para.KeepBuses,'Solve',1,'target',para.TargetFolder);
    otherwise
        % noop
end
r.DSSObj = DSSObj;
