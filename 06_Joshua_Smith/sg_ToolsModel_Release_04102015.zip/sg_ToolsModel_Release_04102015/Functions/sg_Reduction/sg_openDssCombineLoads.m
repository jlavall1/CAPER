function r = sg_openDssCombineLoads(varargin)

%  Combine loads of the same type at a bus.
%  function r = sg_CombineLoads(DSSObj,bus)
%
%  Combine loads that are at the same bus and of the same type into a single load.
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%    bus - a string (cell array) indicating the name of buses to be checked for loads.
%  Options:
%  Returns r
%    r - a structure with the following fields
%      LoadBuses - cell array of buses with loads
%      LoadNames - cell arrays of loads names, which are at the same bus
%                 (aligned with LoadBuses)
%      LoadNewNames - cell array of names for combined loads
%      Actions - a string of the actions taken.
%      ActComment - a string summarizing the actions taken.
%      ActUnDo - a string of actions that reverse the actions taken.
%
%  Examples:
%    r = sg_openDssCombineLoads(DSSObj');
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% February 18, 2015

% Input arguments and defaults
DSSObj  = varargin{1};
if length(varargin) > 1 && ~isempty(varargin{2})
    busName = lower(varargin{2}); % option to perform only at selected buses
    if isempty(busName{1})
        % in case of empty string
        busName = DSSObj.ActiveCircuit.AllBusNames;
    else
        for ii = 1:length(busName)
            idx = strfind(busName{ii},'.');
            if ~isempty(idx)
                busName{ii} = busName{ii}(1:idx(1)-1);
            end
        end
    end
else
    busName = DSSObj.ActiveCircuit.AllBusNames;
end

% Init
DispFlag = 0;         % turn on/off console display (0/1)
r = struct();         % returning a structure
r.status   = 0;       % success status (0/1)
r.EventLog = {};      % keeps track of warning/error messages (cell array)
r.Actions  = {};      % summary of actions taken
r.ActComment = {};    % action description
r.ActUnDo  = {};      % undo-action
LoadType = struct();  % collected loads data structure
CollLoadCount = 0;     % counts collected loads 
r.CollectedLoads = []; % keeps track of collected loads 

%% Globals
global INFO_LOAD

if isempty(INFO_LOAD)
    INFO_LOAD = sg_openDssGetLoadInfo(DSSObj);
end

if ischar(busName)
    busName{1} = busName;
end
for ii = 1:length(busName)
    % identify loads/buses to be handled
    BusLoadIdx{ii} = sg_rgrep(['^' lower(busName{ii})],INFO_LOAD.Bus);
    % only include enabled loads
    enabIdx = find(INFO_LOAD.enab(BusLoadIdx{ii}) > 0);
    BusLoadIdx{ii} = BusLoadIdx{ii}(enabIdx);
    % active connections found
    BusLoadNo(ii) = length(BusLoadIdx{ii});
end

% Check if any loads were found
if sum(BusLoadNo) == 0
    r.EventLog{end+1} = sprintf('Note: Combine Loads: No loads found.');
    if DispFlag,
        fprintf('%s\n',r.EventLog{end});
    end
    return
end

% Check if more than one load at any bus
if max(BusLoadNo) == 1
    r.EventLog{end+1} = sprintf('Note: Combine Loads: Never more than one load at a bus.');
    if DispFlag,
        fprintf('%s\n',r.EventLog{end});
    end
    return
end

% Combine loads
CollectedLoadsCount = 0;
for ii = 1:length(BusLoadIdx)         % for all loads found at a bus
    LoadTypes = 0;
    if length(BusLoadIdx{ii}) > 1 % keep individual loads without any changes
        for jj = 1:BusLoadNo(ii) % for each load at bus
            % keep track of "load types:" same characteristics:
            % no. of wires, phasing, why/delta
            Phases = INFO_LOAD.NumPhases(BusLoadIdx{ii}(jj));
            Bus = INFO_LOAD.Bus{BusLoadIdx{ii}(jj)};
            idx = strfind(Bus,'.');
            if isempty(idx)
                % default node connections: All wires
                Nodes = [1:Phases 0];
                BusName = Bus;
            else
                Nodes = [1:Phases 0];
                m = regexp(Bus(idx(1):end),'(\d+)','match');
                for kk = 1:length(m)
                    Nodes(kk) = str2num(m{kk});
                end
                BusName = Bus(1:idx(1)-1);
            end
            Conn = INFO_LOAD.conn{BusLoadIdx{ii}(jj)};
            kW = INFO_LOAD.kW(BusLoadIdx{ii}(jj));
            kVAR = INFO_LOAD.kVAR(BusLoadIdx{ii}(jj));
            PF = INFO_LOAD.pf(BusLoadIdx{ii}(jj));
            xfkva = INFO_LOAD.XFkVA(BusLoadIdx{ii}(jj));
            kV = INFO_LOAD.kV(BusLoadIdx{ii}(jj));
            
            if LoadTypes > 0
                % compare with already found types
                flag = 0;
                for kk = 1:LoadTypes
                    if LoadType(kk).Phases == Phases && ...
                            strcmpi(LoadType(kk).BusName,BusName) && ...
                            length(LoadType(kk).Nodes) == length(Nodes) && ...
                            sum(LoadType(kk).Nodes==Nodes) == length(Nodes) && ...
                            strcmpi(LoadType(kk).Conn,Conn) && ...
                            LoadType(kk).kV == kV
                        % found match: combine
                        LoadType(kk).kW = LoadType(kk).kW + kW;
                        LoadType(kk).kVAR = LoadType(kk).kVAR + kVAR;
                        LoadType(kk).xfkva = LoadType(kk).xfkva + xfkva;
                        if INFO_LOAD.iNameIdx(BusLoadIdx{ii}(jj)) <= INFO_LOAD.N % do not consider entries for load-gen pairs of 'move link'
                            LoadType(kk).Ratio(INFO_LOAD.iNameIdx(BusLoadIdx{ii}(jj))) = ...
                                LoadType(kk).Ratio(INFO_LOAD.iNameIdx(BusLoadIdx{ii}(jj))) + INFO_LOAD.Ratio(BusLoadIdx{ii}(jj));
                        end
                        % disable
                        str1 = sprintf('Disable load.%s',INFO_LOAD.Name{BusLoadIdx{ii}(jj)});
                        DSSObj.Text.Command = str1;
                        r.ActComment{end+1} = sprintf('Combine loads: Disabled load.%s after adding to load.%s at bus %s.',...
                            INFO_LOAD.Name{BusLoadIdx{ii}(jj)},LoadType(kk).Name,LoadType(kk).BusName);
                        r.Actions{end+1} = str1;
                        r.ActUnDo{end+1} = sprintf('Enable load.%s',INFO_LOAD.Name{BusLoadIdx{ii}(jj)});
                        flag = 1;
						% keeping track of collected loads
			            r.LoadNames{CollectedLoadsCount}{jj} = INFO_LOAD.Name{BusLoadIdx{ii}(jj)};
                        % update global data
                        INFO_LOAD.enab(BusLoadIdx{ii}(jj)) = 0;
                        break;
                    end
                end
                if ~flag
                    % new type
                    LoadTypes = LoadTypes + 1;
                    LoadType(LoadTypes).Name = [busName{ii} '_Sum_' num2str(LoadTypes)];
                    LoadType(LoadTypes).BusName = busName{ii};
                    LoadType(LoadTypes).Phases = Phases;
                    LoadType(LoadTypes).Bus = Bus;
                    idx = strfind(Bus,'.');
                    if isempty(idx)
                        % default node connections: All wires
                        Nodes = [1:Phases 0];
                    else
                        Nodes = [1:Phases 0];
                        m = regexp(Bus(idx(1):end),'(\d+)','match');
                        for kk = 1:length(m)
                            Nodes(kk) = str2num(m{kk});
                        end
                    end
                    LoadType(LoadTypes).Nodes = Nodes;
                    LoadType(LoadTypes).Conn = Conn;
                    LoadType(LoadTypes).kW = kW;
                    LoadType(LoadTypes).kVAR = kVAR;
                    LoadType(LoadTypes).xfkva = xfkva;
                    LoadType(LoadTypes).model = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('model').val);
                    LoadType(LoadTypes).Vminpu = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('Vminpu').val);
                    LoadType(LoadTypes).Vmaxpu = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('Vmaxpu').val);
                    LoadType(LoadTypes).kV = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('kV').val);
                    LoadType(LoadTypes).ZIPV = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('ZIPV').val);
                    % LoadType(LoadTypes).Ratio = zeros(1,DSSObj.ActiveCircuit.Loads.Count);
                    LoadType(LoadTypes).Ratio = zeros(1,INFO_LOAD.N); % expecting index only to original loads
                    if INFO_LOAD.iNameIdx(BusLoadIdx{ii}(jj)) <= INFO_LOAD.N
                        LoadType(LoadTypes).Ratio(INFO_LOAD.iNameIdx(BusLoadIdx{ii}(jj))) = INFO_LOAD.Ratio(BusLoadIdx{ii}(jj));
                    end
                    % disable
                    str1 = sprintf('Disable load.%s',INFO_LOAD.Name{BusLoadIdx{ii}(jj)});
                    DSSObj.Text.Command = str1;
                    r.ActComment{end+1} = sprintf('Combine loads: Disabled load.%s after adding to load.%s_%.0f at bus %s.',...
                        INFO_LOAD.Name{BusLoadIdx{ii}(jj)},LoadType(LoadTypes).Name,LoadTypes,LoadType(LoadTypes).BusName);
                    r.Actions{end+1} = str1;
                    r.ActUnDo{end+1} = sprintf('Enable load.%s',INFO_LOAD.Name{BusLoadIdx{ii}(jj)});
					% keeping track of collected loads
				    CollectedLoadsCount = CollectedLoadsCount + 1;
				    r.LoadBuses{CollectedLoadsCount} = LoadType(LoadTypes).BusName;
			        r.LoadNames{CollectedLoadsCount}{jj} = INFO_LOAD.Name{BusLoadIdx{ii}(jj)};
				    r.LoadNewNames{CollectedLoadsCount} = LoadType(LoadTypes).Name;
                    % update global data
                    INFO_LOAD.enab(BusLoadIdx{ii}(jj)) = 0;
                end
            else
                % first
                LoadTypes = LoadTypes + 1;
                LoadType(LoadTypes).Name = [busName{ii} '_Sum_' num2str(LoadTypes)];
                LoadType(LoadTypes).BusName = busName{ii};
                LoadType(LoadTypes).Phases = Phases;
                LoadType(LoadTypes).Bus = Bus;
                idx = strfind(Bus,'.');
                if isempty(idx)
                    % default node connections: All wires
                    Nodes = [1:Phases 0];
                else
                    Nodes = [1:Phases 0];
                    m = regexp(Bus(idx(1):end),'(\d+)','match');
                    for kk = 1:length(m)
                        Nodes(kk) = str2num(m{kk});
                    end
                end
                LoadType(LoadTypes).Nodes = Nodes;
                LoadType(LoadTypes).Conn = Conn;
                LoadType(LoadTypes).kW = kW;
                LoadType(LoadTypes).kVAR = kVAR;
                LoadType(LoadTypes).xfkva = xfkva;
                LoadType(LoadTypes).model = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('model').val);
                LoadType(LoadTypes).Vminpu = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('Vminpu').val);
                LoadType(LoadTypes).Vmaxpu = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('Vmaxpu').val);
                LoadType(LoadTypes).kV = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('kV').val);
                LoadType(LoadTypes).ZIPV = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{BusLoadIdx{ii}(jj)}]).Properties('ZIPV').val);
                %LoadType(LoadTypes).Ratio = zeros(1,DSSObj.ActiveCircuit.Loads.Count);
                LoadType(LoadTypes).Ratio = zeros(1,INFO_LOAD.N); % expecting index only to original loads
                if INFO_LOAD.iNameIdx(BusLoadIdx{ii}(jj)) <= INFO_LOAD.N
                    LoadType(LoadTypes).Ratio(INFO_LOAD.iNameIdx(BusLoadIdx{ii}(jj))) = INFO_LOAD.Ratio(BusLoadIdx{ii}(jj));
                end
                % disable
                str1 = sprintf('Disable load.%s',INFO_LOAD.Name{BusLoadIdx{ii}(jj)});
                DSSObj.Text.Command = str1;
                r.ActComment{end+1} = sprintf('Combine loads: Disabled load.%s after adding to load.%s_%.0f at bus %s.',...
                    INFO_LOAD.Name{BusLoadIdx{ii}(jj)},LoadType(LoadTypes).Name,LoadTypes,LoadType(LoadTypes).BusName);
                r.Actions{end+1} = str1;
                r.ActUnDo{end+1} = sprintf('Enable load.%s',INFO_LOAD.Name{BusLoadIdx{ii}(jj)});
				% keeping track of collected loads
				CollectedLoadsCount = CollectedLoadsCount + 1;
				r.LoadBuses{CollectedLoadsCount} = LoadType(LoadTypes).BusName;
			    r.LoadNames{CollectedLoadsCount}{jj} = INFO_LOAD.Name{BusLoadIdx{ii}(jj)};
				r.LoadNewNames{CollectedLoadsCount} = LoadType(LoadTypes).Name;
                % update global data
                INFO_LOAD.enab(BusLoadIdx{ii}(jj)) = 0;
            end
        end
        % Add collected loads to model
        for jj = 1:LoadTypes
            CollLoadCount = CollLoadCount + 1;
            str1 = sprintf('new load.%s bus=%s phases=%.0f conn=%s kV=%f xfkva=%f kW=%f kvar=%f model=%.0f Vminpu=%f Vmaxpu=%f ZIPV=[%s] enabled=true',...
                LoadType(jj).Name,LoadType(jj).Bus,LoadType(jj).Phases,LoadType(jj).Conn,LoadType(jj).kV,...
                LoadType(jj).xfkva,LoadType(jj).kW,LoadType(jj).kVAR,LoadType(jj).model,LoadType(jj).Vminpu,LoadType(jj).Vmaxpu,num2str(LoadType(jj).ZIPV));
            DSSObj.Text.Command = str1;
            r.ActComment{end+1} = sprintf('Combine loads: New load.%s_%.0f at bus %s.',...
                LoadType(jj).Name,jj,LoadType(jj).BusName);
            r.Actions{end+1} = str1;
            r.ActUnDo{end+1} = sprintf('Disable load.%s_%.0f',LoadType(jj).Name,jj);
            % keep track of collected load data
            r.CollectedLoads(CollLoadCount).LoadType = LoadType(jj);

        end
    end
end
r.status = 1;