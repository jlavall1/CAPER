function ValidationResults = sg_modelResultsComparisonReduction(FullModel,ReducedModel)
% Function to compare full and reduced model.
% function ValidationResults = sg_modelResultsComparisonReduction(FullModel,ReducedModel)
%
% Function computes selected values that allow comparing two models; bet
% applicable to comparing a full to a reduced model. Solves the power flow
% for each model and extract data before computing values that are in
% common, i.e., based on common buses, and determines differences. Note:
% Assuming model's power flow data is comparable.
%
% Parameters:
%   FullModel    ... name of the OpenDSS full model
%   ReducedModel ... name of the OpenDSS reduced model
%
% Ountput:
%   ValidationResults structure
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% February 4, 2015

%% start up openDSS
DSSObj = actxserver('OpenDSSEngine.DSS');
DSSStartOk = DSSObj.Start(0);
DSSText = DSSObj.Text;

if DSSStartOk
    %% set active circuit interface for Full Model
    DSSCircuit = DSSObj.ActiveCircuit;
    DSSText.Command = ['compile ', FullModel];
    DSSText.Command = 'Solve';
    
    ValidationResults = struct();
    ValidationResults.FullModel.SysLosses = DSSCircuit.Losses;
    ValidationResults.FullModel.TotalPower = DSSCircuit.TotalPower;
    % Node Data -----------------------------------------------------------
    nodeNames = DSSCircuit.AllNodeNames;
    nodeVolt = DSSCircuit.AllBusVolts; % complex voltage values at each node
    VnodeMag = zeros(length(nodeNames),1);
    VnodeAng = zeros(length(nodeNames),1);
    k = 1;
    for n = 1:2:(length(nodeVolt)-1)
        V = nodeVolt(n) + 1i*nodeVolt(n+1);
        VnodeMag(k) = abs(V)*1e-3; % KV
        VnodeAng(k) = angle(V)*180/pi; % degree
        k = k+1;
    end
    i1 = rgrep('\w*\.1',nodeNames);
    ValidationResults.FullModel.Node.Node1.names = nodeNames(i1);
    ValidationResults.FullModel.Node.Node1.Vkv = VnodeMag(i1);
    ValidationResults.FullModel.Node.Node1.Vang = VnodeAng(i1);
    
    i1 = rgrep('\w*\.2',nodeNames);
    ValidationResults.FullModel.Node.Node2.names = nodeNames(i1);
    ValidationResults.FullModel.Node.Node2.Vkv = VnodeMag(i1);
    ValidationResults.FullModel.Node.Node2.Vang = VnodeAng(i1);
    
    i1 = rgrep('\w*\.3',nodeNames);
    ValidationResults.FullModel.Node.Node3.names = nodeNames(i1);
    ValidationResults.FullModel.Node.Node3.Vkv = VnodeMag(i1);
    ValidationResults.FullModel.Node.Node3.Vang = VnodeAng(i1);
    
    % Line Data -----------------------------------------------------------
    ValidationResults.FullModel.Line.PQDataHeader = {'PinLine','PoutLine','QinLine','QoutLine'};
    ValidationResults.FullModel.Line.names = DSSCircuit.Lines.AllNames;
    if ~strcmp(ValidationResults.FullModel.Line.names,'NONE')
        nl = length(ValidationResults.FullModel.Line.names);
        ValidationResults.FullModel.NbLines = nl;
        for i = 1:nl
            x = DSSCircuit.CktElements(['Line.',ValidationResults.FullModel.Line.names{i}]);
            xx = x.get('Powers');
            xph = DSSCircuit.Lines.Phases;
            ValidationResults.FullModel.Line.TerminalBus{i,1} = DSSCircuit.Lines.Bus1;
            ValidationResults.FullModel.Line.TerminalBus{i,2} = DSSCircuit.Lines.Bus2;
            PinLine = 0; QinLine = 0;
            PoutLine = 0; QoutLine = 0; % P and Q out of the line are the P and Q into the Bus2 of the line
            if xph<3,
                aaa=1;
            end
            for j = 1:2:2*xph
                PinLine = PinLine + xx(j);
                QinLine = QinLine + xx(j+1);
                PoutLine = PoutLine + abs(xx(j+xph*2));
                QoutLine = QoutLine + abs(xx(j+xph*2+1));
            end
            ValidationResults.FullModel.Line.PQData(i,1) = PinLine;
            ValidationResults.FullModel.Line.PQData(i,2) = PoutLine;
            ValidationResults.FullModel.Line.PQData(i,3) = QinLine;
            ValidationResults.FullModel.Line.PQData(i,4) = QoutLine;
        end
    else
        ValidationResults.FullModel.Line.TerminalBus{1,1} = {};
        ValidationResults.FullModel.Line.TerminalBus{1,2} = {};
        ValidationResults.FullModel.Line.PQData = zeros(1,4);
    end
    ValidationResults.FullModel.Line.LineLosses = DSSCircuit.LineLosses;
    
    % Load data -----------------------------------------------------------
    ValidationResults.FullModel.Load.names = DSSCircuit.Loads.AllNames;
    if ~strcmp(ValidationResults.FullModel.Load.names,'NONE')
        nld = length(ValidationResults.FullModel.Load.names);
        ValidationResults.FullModel.NbLoads = nld;
        for i = 1:nld
            x = DSSCircuit.CktElements(['Load.',ValidationResults.FullModel.Load.names{i}]);
            xx = x.get('phase'); % gets P and Q in each phase (KW and KVar)
            xph = length(xx)/2;
            xbus = x.get('bus');
            ValidationResults.FullModel.Load.Bus{i,1} = xbus{1}(1:length(xbus{1})-8);
            LoadP = 0; LoadQ = 0;
            for j = 1:2:2*xph
                LoadP = LoadP + xx(j);
                LoadQ = LoadQ + xx(j+1);
            end
            ValidationResults.FullModel.Load.PQ(i,1) = LoadP;
            ValidationResults.FullModel.Load.PQ(i,2) = LoadQ;
        end
    else
        ValidationResults.FullModel.Load.Bus = {};
        ValidationResults.FullModel.Load.PQ = 0;
        ValidationResults.FullModel.Load.PQ = 0;
    end
    
    % Capacitor bank data -------------------------------------------------
    ValidationResults.FullModel.Capacitor.names = DSSCircuit.Capacitors.AllNames;
    if ~strcmp(ValidationResults.FullModel.Capacitor.names,'NONE')
        for ii = 1:length(ValidationResults.FullModel.Capacitor.names)
            element = DSSCircuit.CktElements(['capacitor.',ValidationResults.FullModel.Capacitor.names{ii}]);
            buses   = element.get('bus');
            CapBus1 = buses{1};
            CapBus2 = buses{2};
            idx = strfind(CapBus1,'.');
            if ~isempty(idx)
                CapBus1 = CapBus1(1:idx(1)-1);
            end
            ValidationResults.FullModel.Capacitor.Bus{ii} = CapBus1;
            ValidationResults.FullModel.Capacitor.kVar(ii) = str2num(element.Properties('kvar').Val);
        end
    else
        ValidationResults.FullModel.Capacitor.Bus = {};
        ValidationResults.FullModel.Capacitor.kVar = 0;
    end
    % PQ Data in and out of a bus -------------------------------------------
    ValidationResults.FullModel.BusPQData.busNames = DSSCircuit.AllBusNames;
    nb = length(ValidationResults.FullModel.BusPQData.busNames);
    ValidationResults.FullModel.NbBuses = nb;
    for i = 1:nb
        % P(KW) and Q(KVar) out of a bus
        busIndexLine = rgrep(ValidationResults.FullModel.BusPQData.busNames{i},ValidationResults.FullModel.Line.TerminalBus(:,1));
        busIndexLoad = rgrep(ValidationResults.FullModel.BusPQData.busNames{i},ValidationResults.FullModel.Load.Bus); % load added to P and Q out of bus
        ValidationResults.FullModel.BusPQData.Pout(i,1) = sum(ValidationResults.FullModel.Line.PQData(busIndexLine,1)) ...
            + sum(ValidationResults.FullModel.Load.PQ(busIndexLoad,1));
        ValidationResults.FullModel.BusPQData.Qout(i,1) = sum(ValidationResults.FullModel.Line.PQData(busIndexLine,3)) ...
            + sum(ValidationResults.FullModel.Load.PQ(busIndexLoad,2));
        % P(KW) and Q(KVar) into a bus
        if i == 1
            % account for substation bus
            ValidationResults.FullModel.BusPQData.Pin(i,1) = ValidationResults.FullModel.BusPQData.Pout(i,1);
            ValidationResults.FullModel.BusPQData.Qin(i,1) = ValidationResults.FullModel.BusPQData.Qout(i,1);
        else
            busIndexLine = rgrep(ValidationResults.FullModel.BusPQData.busNames{i},ValidationResults.FullModel.Line.TerminalBus(:,2));
            busIndexCap = rgrep(ValidationResults.FullModel.BusPQData.busNames{i},ValidationResults.FullModel.Capacitor.Bus);
            ValidationResults.FullModel.BusPQData.Pin(i,1) = sum(ValidationResults.FullModel.Line.PQData(busIndexLine,2));
            ValidationResults.FullModel.BusPQData.Qin(i,1) = sum(ValidationResults.FullModel.Line.PQData(busIndexLine,4)) ...
                + sum(ValidationResults.FullModel.Capacitor.kVar(busIndexCap)); % cap VAR is added to Qin
        end
    end
    
    
    %% Clear current active circuit to load the second one
    DSSText.Command = 'clear';
    
    %% set active circuit interface for Reduced Model
    
    DSSText.Command = ['compile ', ReducedModel];
    DSSText.Command = 'Solve';
    
    ValidationResults.ReducedModel.SysLosses = DSSCircuit.Losses;
    ValidationResults.ReducedModel.TotalPower = DSSCircuit.TotalPower;
    % Node Data -----------------------------------------------------------
    nodeNames = DSSCircuit.AllNodeNames;
    nodeVolt = DSSCircuit.AllBusVolts; % complex voltage values at each node
    VnodeMag = zeros(length(nodeNames),1);
    VnodeAng = zeros(length(nodeNames),1);
    k = 1;
    for n = 1:2:(length(nodeVolt)-1)
        V = nodeVolt(n) + 1i*nodeVolt(n+1);
        VnodeMag(k) = abs(V)*1e-3; % KV
        VnodeAng(k) = angle(V)*180/pi; % degree
        k = k+1;
    end
    i1 = rgrep('\w*\.1',nodeNames);
    ValidationResults.ReducedModel.Node.Node1.names = nodeNames(i1);
    ValidationResults.ReducedModel.Node.Node1.Vkv = VnodeMag(i1);
    ValidationResults.ReducedModel.Node.Node1.Vang = VnodeAng(i1);
    
    i1 = rgrep('\w*\.2',nodeNames);
    ValidationResults.ReducedModel.Node.Node2.names = nodeNames(i1);
    ValidationResults.ReducedModel.Node.Node2.Vkv = VnodeMag(i1);
    ValidationResults.ReducedModel.Node.Node2.Vang = VnodeAng(i1);
    
    i1 = rgrep('\w*\.3',nodeNames);
    ValidationResults.ReducedModel.Node.Node3.names = nodeNames(i1);
    ValidationResults.ReducedModel.Node.Node3.Vkv = VnodeMag(i1);
    ValidationResults.ReducedModel.Node.Node3.Vang = VnodeAng(i1);
    
    % Line Data -----------------------------------------------------------
    ValidationResults.ReducedModel.Line.PQDataHeader = {'PinLine','PoutLine','QinLine','QoutLine'};
    ValidationResults.ReducedModel.Line.names = DSSCircuit.Lines.AllNames;
    if ~strcmp(ValidationResults.ReducedModel.Line.names,'NONE')
        nl = length(ValidationResults.ReducedModel.Line.names);
        ValidationResults.ReducedModel.NbLines = nl;
        for i = 1:nl
            x = DSSCircuit.CktElements(['Line.',ValidationResults.ReducedModel.Line.names{i}]);
            xx = x.get('Powers');
            xph = DSSCircuit.Lines.Phases;
            ValidationResults.ReducedModel.Line.TerminalBus{i,1} = DSSCircuit.Lines.Bus1;
            ValidationResults.ReducedModel.Line.TerminalBus{i,2} = DSSCircuit.Lines.Bus2;
            PinLine = 0; QinLine = 0;
            PoutLine = 0; QoutLine = 0; % P and Q out of the line are the P and Q into the Bus2 of the line
            for j = 1:2:2*xph
                PinLine = PinLine + xx(j);
                QinLine = QinLine + xx(j+1);
                PoutLine = PoutLine + abs(xx(j+xph*2));
                QoutLine = QoutLine + abs(xx(j+xph*2+1));
            end
            ValidationResults.ReducedModel.Line.PQData(i,1) = PinLine;
            ValidationResults.ReducedModel.Line.PQData(i,2) = PoutLine;
            ValidationResults.ReducedModel.Line.PQData(i,3) = QinLine;
            ValidationResults.ReducedModel.Line.PQData(i,4) = QoutLine;
        end
    else
        ValidationResults.ReducedModel.Line.TerminalBus{1,1} = {};
        ValidationResults.ReducedModel.Line.TerminalBus{1,2} = {};
        ValidationResults.ReducedModel.Line.PQData = zeros(1,4);
    end
    ValidationResults.ReducedModel.Line.LineLosses = DSSCircuit.LineLosses;
    
    % Load data -----------------------------------------------------------
    ValidationResults.ReducedModel.Load.names = DSSCircuit.Loads.AllNames;
    if ~strcmp(ValidationResults.ReducedModel.Load.names,'NONE')
        nld = length(ValidationResults.ReducedModel.Load.names);
        ValidationResults.ReducedModel.NbLoads = nld;
        for i = 1:nld
            x = DSSCircuit.CktElements(['Load.',ValidationResults.ReducedModel.Load.names{i}]);
            xx = x.get('phase'); % gets P and Q in each phase (KW and KVar)
            xph = length(xx)/2;
            xbus = x.get('bus');
            ValidationResults.ReducedModel.Load.Bus{i,1} = xbus{1}(1:length(xbus{1})-8);
            LoadP = 0; LoadQ = 0;
            for j = 1:2:2*xph
                LoadP = LoadP + xx(j);
                LoadQ = LoadQ + xx(j+1);
            end
            ValidationResults.ReducedModel.Load.PQ(i,1) = LoadP;
            ValidationResults.ReducedModel.Load.PQ(i,2) = LoadQ;
        end
    else
        ValidationResults.ReducedModel.Load.Bus = {};
        ValidationResults.ReducedModel.Load.PQ = 0;
        ValidationResults.ReducedModel.Load.PQ = 0;
    end
    
    % Capacitor bank data -------------------------------------------------
    ValidationResults.ReducedModel.Capacitor.names = DSSCircuit.Capacitors.AllNames;
    if ~strcmp(ValidationResults.ReducedModel.Capacitor.names,'NONE')
        for ii = 1:length(ValidationResults.ReducedModel.Capacitor.names)
            element = DSSCircuit.CktElements(['capacitor.',ValidationResults.ReducedModel.Capacitor.names{ii}]);
            buses   = element.get('bus');
            CapBus1 = buses{1};
            CapBus2 = buses{2};
            idx = strfind(CapBus1,'.');
            if ~isempty(idx)
                CapBus1 = CapBus1(1:idx(1)-1);
            end
            ValidationResults.ReducedModel.Capacitor.Bus{ii} = CapBus1;
            ValidationResults.ReducedModel.Capacitor.kVar(ii) = str2num(element.Properties('kvar').Val);
        end
    else
        ValidationResults.ReducedModel.Capacitor.Bus = {};
        ValidationResults.ReducedModel.Capacitor.kVar = 0;
    end
    
    % PQ Data in and out of a bus -----------------------------------------
    ValidationResults.ReducedModel.BusPQData.busNames = DSSCircuit.AllBusNames;
    nb = length(ValidationResults.ReducedModel.BusPQData.busNames);
    ValidationResults.ReducedModel.NbBuses = nb;
    for i = 1:nb
        % P(KW) and Q(KVar) out of a bus
        busIndexLine = rgrep(ValidationResults.ReducedModel.BusPQData.busNames{i},ValidationResults.ReducedModel.Line.TerminalBus(:,1));
        busIndexLoad = rgrep(ValidationResults.ReducedModel.BusPQData.busNames{i},ValidationResults.ReducedModel.Load.Bus);
        ValidationResults.ReducedModel.BusPQData.Pout(i,1) = sum(ValidationResults.ReducedModel.Line.PQData(busIndexLine,1)) ...
            + sum(ValidationResults.ReducedModel.Load.PQ(busIndexLoad,1));
        ValidationResults.ReducedModel.BusPQData.Qout(i,1) = sum(ValidationResults.ReducedModel.Line.PQData(busIndexLine,3)) ...
            + sum(ValidationResults.ReducedModel.Load.PQ(busIndexLoad,2));
        % P(KW) and Q(KVar) into a bus
        if i == 1
            ValidationResults.ReducedModel.BusPQData.Pin(i,1) = ValidationResults.ReducedModel.BusPQData.Pout(i,1);
            ValidationResults.ReducedModel.BusPQData.Qin(i,1) = ValidationResults.ReducedModel.BusPQData.Qout(i,1);
        else
            busIndexLine = rgrep(ValidationResults.ReducedModel.BusPQData.busNames{i},ValidationResults.ReducedModel.Line.TerminalBus(:,2));
            busIndexCap = rgrep(ValidationResults.FullModel.BusPQData.busNames{i},ValidationResults.FullModel.Capacitor.Bus);
            ValidationResults.ReducedModel.BusPQData.Pin(i,1) = sum(ValidationResults.ReducedModel.Line.PQData(busIndexLine,2));
            ValidationResults.ReducedModel.BusPQData.Qin(i,1) = sum(ValidationResults.ReducedModel.Line.PQData(busIndexLine,4)) ...
                + sum(ValidationResults.ReducedModel.Capacitor.kVar(busIndexCap)); % cap VAR is added to Qin
        end
    end
    
    %% Compare results
    % find common buses
    ValidationResults.Comparison.TotalPower = abs(ValidationResults.FullModel.TotalPower) - abs(ValidationResults.ReducedModel.TotalPower);
    
    indexcommon = find(ismember(ValidationResults.FullModel.BusPQData.busNames,...
        ValidationResults.ReducedModel.BusPQData.busNames));
    indexcommon1 = find(ismember(ValidationResults.FullModel.Node.Node1.names,...
        ValidationResults.ReducedModel.Node.Node1.names));
    indexcommon2 = find(ismember(ValidationResults.FullModel.Node.Node2.names,...
        ValidationResults.ReducedModel.Node.Node2.names));
    indexcommon3 = find(ismember(ValidationResults.FullModel.Node.Node3.names,...
        ValidationResults.ReducedModel.Node.Node3.names));
    
    ValidationResults.Comparison.Buses = ValidationResults.ReducedModel.BusPQData.busNames;
    
    ValidationResults.Comparison.Node1.common = ValidationResults.ReducedModel.Node.Node1.names;
    ValidationResults.Comparison.Node1.VmagReduced = ValidationResults.ReducedModel.Node.Node1.Vkv;
    ValidationResults.Comparison.Node1.VmagFull = ValidationResults.FullModel.Node.Node1.Vkv(indexcommon1);
    ValidationResults.Comparison.Node1.VmagError = 100*abs(ValidationResults.Comparison.Node1.VmagFull - ...
        ValidationResults.Comparison.Node1.VmagReduced)./ValidationResults.Comparison.Node1.VmagFull;
    
    ValidationResults.Comparison.Node2.common = ValidationResults.ReducedModel.Node.Node2.names;
    ValidationResults.Comparison.Node2.VmagReduced = ValidationResults.ReducedModel.Node.Node2.Vkv;
    ValidationResults.Comparison.Node2.VmagFull = ValidationResults.FullModel.Node.Node2.Vkv(indexcommon2);
    ValidationResults.Comparison.Node2.VmagError = 100*abs(ValidationResults.Comparison.Node2.VmagFull - ...
        ValidationResults.Comparison.Node2.VmagReduced)./ValidationResults.Comparison.Node2.VmagFull;
    
    ValidationResults.Comparison.Node3.common = ValidationResults.ReducedModel.Node.Node3.names;
    ValidationResults.Comparison.Node3.VmagReduced = ValidationResults.ReducedModel.Node.Node3.Vkv;
    ValidationResults.Comparison.Node3.VmagFull = ValidationResults.FullModel.Node.Node3.Vkv(indexcommon3);
    ValidationResults.Comparison.Node3.VmagError = 100*abs(ValidationResults.Comparison.Node3.VmagFull - ...
        ValidationResults.Comparison.Node3.VmagReduced)./ValidationResults.Comparison.Node3.VmagFull;
    
    ValidationResults.Comparison.PinBus.Reduced = ValidationResults.ReducedModel.BusPQData.Pin;
    ValidationResults.Comparison.PinBus.Full = ValidationResults.FullModel.BusPQData.Pin(indexcommon);
    ValidationResults.Comparison.PinBus.Error = 100*abs((ValidationResults.Comparison.PinBus.Full - ...
        ValidationResults.Comparison.PinBus.Reduced)./ValidationResults.FullModel.TotalPower(1));
    
    ValidationResults.Comparison.QinBus.Reduced = ValidationResults.ReducedModel.BusPQData.Qin;
    ValidationResults.Comparison.QinBus.Full = ValidationResults.FullModel.BusPQData.Qin(indexcommon);
    ValidationResults.Comparison.QinBus.Error = 100*abs((ValidationResults.Comparison.QinBus.Full - ...
        ValidationResults.Comparison.QinBus.Reduced)./ValidationResults.FullModel.TotalPower(2));
    
    ValidationResults.Comparison.PoutBus.Reduced = ValidationResults.ReducedModel.BusPQData.Pout;
    ValidationResults.Comparison.PoutBus.Full = ValidationResults.FullModel.BusPQData.Pout(indexcommon);
    ValidationResults.Comparison.PoutBus.Error = 100*abs((ValidationResults.Comparison.PoutBus.Full - ...
        ValidationResults.Comparison.PoutBus.Reduced)./ValidationResults.FullModel.TotalPower(1));
    
    ValidationResults.Comparison.QoutBus.Reduced = ValidationResults.ReducedModel.BusPQData.Qout;
    ValidationResults.Comparison.QoutBus.Full = ValidationResults.FullModel.BusPQData.Qout(indexcommon);
    ValidationResults.Comparison.QoutBus.Error = 100*abs((ValidationResults.Comparison.QoutBus.Full - ...
        ValidationResults.Comparison.QoutBus.Reduced)./ValidationResults.FullModel.TotalPower(2));
    
    % ---------------------------------------------------------------------
else
    disp('ERROR: OpenDSS did not start!')
end