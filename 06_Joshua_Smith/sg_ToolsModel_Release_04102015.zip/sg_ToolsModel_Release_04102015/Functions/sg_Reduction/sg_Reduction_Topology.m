function para = sg_Reduction_Topology(varargin)
% Performs a feeder circuit reduction based on topology.
% function para = sg_Reduction_Topology(DSSObj,para)
%
% Feeder circuit reduction based on feeder topology and a list of buses to
% keep. Algorithm is based on walking the topology tree from all leaves
% back to the root until all buses that are to be removed have been processed.
%
% Inputs: DSSObj	... OpenDSS COM interface connection
%    	  para		... Structure with settings for model reduction (specific to
%                		this approach)
%         .Model       ... model to be reduced, path/file name
%         .Method      ... reduction method: 'topology'
%         .KeepBuses   ... cell array of bus names
%         .RemoveBuses ... cell array of bus names
%         .KeepConPoints ... 0/1, allow shifting lines/loads if encountering branching point
%         .IDkeyBuses  ... use key bus identification function 
%                          (0-no, 1-with default settings (Caps, gens, Trx, TapTrx), 2-custom settings);
%         .TargetFolder   ... folder path for reduced model
%         .ActionFile     ... name of action list file, 'ActionList.txt';
%         .ActionUnDoFile ... name of UnDo-action list file, 'ActionListUnDo.txt';
%         .ActionCommentFile ... name of Action-comment file, 'ActionComments.txt';
%         .ActDisp    ... command line display flag
%         .DispFlag ... display action window
%         .fno      ... acttion window (figure) number
%         .profile    ... path-name of associated profile file (.csv or.xlx), output will be a .xls
%         .(KeyBusIDchoice) ... see options for choices to determine key buses
%
% Outputs: para		... updated structure with the following fields
%      	   r.		... structure with information of individual actions taken
%       	.Actions 	... a string of the actions taken.
%       	.ActComment ... a string summarizing the actions taken.
%       	.ActUnDo 	... a string of actions that reverse the actions taken.
%           .status   ... success falg
%           .EventLog ... event messages
%
% Example Call(s):
%    	para = sg_Reduction_Topology(DSSObj,para);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%
% February 18, 2015

%%
% Interface to OpenDSS for topology parsing
DSSObj      = varargin{1};
DSSText     = DSSObj.Text;
DSSSolution = DSSObj.ActiveCircuit.Solution;

% clear/reset global vars
clear global INFO_LOAD INFO_GEN INFO_LINE INFO_TR INFO_LOADRATIO

% Algorithm parameters
para = varargin{2};
% key bus identification options
paraKeyDefault.BusExpr  = '';
paraKeyDefault.CBkvar   = 1;
paraKeyDefault.TapXFMR  = 1;
paraKeyDefault.TransKVA = 1;
paraKeyDefault.TransKV  = 1e12;
paraKeyDefault.GenKVA   = 1;
paraKeyDefault.LoadKVA  = 1e12;
paraKeyDefault.ThreePhaseBus = 0;
paraKeyDefault.kVRating = 1e12;
paraKeyDefault.VRatingEnd = 1e12;
paraKeyDefault.puVDev   = 1e12;
% defaults and user update to set of key bus identification
if para.IDkeyBuses == 2
    % allow individual options

    IDkeyValues = struct('BusExpr','','CBkvar',-1,'TapXFMR',0,'TransKVA',1e12,'TransKV',1e12,'GenKVA',1e12,...
        'LoadKVA',1e12,'ThreePhaseBus',0,'kVRating',1e12,'VRatingEnd',1e12,'puVDev',1e12);
    if isfield(para,'BusExpr')
        IDkeyValues = sg_updateOpts(IDkeyValues,'BusExpr',para.BusExpr);
    end
    if isfield(para,'CBkvar')
        IDkeyValues = sg_updateOpts(IDkeyValues,'CBkvar',para.CBkvar);
    end
    if isfield(para,'TapXFMR')
        IDkeyValues = sg_updateOpts(IDkeyValues,'TapXFMR',para.TapXFMR);
    end
    if isfield(para,'TransKVA')
        IDkeyValues = sg_updateOpts(IDkeyValues,'TransKVA',para.TransKVA);
    end
    if isfield(para,'TransKV')
        IDkeyValues = sg_updateOpts(IDkeyValues,'TransKV',para.TransKV);
    end
    if isfield(para,'GenKVA')
        IDkeyValues = sg_updateOpts(IDkeyValues,'GenKVA',para.GenKVA);
    end
    if isfield(para,'LoadKVA')
        IDkeyValues = sg_updateOpts(IDkeyValues,'LoadKVA',para.LoadKVA);
    end
    if isfield(para,'ThreePhaseBus')
        IDkeyValues = sg_updateOpts(IDkeyValues,'ThreePhaseBus',para.ThreePhaseBus);
    end
    if isfield(para,'kVRating')
        IDkeyValues = sg_updateOpts(IDkeyValues,'kVRating',para.kVRating);
    end
    if isfield(para,'VRatingEnd')
        IDkeyValues = sg_updateOpts(IDkeyValues,'VRatingEnd',para.VRatingEnd);
    end
    if isfield(para,'puVDev')
        IDkeyValues = sg_updateOpts(IDkeyValues,'puVDev',para.puVDev);
    end
end

%% Default setup and handling of options
para.EventLog = {};       % keeps track of warning/error messages (cell array)
para.status   = 0;        % power flow solution status (0/1)
if ~isfield(para,'DispFlag')
    para.DispFlag = 1;
end
if ~isfield(para,'fno')
    para.fno = 1000;
end
% Figure-based display of progress (text/strings)
MaxDispLines = 20;        % number of rows displayed
DispX  = 0.1;             % x-position
DispDY = 0.25;            % step in y-direction for header line and 1st line
DispXmax = 3;             % x-display size
DispYmax = 6;             % y-display size
ftSize = 9;               % font size
DispLine  = 0;            % current display line
DispCount = 0;            % number of lines displayed so far
DateForm = 13;            % date-time string format (see MATLAB help)
TxtColor = [0 0.45 0];    % color for current line (~green)

%% Setup figure for progress display
if para.DispFlag
    figure(para.fno)
    clf;
    set(gca,'position',[0 0 1 1]);
    set(gca,'xtick',[])
    set(gca,'ytick',[])
    set(gcf,'name','Model reduction: Topology based');
    axis([0 DispXmax 0 DispYmax+DispDY])
    h = text(DispX,DispYmax,'Status:','fontsize',ftSize,'color',[0 0 1]);
    TxtExtent = get(h,'extent');
    DYtxt = TxtExtent(4)*1.1;
    DispLine  = DispLine + 1;
    DispCount = DispCount + 1;
    txt = sprintf('[%.0f] %s: Building topology tree',DispCount,datestr(now,DateForm));
    DispText{DispLine} = txt;
    th{DispLine} = text(DispX,DispYmax-DispDY,txt,'fontsize',ftSize,'color',TxtColor);
end

tic
%% Topology tree (linked list)
f = sg_GetTopologyTree(DSSObj);
% find leaves
f.Leaves = [];
for ii = 1:length(f.Tree)
    if isempty(f.Tree(ii).NextID)
        f.Leaves = [f.Leaves ii];
    end
end

KeepBuses1 = lower(para.KeepBuses);
if size(KeepBuses1,2) > 1
    KeepBuses1 = KeepBuses1';
end

%% Determine candidate buses (to be removed) based on parameters provided
if para.DispFlag
    DispLine  = DispLine + 1;
    if DispLine > MaxDispLines, DispLine = 1; end
    DispCount = DispCount + 1;
    DispText{DispLine} = sprintf('[%.0f] %s: Building list of candidate buses to be removed',DispCount,datestr(now,DateForm));
    if DispCount <= MaxDispLines
        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
    else
        set(th{DispLine},'string',DispText{DispLine});
        set(th{DispLine},'color',TxtColor);
    end
    if DispLine > 1 && DispCount <= MaxDispLines
        set(th{DispLine-1},'color',[0 0 0]);
    elseif DispCount > MaxDispLines
        set(th{MaxDispLines},'color',[0 0 0]);
    end
end
% Candidates based on user defined list of key buses
KeyBusEntry  = 0;
CandidateBusNames1 = DSSObj.ActiveCircuit.AllBusNames;
if ~isempty(KeepBuses1)
    BusInt = 1:length(CandidateBusNames1);
    KeyBusIndex = find(ismember(CandidateBusNames1,KeepBuses1));
    if ~isempty(KeyBusIndex) && (length(KeyBusIndex) == length(KeepBuses1))
        CandidateBusNames1(KeyBusIndex) = '';
    else
        % wrong bus names: quit in case not all buses are found
        FoundBuses = find(ismember(KeepBuses1,CandidateBusNames1(KeyBusIndex)));
        KeepBuses = KeepBuses1;
        KeepBuses(FoundBuses) = '';
        para.EventLog{end+1} = sprintf('Error: Model reduction based on topology: Buses to keep not found: ');
        for ii = 1:length(KeepBuses)
            para.EventLog{end} = [para.EventLog{end} sprintf('%s ',KeepBuses{ii})];
        end
        if para.DispFlag, fprintf('%s\n',para.EventLog{end}); end;
        return
    end
else
    CandidateBusNames1 = [];
end
% Automatic detection of buses that fit criteria
if para.IDkeyBuses == 1
    [KeepBuses2, CandidateBusNames2] = sg_IDkeyBuses(DSSObj,...
        'CBkvar',paraKeyDefault.CBkvar,'TapXFMR',paraKeyDefault.TapXFMR,'TransKVA',paraKeyDefault.TransKVA,'GenKVA',paraKeyDefault.GenKVA);
elseif para.IDkeyBuses == 2
    [KeepBuses2, CandidateBusNames2] = sg_IDkeyBuses(DSSObj,...
        'BusExpr',IDkeyValues.BusExpr,'CBkvar',IDkeyValues.CBkvar,'TapXFMR',IDkeyValues.TapXFMR,'TransKVA',IDkeyValues.para,'TransKV',IDkeyValues.TransKV,'GenKVA',IDkeyValues.GenKVA,...
        'LoadKVA',IDkeyValues.LoadKVA,'ThreePhaseBus',IDkeyValues.ThreePhaseBus,'kVRating',IDkeyValues.kVRating,'VRatingEnd',IDkeyValues.VRatingEnd,'puVDev',IDkeyValues.puVDev);
else
    KeepBuses2 = [];
    CandidateBusNames2 = [];
end
% merging the two lists
CandidateBusNames = CandidateBusNames1;
for ii = 1:length(CandidateBusNames2)
    if ~strcmpi(CandidateBusNames2{ii},CandidateBusNames);
        CandidateBusNames{end+1} = CandidateBusNames2{ii};
    end
end
KeepBuses = KeepBuses1;
for ii = 1:length(KeepBuses2)
    if ~strcmpi(KeepBuses2{ii},KeepBuses)
        KeepBuses{end+1} = KeepBuses2{ii};
    end
end
% remove keepers from candidate list
if ~isempty(KeepBuses)
    idx = find(ismember(CandidateBusNames,KeepBuses));
    CandidateBusNames(idx) = '';
else
    
end

NumKeepBuses = length(KeepBuses);
RemovedBuses = 0;
NumBuses = DSSObj.ActiveCircuit.NumBuses;

% display update
if para.DispFlag
    DispLine  = DispLine + 1;
    if DispLine > MaxDispLines, DispLine = 1; end
    DispCount = DispCount + 1;
    DispText{DispLine} = sprintf('[%.0f] %s: %.0f buses total, %.0f key buses, %.0f candidates for removal',...
        DispCount,datestr(now,DateForm),NumBuses,NumKeepBuses,length(CandidateBusNames));
    if DispCount <= MaxDispLines
        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
    else
        set(th{DispLine},'string',DispText{DispLine});
        set(th{DispLine},'color',TxtColor);
    end
    if DispLine > 1 && DispCount <= MaxDispLines
        set(th{DispLine-1},'color',[0 0 0]);
    elseif DispCount > MaxDispLines
        set(th{MaxDispLines},'color',[0 0 0]);
    end
end

%% Determine actions
% display update
if para.DispFlag
    DispLine  = DispLine + 1;
    if DispLine > MaxDispLines, DispLine = 1; end
    DispCount = DispCount + 1;
    DispText{DispLine} = sprintf('[%.0f] %s: Determining list of model reduction actions',...
        DispCount,datestr(now,DateForm));
    if DispCount <= MaxDispLines
        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
    else
        set(th{DispLine},'string',DispText{DispLine});
        set(th{DispLine},'color',TxtColor);
    end
    if DispLine > 1 && DispCount <= MaxDispLines
        set(th{DispLine-1},'color',[0 0 0]);
    elseif DispCount > MaxDispLines
        set(th{MaxDispLines},'color',[0 0 0]);
    end
end
Acts = 0;
for ii = 1:length(f.Leaves)
    if ~isempty(CandidateBusNames)
        % walk from leaves to root-node
        ElemIdx = f.Leaves(ii);
        while length(f.Tree(ElemIdx).PrevID) ~= 0 % while not at root
            % sanity check: not more than one incoming link
            if length(f.Tree(ElemIdx).PrevID) > 1
                % something is off
                para.EventLog{end+1} = sprintf('Error: Model reduction based on topology: Branch has more than one incoming link: %s. May indicate looped or parallel branches.',f.Tree(ElemIdx).BranchName);
                if para.DispFlag, fprintf('%s\n',para.EventLog{end}); end;
                return
            end
            
            if isempty(f.Tree(ElemIdx).PrevID) && isempty(f.Tree(ElemIdx).NextID)
                % something is off
                para.EventLog{end+1} = sprintf('Error: Model reduction based on topology: Branch has no in- and out-links: %s. Indicates inactive element.',f.Tree(ElemIdx).BranchName);
                if para.DispFlag, fprintf('%s\n',para.EventLog{end}); end;
                return
            end
            
            if ~any(strcmpi(f.Tree(ElemIdx).nBus,KeepBuses))
                % not a keeper: handle element/bus
                if length(f.Tree(ElemIdx).NextID) == 0
                    % found leave: move loads and remove bus
                    idx = strcmpi(f.Tree(ElemIdx).nBus,CandidateBusNames);
                    if ~all(idx == 0)
                        % multiple lines between the same buses: bus may
                        % have been removed already
                        Acts = Acts+1;
                        ActionList(Acts).Name = 'MoveElements';
                        ActionList(Acts).Args = {f.Tree(ElemIdx).nBus,f.Tree(ElemIdx).pBus};
                        Acts = Acts+1;
                        ActionList(Acts).Name = 'RemoveBus';
                        ActionList(Acts).Args = f.Tree(ElemIdx).nBus;
                        for jj = 1:length(f.Tree(ElemIdx).PrevID)
                            idx2 = find(f.Tree(f.Tree(ElemIdx).PrevID(jj)).NextID ~= ElemIdx);
                            f.Tree(f.Tree(ElemIdx).PrevID(jj)).NextID = f.Tree(f.Tree(ElemIdx).PrevID(jj)).NextID(idx2);
                        end
                        ElemIdxNew = f.Tree(ElemIdx).PrevID(1);
                        f.Tree(ElemIdx).PrevID = [];
                        CandidateBusNames(idx) = '';
                        RemovedBuses = RemovedBuses + 1;
                        ElemIdx = ElemIdxNew;
                    else
                        % Branch with nBus already removed: disable links
                        % in tree
                        for jj = 1:length(f.Tree(ElemIdx).PrevID)
                            idx2 = find(f.Tree(f.Tree(ElemIdx).PrevID(jj)).NextID ~= ElemIdx);
                            f.Tree(f.Tree(ElemIdx).PrevID(jj)).NextID = f.Tree(f.Tree(ElemIdx).PrevID(jj)).NextID(idx2);
                        end
                        ElemIdxNew = f.Tree(ElemIdx).PrevID(1);
                        f.Tree(ElemIdx).PrevID = [];
                        ElemIdx = ElemIdxNew;
                    end
                elseif length(f.Tree(ElemIdx).PrevID) == 1 && length(f.Tree(ElemIdx).NextID) == 1 && ...
                        f.Tree(ElemIdx).IsLine && f.Tree(f.Tree(ElemIdx).NextID).IsLine
                    % two linked lines: split and remove bus
                    Acts = Acts+1;
                    ActionList(Acts).Name = 'SplitBus';
                    ActionList(Acts).Args = {f.Tree(ElemIdx).nBus,{{f.Tree(ElemIdx).pBus{1} f.Tree(f.Tree(ElemIdx).NextID).nBus{1}}}};
                    Acts = Acts+1;
                    ActionList(Acts).Name = 'RemoveBus';
                    ActionList(Acts).Args = f.Tree(ElemIdx).nBus;
                    idx = find(f.Tree(f.Tree(ElemIdx).PrevID).NextID == ElemIdx);
                    f.Tree(f.Tree(ElemIdx).PrevID).NextID(idx) = f.Tree(ElemIdx).NextID;
                    f.Tree(f.Tree(ElemIdx).NextID).PrevID = f.Tree(ElemIdx).PrevID;
                    f.Tree(f.Tree(ElemIdx).NextID).pBus = f.Tree(ElemIdx).pBus;
                    f.Tree(f.Tree(ElemIdx).NextID).ActiveLevel = f.Tree(f.Tree(ElemIdx).NextID).ActiveLevel - 1;
                    ElemIdxNew = f.Tree(ElemIdx).PrevID(1);
                    f.Tree(ElemIdx).PrevID = [];
                    f.Tree(ElemIdx).NextID = [];
                    idx = strcmpi(f.Tree(ElemIdx).nBus,CandidateBusNames);
                    CandidateBusNames(idx) = '';
                    ElemIdx = ElemIdxNew;
                    RemovedBuses = RemovedBuses + 1;
                elseif length(f.Tree(ElemIdx).NextID) >= 2 && f.Tree(ElemIdx).IsLine &&  all([f.Tree(f.Tree(ElemIdx).NextID).IsLine])
                    if para.KeepConPoints == 0
                        % more than one out-going line branch: move all but one
                        % line, split bus, and remove bus
                        for jj = 1:length(f.Tree(ElemIdx).NextID)-1
                            Acts = Acts+1;
                            ActionList(Acts).Name = 'MoveLine';
                            ActionList(Acts).Args = {f.Tree(ElemIdx).nBus,{{f.Tree(ElemIdx).pBus{1} f.Tree(f.Tree(ElemIdx).NextID(jj)).nBus{1}}}};
                            f.Tree(f.Tree(ElemIdx).NextID(jj)).pBus = f.Tree(ElemIdx).pBus;
                            f.Tree(f.Tree(ElemIdx).NextID(jj)).ActiveLevel = f.Tree(f.Tree(ElemIdx).NextID(jj)).ActiveLevel - 1;
                            f.Tree(f.Tree(ElemIdx).NextID(jj)).PrevID = f.Tree(ElemIdx).PrevID;
                            f.Tree(ElemIdx).NextID(jj) = 0;
                        end
                        idx = find(f.Tree(ElemIdx).NextID ~= 0);
                        f.Tree(ElemIdx).NextID = f.Tree(ElemIdx).NextID(idx);
                        Acts = Acts+1;
                        ActionList(Acts).Name = 'SplitBus';
                        ActionList(Acts).Args = {f.Tree(ElemIdx).nBus,{{f.Tree(ElemIdx).pBus{1} f.Tree(f.Tree(ElemIdx).NextID).nBus{1}}}};
                        Acts = Acts+1;
                        ActionList(Acts).Name = 'RemoveBus';
                        ActionList(Acts).Args = f.Tree(ElemIdx).nBus;
                        idx = find(f.Tree(f.Tree(ElemIdx).PrevID).NextID == ElemIdx);
                        f.Tree(f.Tree(ElemIdx).PrevID).NextID(idx) = f.Tree(ElemIdx).NextID;
                        f.Tree(f.Tree(ElemIdx).NextID).pBus = f.Tree(ElemIdx).pBus;
                        f.Tree(f.Tree(ElemIdx).NextID).ActiveLevel = f.Tree(f.Tree(ElemIdx).NextID).ActiveLevel - 1;
                        f.Tree(f.Tree(ElemIdx).NextID).PrevID = f.Tree(ElemIdx).PrevID;
                        ElemIdxNew = f.Tree(ElemIdx).PrevID(1);
                        f.Tree(ElemIdx).PrevID = [];
                        f.Tree(ElemIdx).NextID = [];
                        idx = strcmpi(f.Tree(ElemIdx).nBus,CandidateBusNames);
                        CandidateBusNames(idx) = '';
                        ElemIdx = ElemIdxNew;
                        RemovedBuses = RemovedBuses + 1;
                    else
                        % selected option: keep bus with multiple connections
                        ElemIdxNew = f.Tree(ElemIdx).PrevID(1);
                        ElemIdx = ElemIdxNew;
                    end
                else
                    % none of the reduction options applied: move to next branch
                    ElemIdx = f.Tree(ElemIdx).PrevID(1);
                end
            else
                % bus is to be kept: move to next branch
                ElemIdx = f.Tree(ElemIdx).PrevID(1);
            end
            % display update
            if para.DispFlag
                DispLine  = DispLine + 1;
                if DispLine > MaxDispLines, DispLine = 1; end
                DispCount = DispCount + 1;
                DispText{DispLine} = sprintf('[%.0f] %s: Leave %.0f/%.0f, %.0f Actions, %.0f key buses, %.0f Candidates, %.0f removed, %.0f buses',...
                    DispCount,datestr(now,DateForm),ii,length(f.Leaves),Acts,NumKeepBuses,length(CandidateBusNames),RemovedBuses,NumBuses-RemovedBuses);
                if DispCount <= MaxDispLines
                    th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
                else
                    set(th{DispLine},'string',DispText{DispLine},'color',TxtColor);
                end
                if DispLine > 1
                    set(th{DispLine-1},'color',[0 0 0]);
                elseif DispLine==1 && DispCount>MaxDispLines
                    set(th{MaxDispLines},'color',[0 0 0]);
                end
                drawnow
            end
        end
    end
end
% Add final step: combine loads
Acts = Acts+1;
ActionList(Acts).Name = 'CombineLoads';
ActionList(Acts).Args = {''};
% Final display update
if para.DispFlag
    DispLine  = DispLine + 1;
    if DispLine > MaxDispLines, DispLine = 1; end
    DispCount = DispCount + 1;
    DispText{DispLine} = sprintf('[%.0f] %s: %.0f Actions, %.0f key buses, %.0f Candidates = %.0f buses remaining',...
        DispCount,datestr(now,DateForm),Acts,NumKeepBuses,length(CandidateBusNames),NumBuses-RemovedBuses);
    if DispCount <= MaxDispLines
        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
    else
        set(th{DispLine},'string',DispText{DispLine},'color',TxtColor);
    end
    if DispLine > 1
        set(th{DispLine-1},'color',[0 0 0]);
    elseif DispLine==1 && DispCount>MaxDispLines
        set(th{MaxDispLines},'color',[0 0 0]);
    end
end

%% Execute actions
if para.DispFlag
    DispLine  = DispLine + 1;
    if DispLine > MaxDispLines, DispLine = 1; end
    DispCount = DispCount + 1;
    DispText{DispLine} = sprintf('[%.0f] %s: Executing reduction actions ...',...
        DispCount,datestr(now,DateForm));
    if DispCount <= MaxDispLines
        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
    else
        set(th{DispLine},'string',DispText{DispLine},'color',TxtColor);
    end
    if DispLine > 1
        set(th{DispLine-1},'color',[0 0 0]);
    elseif DispLine==1 && DispCount>MaxDispLines
        set(th{MaxDispLines},'color',[0 0 0]);
    end
end

r = cell(1,length(ActionList));
acount    = 0;   % keeps count of number of actions performed
ErrorFlag = 0;   % used to exit action-loop on first error
noAct     = 1e9; % for debugging: stop at this action
dbgAct    = 16;   % allows to set a break point for debugging

ActRemoveBusCount = 0;
try
    for ii = 1:min(noAct,length(ActionList))
        if dbgAct == ii
            DebugPoint = 1;
        end
        r{ii}.Actions = [];
        r{ii}.EventLog = [];
        r{ii}.ActUnDo = [];
        if ~ErrorFlag
            switch ActionList(ii).Name
                case 'SplitBus'
                    r{ii} = sg_openDssSplitBus(DSSObj,ActionList(ii).Args);
                case 'RemoveBus'
                    r{ii} = sg_openDssRemoveBus(DSSObj,ActionList(ii).Args);
                    if r{ii}.status
                        ActRemoveBusCount = ActRemoveBusCount + 1;
                    end
                case 'MoveElements'
                    r{ii} = sg_openDssMoveElements(DSSObj,ActionList(ii).Args);
                case 'MoveLine'
                    r{ii} = sg_openDssMoveLine(DSSObj,ActionList(ii).Args);
                case 'CombineLoads'
                    r{ii} = sg_openDssCombineLoads(DSSObj,ActionList(ii).Args);
                    % update profile data if necessary
                    if ~isempty(para.profile)
                        % updates: entries for split loads and collected loads
                        r{ii} = sg_ProfileUpdate(r{ii},para.profile);
                    end
                otherwise
                    para.EventLog{end+1} = sprintf('Error: [%.0f] Reducing circuit: Unknown reduction action %s.',ii,ActionList(ii).Name);
                    r{ii}.Actions  = {''};
                    r{ii}.status   = 0;
                    r{ii}.EventLog = para.EventLog(end);
            end
            if para.ActDisp
                for jj = 1:length(r{ii}.Actions)
                    txt = sprintf('[%.0f,%.0f] %s',ii,jj,r{ii}.Actions{jj});
                    fprintf('%s\n',txt);
                end
            end
            for jj = 1:length(r{ii}.EventLog)
                txt = sprintf('[%.0f,%.0f] Event: %s',ii,jj,r{ii}.EventLog{jj});
                fprintf('%s\n',txt);
                if strfind(txt,'Error:')
                    % Last reduction action was not successful: exit
                    ErrorFlag = 1;
                end
            end
            if para.DispFlag
                % display action summary
                DispLine  = DispLine + 1;
                if DispLine > MaxDispLines, DispLine = 1; end
                DispCount = DispCount + 1;
                DispText{DispLine} = sprintf('[%.0f] %s: Action %.0f/%.0f, %s (steps: %.0f), removed: %.0f, remain: %.0f',...
                    DispCount,datestr(now,DateForm),ii,Acts,ActionList(ii).Name,length(r{ii}.Actions),ActRemoveBusCount,NumBuses-ActRemoveBusCount);
                if DispCount <= MaxDispLines
                    th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
                else
                    set(th{DispLine},'string',DispText{DispLine},'color',TxtColor);
                end
                if DispLine > 1
                    set(th{DispLine-1},'color',[0 0 0]);
                elseif DispLine==1 && DispCount>MaxDispLines
                    set(th{MaxDispLines},'color',[0 0 0]);
                end
                % display EventLog entries
                for jj = 1:length(r{ii}.EventLog)
                    DispLine  = DispLine + 1;
                    if DispLine > MaxDispLines, DispLine = 1; end
                    DispCount = DispCount + 1;
                    DispText{DispLine} = sprintf('[%.0f] %s: Event: %s',...
                        DispCount,datestr(now,DateForm),r{ii}.EventLog{jj});
                    if DispCount <= MaxDispLines
                        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},...
                            'fontsize',ftSize,'color',TxtColor,'interpreter','none');
                    else
                        set(th{DispLine},'string',DispText{DispLine},'color',TxtColor,'interpreter','none');
                    end
                    if DispLine > 1
                        set(th{DispLine-1},'color',[0 0 0]);
                    elseif DispLine==1 && DispCount>MaxDispLines
                        set(th{MaxDispLines},'color',[0 0 0]);
                    end
                end
                drawnow
            end
            acount = acount + 1;
            if ErrorFlag
                break;
            end
        end
    end
catch
    % data extraction failed: providing error message
    le = lasterror;
    para.EventLog{end+1} = sprintf('Error: [%.0f] Reducing circuit: %s\n  %s\nFile: %s, Line: %.0f',...
        ii,ActionList(ii).Name,le.message,le.stack(1).name,le.stack(1).line);
    if para.DispFlag
        fprintf('\nError reducing circuit: [%.0f] %s\n %s\nStack:\n',ii,ActionList(ii).Name,le.message);
        for ii=1:length(le.stack)
            fprintf(' File: %s, Line: %.0f\n',le.stack(ii).name,le.stack(ii).line);
        end
    end
end

%% continue with solving and saving circuit if all actions were successful
if acount == length(ActionList)
    %%  Solve the model and save ciruit, actions
    % save updated circuit
    DSSText.command = 'Calcv';
    if ~isempty(DSSText.Result)
        para.EventLog{end+1} = sprintf('Error: OpenDSS: %s\n',DSSText.Result);
        if para.DispFlag
            fprintf(' OpenDSS: %s\n',DSSText.Result);
        end
        return
    end
    DSSSolution.Solve;
    % Exit with success (only if all actions were executed)
    para.status = 1;
end

%% Save feeder circuit
DSSText.Command=['save circuit dir=' para.TargetFolder];
% reopen master.dss and add base voltage information
DSSObj.Text.Command = 'get voltagebases';
val = DSSObj.Text.Result;
fn  = sprintf('%s/Master.DSS',para.TargetFolder);
str1 = sprintf('\n\nSet voltagebases = %s\nCalcv\n\n',val);
fid = fopen(fn,'a');
fprintf(fid,str1);
fclose(fid);


% save action list
if ~isempty(para.ActionFile)
    [fid,message] = fopen([para.TargetFolder '\' para.ActionFile],'w');
    if ~isempty(message)
        para.EventLog{end+1} = sprintf('Error: Saving Action-List file: %s',message);
        if para.DispFlag
            fprintf(' Error: Saving Action-List file: %s\n',message);
        end
        return
    end
    for ii = 1:acount
        for jj = 1:length(r{ii}.Actions)
            fprintf(fid,'[%.0f,%.0f] %s\n',ii,jj,r{ii}.Actions{jj});
        end
    end
    fclose(fid);
end
% save action-UnDo list
if ~isempty(para.ActionUnDoFile)
    [fid,message] = fopen([para.TargetFolder '\' para.ActionUnDoFile],'w');
    if ~isempty(message)
        para.EventLog{end+1} = sprintf('Error: Saving Action-UnDo-List file: %s',message);
        if para.DispFlag
            fprintf(' Error: Saving Action-UnDo-List file: %s\n',message);
        end
        return
    end
    for ii = 1:acount
        for jj = 1:length(r{ii}.ActUnDo)
            fprintf(fid,'[%.0f,%.0f] %s\n',ii,jj,r{ii}.ActUnDo{jj});
        end
    end
    fclose(fid);
end
% save action-Comments list
if ~isempty(para.ActionCommentFile)
    [fid,message] = fopen([para.TargetFolder '\' para.ActionCommentFile],'w');
    if ~isempty(message)
        para.EventLog{end+1} = sprintf('Error: Saving Action-Comment-List file: %s',message);
        if para.DispFlag
            fprintf(' Error: Saving Action-Comment-List file: %s\n',message);
        end
        return
    end
    for ii = 1:acount
        for jj = 1:length(r{ii}.ActComment)
            fprintf(fid,'[%.0f,%.0f] %s\n',ii,jj,r{ii}.ActComment{jj});
        end
    end
    fclose(fid);
end
% display update
if para.DispFlag
    DispLine  = DispLine + 1;
    if DispLine > MaxDispLines, DispLine = 1; end
    DispCount = DispCount + 1;
    DispText{DispLine} = sprintf('[%.0f] %s: Saved feeder: %s',...
        DispCount,datestr(now,DateForm),para.TargetFolder);
    if DispCount <= MaxDispLines
        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor,'interpreter','none');
    else
        set(th{DispLine},'string',DispText{DispLine},'color',TxtColor,'interpreter','none');
    end
    if DispLine > 1
        set(th{DispLine-1},'color',[0 0 0]);
    elseif DispLine==1 && DispCount>MaxDispLines
        set(th{MaxDispLines},'color',[0 0 0]);
    end
    drawnow
    % Actions
    DispLine  = DispLine + 1;
    if DispLine > MaxDispLines, DispLine = 1; end
    DispCount = DispCount + 1;
    DispText{DispLine} = sprintf('[%.0f] %s: Saved actions (%s) and undo-lists (%s)',...
        DispCount,datestr(now,DateForm),para.ActionFile,para.ActionUnDoFile);
    if DispCount <= MaxDispLines
        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
    else
        set(th{DispLine},'string',DispText{DispLine},'color',TxtColor);
    end
    if DispLine > 1
        set(th{DispLine-1},'color',[0 0 0]);
    elseif DispLine==1 && DispCount>MaxDispLines
        set(th{MaxDispLines},'color',[0 0 0]);
    end
    drawnow
end

%% time info
T  = toc;
tH = floor(T/(60*60));
T  = T - tH*60*60;
tM = floor(T/60);
tS  = round(T - tM*60);
para.MRtime = [tH tM tS];

if para.DispFlag
    DispLine  = DispLine + 1;
    if DispLine > MaxDispLines, DispLine = 1; end
    DispCount = DispCount + 1;
    DispText{DispLine} = sprintf('[%.0f] %s: Took %.0fh %2.0fm %2.0fs',...
        DispCount,datestr(now,DateForm),tH,tM,tS);
    if DispCount <= MaxDispLines
        th{DispLine} = text(DispX,DispYmax-DispDY-(DispLine-1)*DYtxt,DispText{DispLine},'fontsize',ftSize,'color',TxtColor);
    else
        set(th{DispLine},'string',DispText{DispLine},'color',TxtColor);
    end
    if DispLine > 1
        set(th{DispLine-1},'color',[0 0 0]);
    elseif DispLine==1 && DispCount>MaxDispLines
        set(th{MaxDispLines},'color',[0 0 0]);
    end
    drawnow
end