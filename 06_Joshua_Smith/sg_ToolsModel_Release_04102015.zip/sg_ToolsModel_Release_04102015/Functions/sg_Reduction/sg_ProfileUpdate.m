function r = sg_ProfileUpdate(r,Profile)

%  Update load profile data after model reduction and save as new file.
%  function r = sg_ProfileUpdate(r,Profile)
%
%  Creates new profile file with updated load information. Identifies
%  active and reactive power entries of loads that require scaling and/or
%  adds new entries (i.e., after splitting loads.) Requires Microsoft
%  Excel to be installed as xlswrite is used.
%
%  Parameters:
%    r - data structure with the following fields
%      CollectedLoads  - has been added by sg_openDssCombineLoads
%    Profile - fully qualified name of profile file
%  Options:
%  Returns r
%    r - a structure with the following fields
%      status - success flag
%      EventLog - event messages
%
%  Examples:
%    r = sg_MR_ProfileUpdate(r,'ProfileFile.xlsx');
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% February 18, 2015

% Init
DispFlag = 0;         % turn on/off console display (0/1)
r.status   = 0;       % success status (0/1)
r.EventLog = {};      % keeps track of warning/error messages (cell array)

%% Globals
global INFO_LOAD

if isempty(INFO_LOAD)
    INFO_LOAD = sg_openDssGetLoadInfo(DSSObj);
end

%%  Read in the profile for the file.
[Tprof,nvTprof,EventLogPD] = sg_loadTable(Profile,'returnType','cell');

if ~isempty(EventLogPD)
    r.EventLog = EventLogPD;
    return
end
profile       = struct();
profile.time  = Tprof(:,1);
profile.param = nvTprof(2:end);
profile.val   = Tprof(:,2:end);

idx = strfind(Profile,'.'); % name needs to include an extension
ProfileUpdated = [Profile(1:idx(end)-1) '_MRupdated' Profile(idx(end):end)];

%% 1st part: all none-load entries are to be kept
ColumnIdx = [];
for ii = 1:length(profile.param)
    isNotALoad = isempty(sg_rgrep(['^load\.'],lower(profile.param(ii))));
    if isNotALoad
        ColumnIdx = [ColumnIdx ii];
    end
end
if ~isempty(ColumnIdx)
    % write part to file
    ColumnStr = sg_Dec2Column(length(ColumnIdx)+1);
    [status,messages] = xlswrite(ProfileUpdated,{'time' profile.param{ColumnIdx}},1,...
        ['A1:' ColumnStr '1']);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
    [status,messages] = xlswrite(ProfileUpdated,[profile.time profile.val(:,ColumnIdx)],1,...
        ['A2:' ColumnStr num2str(length(profile.time)+1)]);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
end

%% 2nd part: enabled loads in INFO_LOAD
% expecting to find kW and kvar: both will be scaled by a complex number to
% find the new active and reactive parts
PQ = [];          % new profile data
LoadHeaders = {}; % corresponding headers
for ii = 1:length(INFO_LOAD.kW)
    if INFO_LOAD.enab(ii)
        % find (original) load name in profile
        idx = sg_rgrep(['^load\.' lower(INFO_LOAD.Name{INFO_LOAD.iNameIdx(ii)})],lower(profile.param));
        % add to saved data
        if ~isempty(idx)
            if length(idx) < 3
                idxkW   = idx(sg_rgrep([' kw'],lower(profile.param(idx))));
                idxkVAR = idx(sg_rgrep([' kvar'],lower(profile.param(idx))));
                S = (profile.val(:,idxkW) + 1i*profile.val(:,idxkVAR)) * INFO_LOAD.Ratio(ii);
                % add with (new) name to updated profile
                PQ = [PQ real(S) imag(S)];
                LoadHeaders{end+1} = ['load.' INFO_LOAD.Name{ii} ' kw'];
                LoadHeaders{end+1} = ['load.' INFO_LOAD.Name{ii} ' kvar'];
            else
                % load (name) was not just found once: should be kW and
                % kvar only
                r.EventLog{end+1} = sprintf('Load %s found with more than 2 entries in profile data.',INFO_LOAD.Name{ii});
                return
            end
        end        
    end
end
% save PQ data
if isempty(ColumnIdx)
    % with time vector
    ColumnStr = sg_Dec2Column(size(PQ,2)+1);
    [status,messages] = xlswrite(ProfileUpdated,[{'time'} LoadHeaders],1,...
        ['A1:' ColumnStr '1']);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
    [status,messages] = xlswrite(ProfileUpdated,[profile.time PQ],1,...
        ['A2:' ColumnStr num2str(length(profile.time)+1)]);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
else
    % without time vector
    ColumnStr1 = sg_Dec2Column(length(ColumnIdx)+2);
    ColumnStr2 = sg_Dec2Column(length(ColumnIdx)+size(PQ,2)+1);
    [status,messages] = xlswrite(ProfileUpdated,LoadHeaders,1,...
        [ColumnStr1 '1:' ColumnStr2 '1']);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
    [status,messages] = xlswrite(ProfileUpdated,PQ,1,...
        [ColumnStr1 '2:' ColumnStr2 num2str(length(profile.time)+1)]);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
end

%% 3rd part: collected loads
Ssp = [];         % source profile data
PQ   = [];        % new profile data
LoadHeaders = {}; % corresponding headers
if length(r.CollectedLoads) > 0
    % collect original load profile info
    for ii = 1:INFO_LOAD.N
        % find (original) load name in profile
        idx = sg_rgrep(['^load\.' lower(INFO_LOAD.Name{ii})],lower(profile.param));
        % add to original,source data matrix
        if ~isempty(idx)
            if length(idx) < 3
                idxkW   = idx(sg_rgrep([' kw'],lower(profile.param(idx))));
                idxkVAR = idx(sg_rgrep([' kvar'],lower(profile.param(idx))));
                Ssp = [Ssp profile.val(:,idxkW)+1i*profile.val(:,idxkVAR)];
            else
                % load (name) was not just found once: should be kW and
                % kvar only
                r.EventLog{end+1} = sprintf('Load %s found with more than 2 entries in profile data.',INFO_LOAD.Name{ii});
                return
            end
        else
            % no profile data for this load; skipping it by adding zeros.
            % will void the new profile in case this load is
            % multiplied by a ratio factor (>0) to compute a collected load's
            % profile
            Ssp = [Ssp zeros(length(profile.time),1)];
        end
    end
end
for ii = 1:length(r.CollectedLoads)
    % add ratios of kW/kvar for each new collected load:
    % find PQ-profile data for each of the original loads in INFO_LOAD,
    % scale and sum, add to new load data matrix
    S = Ssp * r.CollectedLoads(ii).LoadType.Ratio.';
    PQ = [PQ real(S) imag(S)];
    LoadHeaders{end+1} = ['load.' r.CollectedLoads(ii).LoadType.Name ' kw'];
    LoadHeaders{end+1} = ['load.' r.CollectedLoads(ii).LoadType.Name ' kvar'];
end
% save PQ data
if isempty(ColumnIdx) && sum(INFO_LOAD.enab)==0
    % with time vector
    ColumnStr = sg_Dec2Column(size(PQ,2)+1);
    [status,messages] = xlswrite(ProfileUpdated,[{'time'} LoadHeaders],1,...
        ['A1:' ColumnStr '1']);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
    [status,messages] = xlswrite(ProfileUpdated,[profile.time PQ],1,...
        ['A2:' ColumnStr num2str(length(profile.time)+1)]);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
else
    % without time vector
    ColumnStr1 = sg_Dec2Column(length(ColumnIdx)+sum(INFO_LOAD.enab)*2+2);
    ColumnStr2 = sg_Dec2Column(length(ColumnIdx)+sum(INFO_LOAD.enab)*2+size(PQ,2)+1);
    [status,messages] = xlswrite(ProfileUpdated,LoadHeaders,1,...
        [ColumnStr1 '1:' ColumnStr2 '1']);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
    [status,messages] = xlswrite(ProfileUpdated,PQ,1,...
        [ColumnStr1 '2:' ColumnStr2 num2str(length(profile.time)+1)]);
    if ~status
        r.EventLog{end+1} = messages.message;
        return;
    end
end

r.status = 1;
return

function NumStringOut = sg_Dec2Column(d)
% function NumStringOut = sg_Dec2Column(d)
%
% Helper function: converts decimal number to base 27 in alphabetical
% string form. I.e., is used to convert an integer column number into Excel
% column identifier.
%
% Examples:  1 --> A, 27 --> AA

ValueMap  = containers.Map({'1' '2' '3' '4' '5' '6' '7' '8' '9' 'A' 'B' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'J' 'K' 'L' 'M' 'N' 'O' 'P' 'Q'},...
    {'A' 'B' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'J' 'K' 'L' 'M' 'N' 'O' 'P' 'Q' 'R' 'S' 'T' 'U' 'V' 'W' 'X' 'Y' 'Z'});

NumStringIn  = dec2base(d,27);
NumStringOut = NumStringIn;

for ii = 1:length(NumStringIn)
    NumStringOut(ii) = ValueMap(NumStringIn(ii));
end

    