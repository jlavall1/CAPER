function [busv,linev] = sg_findAdjacentBuses(DSSObj,bus)
% Find adjacent buses (and lines).
% function [busv,linev] = sg_findAdjacentBuses(DSSObj,bus)
%  
% Uses extracted OpenDSS data to determine adjacent buses and corresponding connecting lines.
%
% Inputs: DSSObj	... OpenDSS handle
%		  bus		... bus name
% 
% Outputs: busv		... adjacent bus names
%		   linev	... adjacent line names
%
% Example Call(s):
%       [busNames,lineNames] = sg_findAdjacentBuses(DSSObj,'BusName');
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682


yline = sg_openDssGetLineInfo(DSSObj);
i1 = find(yline.enab==1);
yline.Name = yline.Name(i1);
yline.Bus1 = yline.Bus(i1,1);
yline.Bus2 = yline.Bus(i1,2);
i1l = sg_rgrep(['^' bus],yline.Bus1,'caseSensitive',0);
i2l = sg_rgrep(['^' bus],yline.Bus2,'caseSensitive',0);


busv = {};
linev = {};
N = 0;

if(length(i1l)>0)
    for(n = 1:length(i1l))
        N = N+1;
        busv{N} = yline.Bus2{i1l(n)};
        linev{N} = yline.Name{i1l(n)};
    end
end

if(length(i2l)>0)
    for(n = 1:length(i2l))
        N = N+1;
        busv{N} = yline.Bus1{i2l(n)};
        linev{N} = yline.Name{i2l(n)};
    end
end