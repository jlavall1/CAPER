function [KeyBusNames, CandidateBusNames] = sg_IDkeyBuses(varargin)
% Returns bus lists: keepers and reduction candidates.
% function [KeyBusNames, CandidateBusNames] = IDkeyBusesV2(varargin)
%
% Function for classification of buses into key buses that should be
% either retained or removed.
%
% Inputs: DSSObj	... OpenDSS COM interface connection
% 		  'Buses'	... buses explicitly identified by the user (a cell array of
%   					names) - DEFAULT = '', empty string
%   	  'BusExpr' ... buses with names matching a regular expression provided by
%   					the user (could be used with naming conventions to easily select
%   					portions of a feeder that need to be retained) - DEFAULT = '', empty
%   					string means no specific expression
%   	  'CBkvar'	... capacitor bank rating threshold (buses having capacitor banks
%   					with ratings higher than the threshold are retained)(default = -1,
%   					indicating that this option is not used)
%   	  'TapXFMR'	... retain buses with tap changing transformer (default=0)
%   	  'TransKVA'... transformer KVA rating threshold (buses having
%   					ratings higher than the threshold are retained)
%   	  'TransKV'	... transformer KV rating threshold (buses having
%   					ratings higher than the threshold are retained)
%   	  'GenKVA'	... generator kVA rating threshold (buses having generator units
%   					with ratings higher than the threshold are retained)
%   	  'LoadKVA' ... load KVA rating (buses with load KVA higher than the
%   					threshold are retained)
%   'ThreePhaseBus'	... option to retain all three phase buses
%   	  'kVRating ... all buses with voltage rating above this threshold are
%   					retained
%   	'VRatingEnd'... threshold voltage rating (buses at the end of a feeder
%   					segment with voltage rating above this threshold will be retained), 
%                       not yet implemented
%   	  'puVDev'	... per unit voltage deviation (all buses within the solved
%   					model having voltages that differ from nominal by more than this
%   					threshold value will be retained)
%
% Outputs: KeyBusNames			... array of bus names
%		   CandidateBusNames	... array of bus names
%
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682


DSSObj = varargin{1};

opts = struct('Buses','','BusExpr','','CBkvar',-1,'TapXFMR',0,'TransKVA',1,'TransKV',1,'GenKVA',1,...
    'LoadKVA',1,'ThreePhaseBus',0,'kVRating',1,'VRatingEnd',1,'puVDev',0.1);
opts = sg_updateOpts(opts,varargin,1);

DSSCircuit = DSSObj.ActiveCircuit;

CandidateBusNames = DSSCircuit.AllBusNames;   % at first all buses are candidate buses
KeyBusNames  = cell(size(CandidateBusNames)); % preallocate memory for 'worst' case
KeyBusEntry  = 0;                             % index/counter of key bus entries
NumBuses = length(CandidateBusNames);

% buses explicitly identified
if ~isempty(opts.Buses)
    % get vector of indices of elements in CandidateBusNames that are common to both arrays
    KeyBusIndex = find(ismember(CandidateBusNames,opts.Buses)); 
    if ~isempty(KeyBusIndex)
        KeyBusNames(KeyBusEntry+1:KeyBusEntry+length(KeyBusIndex)) = CandidateBusNames(KeyBusIndex);
        KeyBusEntry = KeyBusEntry + length(KeyBusIndex);
        CandidateBusNames(KeyBusIndex) = '';
    end
end

% bus expressions
if ~isempty(opts.BusExpr)
    KeyBusIndex = rgrep(opts.BusExpr,CandidateBusNames); 
    if ~isempty(KeyBusIndex)
        KeyBusNames(KeyBusEntry+1:KeyBusEntry+length(KeyBusIndex)) = CandidateBusNames(KeyBusIndex);
        KeyBusEntry = KeyBusEntry + length(KeyBusIndex);
        CandidateBusNames(KeyBusIndex) = '';
    end
end

% CBkvar: choice of keeping capacitors with kvar >= value but keep
% series capacitors, ignore caps. if CBkvar<=0
if opts.CBkvar >= 0
    CapNames = DSSCircuit.Capacitors.AllNames;
    for ii = 1:length(CapNames)
        element = DSSCircuit.CktElements(['capacitor.',CapNames{ii}]);
        buses   = element.get('bus');
        CapBus1 = buses{1};
        CapBus2 = buses{2};
        kVar = str2num(element.Properties('kvar').Val);
        idx = strfind(CapBus1,'.');
        if ~isempty(idx)
            CapBus1 = CapBus1(1:idx(1)-1);
        end
        idx = findstr(CapBus2,'.');
        if ~isempty(idx)
            CapBus2 = CapBus2(1:idx(1)-1);
        end
        isShunt = strcmpi(CapBus1,CapBus2);
        if ~isShunt || (kVar >= opts.CBkvar)
            % move from candiate (for removal) to key bus list (keepers)
            KeyBusIndex = find(ismember(CandidateBusNames,CapBus1));
            if ~isempty(KeyBusIndex)
                KeyBusEntry = KeyBusEntry + 1;
                KeyBusNames{KeyBusEntry} = CapBus1;
                CandidateBusNames(KeyBusIndex) = '';
            end
        end
    end
end

% Transformers (TapXFMR and TransKVA)
% keep all tap-changing transformers, keep transformers with both terminal voltages above 
% a given level
if opts.TapXFMR >= 0 || opts.TransKV >= 0 || opts.TransKVA >= 0 || opts.ThreePhaseBus >= 1 || opts.puVDev >= 0
    ii = DSSCircuit.Transformers.First;
    while ii
        Name    = DSSCircuit.Transformers.Name;
        element = DSSCircuit.CktElements(['transformer.',Name]);
        buses   = element.get('bus');
        hasVoltControl = element.get('hasVoltControl');
        kVs     = str2num(element.Properties('kvs').Val);
        kVAs    = str2num(element.Properties('kvas').Val);
        phases  = str2num(element.Properties('phases').Val);
        kVBase1 = DSSCircuit.Buses(buses{1}).kVBase; % phase
        kVBase2 = DSSCircuit.Buses(buses{2}).kVBase;
        kVsAct  = element.VoltagesMagAng(1:2:end)/1e3; % power flow solution
        idx = find(kVsAct ~= 0);
        kVsAct = kVsAct(idx);
        idx = strfind(buses,'.');
        for jj = 1:2
            if ~isempty(idx{jj})
                buses{jj} = buses{jj}(1:idx{jj}(1)-1);
            end
        end
        % retain tap changing transformers
        if (hasVoltControl && opts.TapXFMR>=0) || ...
                (sum(kVs >= opts.TransKV) > 1 && opts.TransKV >= 0) || ...
                (sum(kVAs >= opts.TransKVA) > 1 && opts.TransKVA >= 0) || ...
                (phases >= 3 && opts.ThreePhaseBus >= 1) || ...
                (sum(abs((kVsAct(1:end/2)-kVBase1)/kVBase1) >= opts.puVDev) >= 1 && opts.puVDev >= 0) || ...
                (sum(abs((kVsAct(end/2+1:end)-kVBase2)/kVBase2) >= opts.puVDev) >= 1 && opts.puVDev >= 0)
            for jj = 1:2
                KeyBusIndex = sg_rgrep(buses{jj},CandidateBusNames);
                if ~isempty(KeyBusIndex)
                    KeyBusEntry = KeyBusEntry + 1;
                    KeyBusNames{KeyBusEntry} = buses{jj};
                    CandidateBusNames(KeyBusIndex) = '';
                end
            end
        end
        ii = DSSCircuit.Transformers.Next;
    end
end

% GenKVA
if opts.GenKVA >= 0
    ii = DSSCircuit.Generators.First;
    while ii
        Name    = DSSCircuit.Generators.Name;
        element = DSSCircuit.CktElements(['generator.',Name]);
        bus     = element.get('bus');
        bus     = bus{1};
        kV      = str2num(element.Properties('kv').Val);
        kVA     = str2num(element.Properties('kva').Val);
        idx = strfind(bus,'.');
        if ~isempty(idx)
            bus = bus(1:idx(1)-1);
        end
        % retain by size
        if kVA >= opts.GenKVA
            KeyBusIndex = sg_rgrep(bus,CandidateBusNames);
            if ~isempty(KeyBusIndex)
                KeyBusEntry = KeyBusEntry + 1;
                KeyBusNames{KeyBusEntry} = bus;
                CandidateBusNames(KeyBusIndex) = '';
            end
        end
        ii = DSSCircuit.Generators.Next;
    end
end

% LoadKVA
if opts.LoadKVA >= 0
    ii = DSSCircuit.Loads.First;
    while ii
        Name    = DSSCircuit.Loads.Name;
        element = DSSCircuit.CktElements(['load.',Name]);
        bus     = element.get('bus');
        bus     = bus{1};
        kV      = str2num(element.Properties('kv').Val);
        kVA     = str2num(element.Properties('kva').Val);
        idx = strfind(bus,'.');
        if ~isempty(idx)
            bus = bus(1:idx(1)-1);
        end
        % retain by size
        if kVA >= opts.LoadKVA
            KeyBusIndex = sg_rgrep(bus,CandidateBusNames);
            if ~isempty(KeyBusIndex)
                KeyBusEntry = KeyBusEntry + 1;
                KeyBusNames{KeyBusEntry} = bus;
                CandidateBusNames(KeyBusIndex) = '';
            end
        end
        ii = DSSCircuit.Loads.Next;
    end
end

x1=cellfun(@isempty,KeyBusNames);
i1=find(~x1);
KeyBusNames=KeyBusNames(i1);