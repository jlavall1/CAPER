function y = sg_openDssGetTransformerInfo(varargin)
%  Get Transformer Information
%  function y = sg_openDssGetTransformerInfo(DSSObj)
%
%  Returns information about transformers in an openDSS model.
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%  Options;
%    Transformers - Either a cell array of strings or a single string.  If a cell
%      array, this is interpreted as a list of transformer names for which to get
%      information.  If a string, this is interpreted as a regular
%      expression pattern used to match transformer names.  The default value is the
%      regular expression '.*', indicating that information for all
%      transformers should be returned. 
%  Returns y
%    y - a structure of information.
%
% Examples: 
%   y = sg_openDssGetTransformerInfo(DSSObj);
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% January, 2015


DSSObj = varargin{1};

opts = struct('Transformers','.*');
opts = sg_updateOpts(opts,varargin,1);

y = struct();

if(iscell(opts.Transformers)  ==  0)
    lv = DSSObj.ActiveCircuit.Transformers.AllNames;
    if ~strcmpi(lv{1},'none')
        i1 = sg_rgrep(opts.Transformers,lv);
        opts.Transformers = lv(i1);
    else
        opts.Transformers = [];
    end
end

N = length(opts.Transformers);
y.Name = opts.Transformers;
y.Bus1 = repmat({'Bus1'},1,N);
y.Bus2 = repmat({'Bus2'},1,N);
y.NumPhases = zeros(1,N);
y.kV1 = zeros(1,N);
y.kV2 = zeros(1,N);
y.kVA = zeros(1,N);
y.Xhl = zeros(1,N);
y.Rs1 = zeros(1,N);
y.Rs2 = zeros(1,N);
y.BaseFreq = zeros(1,N);
y.enab = zeros(1,N);
y.wdgs = zeros(1,N);

for(n = 1:length(opts.Transformers))
    name = y.Name{n};
    x = DSSObj.ActiveCircuit.CktElements(['Transformer.' y.Name{n}]);
    y.Bus1{n} = x.BusNames{1};
    y.Bus2{n} = x.BusNames{2};
    y.NumPhases(n) = x.NumPhases;
    str1 = sprintf('? Transformer.%s.Kvs',name);
    DSSObj.Text.Command = str1;
    xx = str2num(DSSObj.Text.Result);
    y.kV1(n) = xx(1);
    y.kV2(n) = xx(2);
    str1 = sprintf('? Transformer.%s.kva',name);
    DSSObj.Text.Command = str1;
    y.kVA(n) = str2num(DSSObj.Text.Result);

    str1 = sprintf('? Transformer.%s.xhl',name);
    DSSObj.Text.Command = str1;
    y.Xhl(n) = str2num(DSSObj.Text.Result);
    str1 = sprintf('? Transformer.%s.%%Rs',name);
    DSSObj.Text.Command = str1;
    xx = str2num(DSSObj.Text.Result);
    y.Rs1(n) = xx(1);
    y.Rs2(n) = xx(2);
    str1 = sprintf('? Transformer.%s.basefreq',name);
    DSSObj.Text.Command = str1;
    y.BaseFreq(n) = str2num(DSSObj.Text.Result);
    y.enab(n) = x.Enabled;
    str1 = sprintf('? Transformer.%s.windings',name);
    DSSObj.Text.Command = str1;
    y.wdgs(n) = str2num(DSSObj.Text.Result);
end
