function r = sg_openDssMoveElements(varargin)

%  Move load or transformer elements from a bus to be removed to a neighboring bus in OpenDSS model.
%  function r = sg_openDssMoveElements(DSSObj,bus)
%
%  Prepare for removal of a bus from an OpenDSS model. Moves all elements
%  from one bus to another. Move can be across a line or a transformer,
%  which is connected at the specified bus.
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%    bus   - a string indicating the name of a bus to be removed.
%    busTo - a string indicating the name of a bus elements get moved to.
%  Options:
%  Returns r
%    r - a structure with the following fields
%      ElementNames - cell arrays of element names, which were relocated
%      ElementBuses - .from- and .to-buses of moved elements 
%      Actions - a string of the actions taken.
%      ActComment - a string summarizing the actions taken.
%      ActUnDo - a string of actions that reverse the actions taken.
%
%  Examples:
%    r = sg_openDssMoveElements(DSSObj,{{'Bus101') {'Bus100'}};
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% August 31, 2014

% Input arguments
DSSObj    = varargin{1};
busName   = varargin{2}{1};
busNameTo = varargin{2}{2};

% Init
DispFlag   = 0;    % turn on/off console display (0/1)
r  = struct();     % returning a structure
r.status   = 0;    % success status (0/1)
r.EventLog = {};   % keeps track of warning/error messages (cell array)
r.Actions  = {};   % actions taken
r.ActComment = {}; % summary of actions taken
r.ActUnDo  = {};   % undo-actions

%% Globals
global INFO_LINE INFO_TR INFO_LOAD INFO_GEN

if isempty(INFO_LINE)
    INFO_LINE = sg_openDssGetLineInfo(DSSObj);
end
if isempty(INFO_TR)
    INFO_TR = sg_openDssGetTransformerInfo(DSSObj);
end
if isempty(INFO_LOAD)
    INFO_LOAD = sg_openDssGetLoadInfo(DSSObj);
end
if isempty(INFO_GEN)
    INFO_GEN = sg_openDssGetGenInfo(DSSObj);
end

% string to cell
if ischar(busName)
    busName{1} = busName;
end
% convert to lower case bus names and remove node-info
for ii = 1:length(busName)
    idx = strfind(busName{ii},'.');
    if ~isempty(idx)
        busName{ii} = lower(busName{ii}(1:idx(1)-1));
    else
        busName{ii} = lower(busName{ii});
    end
end
for ii = 1:length(busNameTo)
    idx = strfind(busNameTo{ii},'.');
    if ~isempty(idx)
        busNameTo{ii} = lower(busNameTo{ii}(1:idx(1)-1));
    else
        busNameTo{ii} = lower(busNameTo{ii});
    end
end

% handle one bus at a time
MoveCount = 0;
for ii = 1:length(busName)
    % Bus info
    BuskV   = DSSObj.ActiveCircuit.Buses(busName{ii}).kVBase*sqrt(3);
    BusTokV = DSSObj.ActiveCircuit.Buses(busNameTo{ii}).kVBase*sqrt(3);
    
    % Identify element accross which components to move
    % Is it a line?
    i11 = sg_rgrep(['^' lower(busName{ii})],INFO_LINE.Bus(:,1));
    i12 = sg_rgrep(['^' lower(busName{ii})],INFO_LINE.Bus(:,2));
    i21 = sg_rgrep(['^' lower(busNameTo{ii})],INFO_LINE.Bus(:,1));
    i22 = sg_rgrep(['^' lower(busNameTo{ii})],INFO_LINE.Bus(:,2));
    % only include enabled lines
    enabi11 = find(INFO_LINE.enab(i11) > 0);
    enabi12 = find(INFO_LINE.enab(i12) > 0);
    enabi21 = find(INFO_LINE.enab(i21) > 0);
    enabi22 = find(INFO_LINE.enab(i22) > 0);
    i11 = i11(enabi11);
    i12 = i12(enabi12);
    i21 = i21(enabi21);
    i22 = i22(enabi22);
    ElemIdx = [];
    if ~isempty(i11) && ~isempty(i22),
        LineNo = intersect(i11,i22);
        if ~isempty(LineNo)
            ElemType = 1;%'line';
            ElemIdx = LineNo; % may be more than one line between buses
            ElemBusFromTo = [1 2];
        end
    end
    if ~isempty(i12) && ~isempty(i21), 
        LineNo = intersect(i12,i21);
        if ~isempty(LineNo)
            ElemType = 1;%'line';
            ElemIdx = LineNo; % may be more than one line between buses
            ElemBusFromTo = [2 1];
        end
    end
    % No line --> check transformers
    if isempty(ElemIdx)
        i11 = sg_rgrep(['^' lower(busName{ii})],INFO_TR.Bus1);
        i12 = sg_rgrep(['^' lower(busName{ii})],INFO_TR.Bus2);
        i21 = sg_rgrep(['^' lower(busNameTo{ii})],INFO_TR.Bus1);
        i22 = sg_rgrep(['^' lower(busNameTo{ii})],INFO_TR.Bus2);
        % only include enabled transformers
        enabi11 = find(INFO_TR.enab(i11) > 0);
        enabi12 = find(INFO_TR.enab(i12) > 0);
        enabi21 = find(INFO_TR.enab(i21) > 0);
        enabi22 = find(INFO_TR.enab(i22) > 0);
        if ~isempty(i11) && ~isempty(i22),
            TrNo = intersect(i11,i22);
            if ~isempty(TrNo)
                ElemType = 2; %'transformer';
                %                 ElemIdx = TrNo(1);
                ElemIdx = TrNo; % may be more than one
                ElemBusFromTo = [1 2];
            end
        end
        if ~isempty(i12) && ~isempty(i21),
            TrNo = intersect(i12,i21);
            if ~isempty(TrNo)
                ElemType = 2; %'transformer';
                %                 ElemIdx = TrNo(1);
                ElemIdx = TrNo; % may be more than one
                ElemBusFromTo = [2 1];
            end
        end
    end
    if isempty(ElemIdx)
        r.EventLog{end+1} = sprintf('Warning: Reducing circuit: Could not find element to shift across: %s - %s.',...
            busName{ii},busNameTo{ii});
        if DispFlag, fprintf('%s\n',r.EventLog{end}); end;
        return
    end
    
    % iterate over line/transformer candidates to cover all connection
    % possibilities
    for hh = 1:length(ElemIdx)
        % Note: this is a pointer! And points to the (current) element as
        % identified by name. Another call will change what variable Element
        % points to!
        if ElemType==1
            Element = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(hh)}]);
        else
            Element = DSSObj.ActiveCircuit.CktElements(['Transformer.' INFO_TR.Name{ElemIdx(hh)}]);
        end
        
        % Get line/transformer wire-node relationship for From and To ends (in
        % this order --> used below)
        for jj = 1:2
            idx = strfind(Element.Bus{ElemBusFromTo(jj)},'.');
            if isempty(idx)
                % determine wire-phase connections
                WirePhase{jj} = 1:Element.NumPhases;
            else
                % use existing wire-phase info
                WirePhase{jj} = str2num(strrep(Element.bus{ElemBusFromTo(jj)}(idx(1):end),'.',' '));
            end
        end
        
        % Find loads and move
        idx = strfind(INFO_LOAD.Bus,busName{ii});
        CompIdx = [];
        for jj = 1:length(idx)
            if ~isempty(idx{jj})
                CompIdx = [CompIdx jj];
            end
        end
        for jj = 1:length(CompIdx)
            idx = strfind(INFO_LOAD.Bus{CompIdx(jj)},'.');
            if isempty(idx)
                % default wire-phase connections
                CompWirePhase = 1:INFO_LOAD.NumPhases(CompIdx(jj));
            else
                % use existing wire-phase info
                CompWirePhase = str2num(strrep(INFO_LOAD.Bus{CompIdx(jj)}(idx(1):end),'.',' '));
            end
            % trace wiring for proper node connections
            node = [];
            if length(CompWirePhase) <= length(WirePhase{1})
                for kk = 1:length(CompWirePhase)
                    idx = find(CompWirePhase(kk) == WirePhase{1});
                    if ~isempty(idx)
                        node(kk) = WirePhase{2}(idx);
                    else
                        % component is on a different phase/wire
                        node(kk) = -1;
                    end
                end
            else
                for kk = 1:length(WirePhase{1})
                    idx = find(CompWirePhase == WirePhase{1}(kk));
                    if ~isempty(idx)
                        node(kk) = WirePhase{2}(idx);
                    else
                        % component is on a different phase/wire
                        node(kk) = -1;
                    end
                end
                % appending remaining connections
                node = [node CompWirePhase(length(WirePhase{1})+1:end)];
            end
            if ~any(node == -1)
                % all nodes connected
                NewLoadBus = [busNameTo{ii} sprintf('.%.0f',node)];
                CurrentkV = str2num(DSSObj.ActiveCircuit.CktElements(['load.' INFO_LOAD.Name{CompIdx(jj)}]).Properties('kV').val);
                str1 = sprintf('edit Load.%s bus=%s kV=%f',INFO_LOAD.Name{CompIdx(jj)},NewLoadBus,CurrentkV*BusTokV/BuskV);
                DSSObj.Text.Command = str1;
                r.ActComment{end+1} = sprintf('Move Elements: From bus %s: Moved Load.%s to bus=%s at kV=%f',...
                    busName{ii},INFO_LOAD.Name{CompIdx(jj)},NewLoadBus,BusTokV);
                r.Actions{end+1} = str1;
                r.ActUnDo{end+1} = sprintf('edit Load.%s bus=%s kV=%f',...
                    INFO_LOAD.Name{CompIdx(jj)}, INFO_LOAD.Bus{CompIdx(jj)}, BuskV);
                % keep track of moved elements
                MoveCount = MoveCount + 1;
                r.ElementNames{MoveCount} = ['load.' INFO_LOAD.Name{CompIdx(jj)}];
                r.ElementBuses.From{MoveCount} = INFO_LOAD.Bus{CompIdx(jj)};
                r.ElementBuses.To{MoveCount} = NewLoadBus;
                % update load structure (in case of multiple shifts)
                INFO_LOAD.Bus{CompIdx(jj)} = NewLoadBus;
                INFO_LOAD.kV(CompIdx(jj))  = CurrentkV*BusTokV/BuskV;                
            end
        end
    end
    
    % Find transformers and move: reconnects primary bus, does not modify
    % others
    idx = strfind(INFO_TR.Bus1,busName{ii}); % assuming primary side gets reconnected
    CompIdx = [];
    for jj = 1:length(idx)
        if ~isempty(idx{jj})
            CompIdx = [CompIdx jj];
        end
    end
    for jj = 1:length(CompIdx)
        idx = strfind(INFO_TR.Bus1{CompIdx(jj)},'.');
        if isempty(idx)
            % default wire-phase connections
            CompWirePhase = [1:INFO_TR.NumPhases(CompIdx(jj)) 0];
        else
            % use existing wire-phase info
            CompWirePhase = str2num(strrep(INFO_TR.Bus1{CompIdx(jj)}(idx(1):end),'.',' '));
        end
        % trace wiring for proper node connections
        node = [];
        if length(CompWirePhase) <= length(WirePhase{1})
            for kk = 1:length(CompWirePhase)
                idx = find(CompWirePhase(kk) == WirePhase{1});
                node(kk) = WirePhase{2}(idx);
            end
        else
            for kk = 1:length(WirePhase{1})
                idx = find(CompWirePhase == WirePhase{1}(kk));
                node(kk) = WirePhase{2}(idx);
            end
            % appending remaining connections
            node = [node CompWirePhase(length(WirePhase{1})+1:end)];
        end
        NewTrBus = [busNameTo{ii} sprintf('.%.0f',node)];
        str1 = sprintf('edit Transformer.%s wdg=1 bus=%s kV=%f',...
            INFO_TR.Name{CompIdx(jj)},NewTrBus,INFO_TR.kV1(CompIdx(jj))*BusTokV/BuskV);
        DSSObj.Text.Command = str1;
        r.ActComment{end+1} = sprintf('Move Elements: From bus %s: Moved Transformer.%s buses=(%s %s) kvs=(%f %f)',...
            busName{ii},INFO_TR.Name{CompIdx(jj)},NewTrBus,INFO_TR.Bus2{CompIdx(jj)},BusTokV,INFO_TR.kV2(CompIdx(jj)));
        r.Actions{end+1} = str1;
        r.ActUnDo{end+1} = sprintf('edit Transformer.%s wdg=1 bus=%s kV=%f',...
            INFO_TR.Name{CompIdx(jj)}, INFO_TR.Bus1{CompIdx(jj)}, INFO_TR.kV1(CompIdx(jj)));
        % update structure (in case of multiple shifts)
        INFO_TR.Bus1{CompIdx(jj)} = NewTrBus;
        INFO_TR.kV1{CompIdx(jj)}  = INFO_TR.kV1(CompIdx(jj))*BusTokV/BuskV; 
    end
 end
r.status = 1;