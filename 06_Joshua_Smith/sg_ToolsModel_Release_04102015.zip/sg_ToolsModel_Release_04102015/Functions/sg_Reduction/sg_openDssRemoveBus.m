function r = sg_openDssRemoveBus(varargin)

%  Remove Radial Bus in OpenDSS Model
%  function r = sg_openDssRemoveBus(DSSObj,bus)
%
%  Two cases are handled: 
%  Remove a single radial bus from an OpenDSS model. Assumes that no loads or
%  generators are connected at the bus to be removed. These loads and generators
%  have to be moved with another function call (split/move) before.
%  Remove a bus that connects two lines. Lines are combined into one if compatible,
%  i.e., number of phases is the same. Phase-node relationships are considered to 
%  preserve phase relationships. 
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%    bus - a string indicating the name of a bus to be removed.
%  Options:
%  Returns [r,txt]
%    r - a structure with the following fields
%      NewElements ... cell arrays of newly created lines
%      RemovedElements ... replaced line sections
%      Actions ... a string of the actions taken.
%      ActComment ... a string summarizing the actions taken.
%      ActUnDo ... a string of actions that reverse the actions taken.
%
%  Examples:
%    r = sg_openDssRemoveBus(DSSObj,'Bus101');
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% January 27, 2015

% Input arguments
DSSObj  = varargin{1};
busName = lower(varargin{2});
for ii = 1:length(busName)
    idx = strfind(busName{ii},'.');
    if ~isempty(idx)
        busName{ii} = busName{ii}(1:idx(1)-1);
    end
end

%% Init
DispFlag = 0;    % turn on/off console display (0/1)
r = struct();     % returning a structure
r.status   = 0;    % success status (0/1)
r.EventLog = {};   % keeps track of warning/error messages (cell array)
r.Actions  = {};   % actions taken
r.ActComment = {}; % summary of actions taken
r.ActUnDo  = {};   % undo-actions

%% Globals
global INFO_LINE INFO_TR

if isempty(INFO_LINE)
    INFO_LINE = sg_openDssGetLineInfo(DSSObj);
end
if isempty(INFO_TR)
    INFO_TR = sg_openDssGetTransformerInfo(DSSObj);
end
if ischar(busName)
    busName{1} = busName;
end

% Taking care of one energy meter in circuit: update measured line elements 
M.Obj     = DSSObj.ActiveCircuit.Meters;
M.Obj.First;
M.Name    = M.Obj.Name;
M.Element = M.Obj.MeteredElement;
if ~isempty(sg_rgrep(['^line\.'],{lower(M.Element)}))
    M.WatchLine = 1;
else
    M.WatchLine = 0;
end

% Reduction
Lcount = 0;
for ii = 1:length(busName)
    %% Find the number of lines and/or transformers connected to the bus and
    % verify that the bus is a radial bus (only 1 or 2 connected branches).
    % identify line candiates 
    i1l = sg_rgrep(['^' busName{ii}],INFO_LINE.Bus(:,1));
    i2l = sg_rgrep(['^' busName{ii}],INFO_LINE.Bus(:,2));
    i1t = sg_rgrep(['^' busName{ii}],INFO_TR.Bus1);
    i2t = sg_rgrep(['^' busName{ii}],INFO_TR.Bus2);
    % only include enabled lines
    enabi1l = find(INFO_LINE.enab(i1l) > 0);
    enabi2l = find(INFO_LINE.enab(i2l) > 0);
    enabi1t = find(INFO_TR.enab(i1t) > 0);
    enabi2t = find(INFO_TR.enab(i2t) > 0);
    i1l = i1l(enabi1l);
    i2l = i2l(enabi2l);
    i1t = i1t(enabi1t);
    i2t = i2t(enabi2t);
    % active connections found
    Nlines = length(i1l) + length(i2l);
    Ntr    = length(i1t) + length(i2t);
    % involved buses (allow multiple lines between two buses)
    OtherLineBuses = {INFO_LINE.Bus{i1l,2}; INFO_LINE.Bus{i2l,1}}; 
    for jj = 1:length(OtherLineBuses)
        idx = strfind(OtherLineBuses{jj},'.');
        if ~isempty(idx)
            OtherLineBuses{jj} = OtherLineBuses{jj}(1:idx(1)-1);
        end
    end
    OtherLineBuses = unique(OtherLineBuses);
    
    if Nlines > 2 && length(OtherLineBuses) > 1
        r.EventLog{end+1} = sprintf('Warning: The specified bus, Bus %s, has more than two lines connecting more than two buses. Bus not removed.',busName{ii});
        if DispFlag,
            fprintf('%s\n',r.EventLog{end});
        end
        return
    end
    if Ntr > 1
        r.EventLog{end+1} = sprintf('Warning: The specified bus, Bus %s, has more than one transformer connected. Bus not removed.',busName{ii});
        if DispFlag,
            fprintf('%s\n',r.EventLog{end});
        end
        return
    end
    if Nlines == 0 & Ntr == 0
        r.EventLog{end+1} = sprintf('Warning: The specified bus, Bus %s, does not exist. Bus not removed.',busName{ii});
        if DispFlag,
            fprintf('%s\n',r.EventLog{end});
        end
        return
    end
    
    %% Handle bus removal options
    if Nlines + Ntr == 1
        %  If there is only one connecting branch (or one other bus),
        %  simply remove (disable) the branch(es)
        if Nlines == 1
            if (length(i1l) == 1)
                ElemName = INFO_LINE.Name{i1l};
                INFO_LINE.enab(i1l) = 0;
            else
                ElemName = INFO_LINE.Name{i2l};
                INFO_LINE.enab(i2l) = 0;
            end
            str1 = sprintf('Line.%s',ElemName);
        else
            if (length(i1t) == 1)
                ElemName = INFO_TR.Name{i1t};
                INFO_TR.enab(i1t) = 0;
            else
                ElemName = INFO_TR.Name{i2t};
                INFO_TR.enab(i2t) = 0;
            end
            str1 = sprintf('Transformer.%s',ElemName);
        end
        % Actions for OpenDSS model
        r.Actions{end+1} = ['Disable ' str1];
        DSSObj.Text.Command = ['Disable ' str1];
        r.ActComment{end+1} = ['Remove bus: Dangling end removed: ' str1];
        r.ActUnDo{end+1} = ['Enable ' str1];
        
        % Informational data: chance in model elements
        Lcount = Lcount + 1;
        r.RemovedElements{Lcount} = str1;
        r.NewElements{Lcount} = '';
    elseif length(OtherLineBuses) == 1 && Ntr == 0
        %  If there are multiple branches between two buses, no transformer
        for jj = 1:length(i1l)
            ElemName = INFO_LINE.Name{i1l(jj)};
            INFO_LINE.enab(i1l(jj)) = 0;
            str1 = sprintf('Line.%s',ElemName);
            
            r.Actions{end+1} = ['Disable ' str1];
            DSSObj.Text.Command = ['Disable ' str1];
            r.ActComment{end+1} = ['Remove bus: Dangling end removed: ' str1];
            r.ActUnDo{end+1} = ['Enable ' str1];
            
            Lcount = Lcount + 1;
            r.RemovedElements{Lcount} = str1;
            r.NewElements{Lcount} = '';
        end
        for jj = 1:length(i2l)
            ElemName = INFO_LINE.Name{i2l(jj)};
            INFO_LINE.enab(i2l(jj)) = 0;
            str1 = sprintf('Line.%s',ElemName);
            
            r.Actions{end+1} = ['Disable ' str1];
            DSSObj.Text.Command = ['Disable ' str1];
            r.ActComment{end+1} = ['Remove bus: Dangling end removed: ' str1];
            r.ActUnDo{end+1} = ['Enable ' str1];
            
            Lcount = Lcount + 1;
            r.RemovedElements{Lcount} = str1;
            r.NewElements{Lcount} = '';
        end
    elseif Nlines == 2
        % Eliminate connecting bus. Assuming no elements (e.g., loads) are connected.
        if length(i1l) == 1 & length(i2l) == 1
            ElemIdx(1) = i1l;
            Element{1} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(1)}]).Name;
            ElemBusFromTo(1,:) = [2 1];
            ElemIdx(2) = i2l;
            Element{2} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(2)}]).Name;
            ElemBusFromTo(2,:) = [2 1];
            Buses = {INFO_LINE.Bus{i1l,2} INFO_LINE.Bus{i1l,1}; INFO_LINE.Bus{i2l,2} INFO_LINE.Bus{i2l,1};};
            NumPhases = [INFO_LINE.NumPhases(i1l) INFO_LINE.NumPhases(i2l)];
            DisableIndex = i1l;
            KeepIndex = i2l;
        elseif length(i1l) == 2
            ElemIdx(1) = i1l(1);
            Element{1} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(1)}]).Name;
            ElemBusFromTo(1,:) = [2 1];
            ElemIdx(2) = i1l(2);
            Element{2} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(2)}]).Name;
            ElemBusFromTo(2,:) = [1 2];
            Buses = {INFO_LINE.Bus{i1l(1),2} INFO_LINE.Bus{i1l(1),1}; INFO_LINE.Bus{i1l(2),1} INFO_LINE.Bus{i1l(2),2}};
            NumPhases = [INFO_LINE.NumPhases(i1l(1)) INFO_LINE.NumPhases(i1l(2))];
            DisableIndex = i1l(1);
            KeepIndex = i1l(2);
        elseif length(i2l) == 2
            ElemIdx(1) = i2l(1);
            Element{1} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(1)}]).Name;
            ElemBusFromTo(1,:) = [2 1];
            ElemIdx(2) = i2l(2);
            Element{2} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(2)}]).Name;
            ElemBusFromTo(2,:) = [1 2];
            Buses = {INFO_LINE.Bus{i2l(1),1} INFO_LINE.Bus{i2l(1),2}; INFO_LINE.Bus{i2l(2),2} INFO_LINE.Bus{i2l(2),1}};
            NumPhases = [INFO_LINE.NumPhases(i2l(1)) INFO_LINE.NumPhases(i2l(2))];
            DisableIndex = i2l(1);
            KeepIndex = i2l(2);
        end
        % check phase number consistency
        if NumPhases(1) ~= NumPhases(2)
            r.EventLog{end+1} = sprintf('Warning: Lines (%s and %s) found at bus (%s) do not have the same number of phases (%.0f and %.0f): Bus not removed.',...
                INFO_LINE.Name{ElemIdx(1)},INFO_LINE.Name{ElemIdx(2)},busName{ii},NumPhases(1),NumPhases(2));
            if DispFlag,
                fprintf('%s\n',r.EventLog{end});
            end
            return
        end
        % Will remove this line (but update info on the other)
        INFO_LINE.enab(DisableIndex) = 0;
    
        % Get wire-node relationship for From and To ends (in
        % this order --> used below)
        for kk = 1:2 % elements 
            for jj = 1:2 % buses
                idx = strfind(Buses{kk,jj},'.');
                if isempty(idx)
                    % default wire-phase connections
                    WirePhase{kk,jj} = 1:DSSObj.ActiveCircuit.CktElements(Element{kk}).NumPhases;
                    BusName{kk,jj} = Buses{kk,jj};
                else
                    % use existing wire-phase info
                    WirePhase{kk,jj} = str2num(strrep(Buses{kk,jj}(idx(1):end),'.',' '));
                    BusName{kk,jj} = Buses{kk,jj}(1:idx(1)-1);
                end
            end
        end
        
        % connect the two lines: keep one Bus.Phases and find second
        % Bus.Phases
        node = [];
        for kk = 1:length(WirePhase{1,1})
            idx = find(WirePhase{2,1} == WirePhase{1,2}(kk));
            node(kk) = WirePhase{2,2}(idx);
        end
        BusTo   = [BusName{1,1} sprintf('.%.0f',WirePhase{1,1})]; % to <--> from
        BusFrom = [BusName{2,2} sprintf('.%.0f',node)];
              
        % create new combined line
        llen1 = INFO_LINE.llen(ElemIdx(1));
        llen2 = INFO_LINE.llen(ElemIdx(2));
        llen  = sg_sumLengths([llen1 llen2],{INFO_LINE.unit{ElemIdx(1)} INFO_LINE.unit{ElemIdx(2)}});
        if ~isempty(INFO_LINE.r1{ElemIdx(1)}) & ~isempty(INFO_LINE.r1{ElemIdx(2)})
            % use sequence components
            r1 = (INFO_LINE.r1{ElemIdx(1)}*llen1 + INFO_LINE.r1{ElemIdx(2)}*llen2)/llen.l;
            x1 = (INFO_LINE.x1{ElemIdx(1)}*llen1 + INFO_LINE.x1{ElemIdx(2)}*llen2)/llen.l;
            r0 = (INFO_LINE.r0{ElemIdx(1)}*llen1 + INFO_LINE.r0{ElemIdx(2)}*llen2)/llen.l;
            x0 = (INFO_LINE.x0{ElemIdx(1)}*llen1 + INFO_LINE.x0{ElemIdx(2)}*llen2)/llen.l;
            C1 = (INFO_LINE.C1{ElemIdx(1)}*llen1 + INFO_LINE.C1{ElemIdx(2)}*llen2)/llen.l;
            C0 = (INFO_LINE.C0{ElemIdx(1)}*llen1 + INFO_LINE.C0{ElemIdx(2)}*llen2)/llen.l;
            
            if DSSObj.ActiveCircuit.Buses(BusName{1,1}).Distance > DSSObj.ActiveCircuit.Buses(BusName{2,2}).Distance
                %r.ActUnDo{end+1} = ['Disable Line.' BusName{2,2} '_' BusName{1,1}];
                INFO_LINE.Name{ElemIdx(2)} = [BusName{2,2} '_' BusName{1,1}];
                INFO_LINE.Bus{ElemIdx(2),1} = BusFrom;
                INFO_LINE.Bus{ElemIdx(2),2} = BusTo;
            else
                %r.ActUnDo{end+1} = ['Disable Line.' BusName{1,1} '_' BusName{2,2}];
                INFO_LINE.Name{ElemIdx(2)} = [BusName{1,1} '_' BusName{2,2}];
                INFO_LINE.Bus{ElemIdx(2),1} = BusTo;
                INFO_LINE.Bus{ElemIdx(2),2} = BusFrom;
            end
            str1 = sprintf('new Line.%s bus1=%s bus2=%s phases=%f r1=%f x1=%f r0=%f x0=%f C1=%f C0=%f length=%f units=%s',...
                INFO_LINE.Name{ElemIdx(2)},INFO_LINE.Bus{ElemIdx(2),1},INFO_LINE.Bus{ElemIdx(2),2},NumPhases(1),r1,x1,r0,x0,C1,C0,llen.l,llen.u); % {1),{2}
            DSSObj.Text.Command = str1;
            r.Actions{end+1} = str1;
            r.ActComment{end+1} = sprintf('Remove bus: Combined new Line.%s bus1=%s bus2=%s length=%f units=%s',...
                INFO_LINE.Name{ElemIdx(2)},INFO_LINE.Bus{ElemIdx(2),1},INFO_LINE.Bus{ElemIdx(2),2},llen.l,llen.u);
            r.ActUnDo{end+1} = ['Disable Line.' INFO_LINE.Name{ElemIdx(2)}];
            % update global info (using/keeping second element)
            INFO_LINE.r1{ElemIdx(2)} = r1;
            INFO_LINE.x1{ElemIdx(2)} = x1;
            INFO_LINE.r0{ElemIdx(2)} = r0;
            INFO_LINE.x0{ElemIdx(2)} = x0;
            INFO_LINE.C1{ElemIdx(2)} = C1;
            INFO_LINE.C0{ElemIdx(2)} = C0;
            INFO_LINE.llen(ElemIdx(2)) = llen.l;
            INFO_LINE.unit{ElemIdx(2)} = llen.u;
            INFO_LINE.rmatrix{ElemIdx(2)} = [];
            INFO_LINE.xmatrix{ElemIdx(2)} = [];
            INFO_LINE.cmatrix{ElemIdx(2)} = [];
        else
            % matrix approach
            rm = (INFO_LINE.rmatrix{ElemIdx(1)}*llen1 + INFO_LINE.rmatrix{ElemIdx(2)}*llen2)/llen.l;
            xm = (INFO_LINE.xmatrix{ElemIdx(1)}*llen1 + INFO_LINE.xmatrix{ElemIdx(2)}*llen2)/llen.l;
            cm = (INFO_LINE.cmatrix{ElemIdx(1)}*llen1 + INFO_LINE.cmatrix{ElemIdx(2)}*llen2)/llen.l;

            rmstr = sg_Matrix2String(rm);
            xmstr = sg_Matrix2String(xm);
            cmstr = sg_Matrix2String(cm);
            
            str1 = sprintf('new Line.%s_%s bus1=%s bus2=%s phases=%f rmatrix=%s xmatrix=%s cmatrix=%s length=%f units=%s',...
                BusName{2,2},BusName{1,1},BusFrom,BusTo,NumPhases(1),rmstr,xmstr,cmstr,llen.l,llen.u);
            DSSObj.Text.Command = str1;
            r.Actions{end+1} = str1;
            r.ActComment{end+1} = sprintf('Combined new Line.%s_%s bus1=%s bus2=%s length=%f units=%s',...
                            BusName{2,2},BusName{1,1},BusFrom,BusTo,llen.l,llen.u);
            r.ActUnDo{end+1} = ['Disable Line.' BusName{2,2} '_' BusName{1,1}];
            % update global info (using/keeping second element)
            INFO_LINE.Name{ElemIdx(2)} = [BusName{2,2} '_' BusName{1,1}];
            INFO_LINE.Bus{ElemIdx(2),1} = BusFrom;
            INFO_LINE.Bus{ElemIdx(2),2} = BusTo;
            INFO_LINE.r1{ElemIdx(2)} = [];
            INFO_LINE.x1{ElemIdx(2)} = [];
            INFO_LINE.r0{ElemIdx(2)} = [];
            INFO_LINE.x0{ElemIdx(2)} = [];
            INFO_LINE.C1{ElemIdx(2)} = [];
            INFO_LINE.C0{ElemIdx(2)} = [];
            INFO_LINE.llen(ElemIdx(2)) = llen.l;
            INFO_LINE.unit{ElemIdx(2)} = llen.u;
            INFO_LINE.rmatrix{ElemIdx(2)} = rm;
            INFO_LINE.xmatrix{ElemIdx(2)} = xm;
            INFO_LINE.cmatrix{ElemIdx(2)} = cm;
        end

        % disable original lines
        str1 = sprintf('Disable %s',Element{1});
        DSSObj.Text.Command = str1;
        r.Actions{end+1} = str1;
        r.ActComment{end+1} = ['Remove bus: Replaced line section: ' Element{1}];
        str1 = sprintf('Disable %s',Element{2});
        DSSObj.Text.Command = str1;
        r.ActUnDo{end+1} = ['Enable ' Element{1}];
        r.Actions{end+1} = str1;
        r.ActComment{end+1} = ['Remove bus: Replaced line section: ' Element{2}];
        r.ActUnDo{end+1} = ['Enable ' Element{2}];
        Lcount = Lcount + 1;
        r.NewElements{Lcount} = ['Line.' BusName{2,2} '_' BusName{1,1}];
        r.RemovedElements{Lcount} = {Element{1}  Element{2}};
        % may need to update energy meter
        if M.WatchLine
            if strcmpi(M.Element,lower(Element{1})) || strcmpi(M.Element,lower(Element{2}))
                DSSObj.Text.Command = ['edit EnergyMeter.' M.Name ' element=line.' INFO_LINE.Name{ElemIdx(2)}];
            end
        end
    end
end
r.status = 1;