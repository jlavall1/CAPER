function r = sg_openDssSplitBus(varargin)

%  Move elements from a bus to be removed to neighboring buses in OpenDSS model.
%  function r = sg_openDssSplitBus(DSSObj,busName,)
%
%  Split load at a bus into two components and connect to neighboring buses. 
%  Expecting that exactly two lines are connected at the bus.
%
%  Parameters:
%    DSSObj    - OpenDSS COM interface connection
%    busName   - a string (cell array) indicating the name of original bus 
%                of connection
%    busNameTo - String array (cell) of neighboring buses for (load)
%                reconnection (original load will be split between these
%                two buses according to line impedance ratios
%  Options:
%    scaling - means of computing ratios used to split loads into two
%              parts:
%              1: positive sequence impedance (default)
%  Returns [r]
%    r - a structure with the following fields
%      SplitLoads - cell array of load names 
%      loadFactors - an array of values indicating the proportion of the
%        load on the removed bus that was added to each of the buses
%        indicated by the loadBuses field
%      NewLoadNames - List of load names for the two load fractions
%      Actions - a string of the actions taken.
%      ActComment - a string summarizing the actions taken.
%      ActUnDo - a string of actions that reverse the actions taken.
%
%  Examples:
%    r = sg_openDssSplitBus(DSSObj,{{'Bus101') {'Bus100' 'Bus102'}};
%
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% February 20, 2015

% Defaults / choices
% load scaling
ch.Scaling.posseq = 1;  % positive sequence impedance
ch.Scaling.ims    = 2;  % impedance matrix scalar

Scaling   = ch.Scaling.posseq; % only choice implemented so far

% Input arguments
DSSObj    = varargin{1};
busName   = varargin{2}{1};
busNameTo = varargin{2}{2};
if length(varargin{2}) > 2
    for ii = 3:2:length(varargin)
        switch lower(varargin{ii})
            case 'scaling'
                Scaling = varargin{ii+1};
        end
    end
end
% remove node-info in case it's part of the bus name
for ii = 1:length(busName)
    idx = strfind(busName{ii},'.');
    if ~isempty(idx)
        busName{ii} = lower(busName{ii}(1:idx(1)-1));
    else
        busName{ii} = lower(busName{ii});
    end
end
for ii = 1:length(busNameTo)
    for jj = 1:2
        idx = strfind(busNameTo{ii}{jj},'.');
        if ~isempty(idx)
            busNameTo{ii}{jj} = lower(busNameTo{ii}{jj}(1:idx(1)-1));
        else
            busNameTo{ii}{jj} = lower(busNameTo{ii}{jj});
        end
    end
end

% Init
DispFlag   = 1;    % turn on/off console display (0/1)
r  = struct();     % returning a structure
r.status   = 0;    % success status (0/1)
r.EventLog = {};   % keeps track of warning/error messages (cell array)
r.Actions  = {};   % actions taken
r.ActComment = {}; % summary of actions taken
r.ActUnDo  = {};   % undo-actions

%% Globals
global INFO_LINE INFO_TR INFO_LOAD %INFO_LOADRATIO

if isempty(INFO_LINE)
    INFO_LINE = sg_openDssGetLineInfo(DSSObj);
end
if isempty(INFO_TR)
    INFO_TR = sg_openDssGetTransformerInfo(DSSObj);
end
if isempty(INFO_LOAD)
    INFO_LOAD = sg_openDssGetLoadInfo(DSSObj);
end


% Conversion elements (loads, generators) into
LoadNames = INFO_LOAD.Name; % will add loads below: keep track of names already used

% Distribution elements
% below:  Find the number of lines and/or transformers connected to the bus and
%  verify that the bus is a radial bus (only 1 or 2 connected branches).
TrNames = INFO_TR.Name; % will add transformers below: keep track of names already used

% handle one bus at a time
for ii = 1:length(busName)
    % Bus info
    % nominal voltage (phase)
    BuskV   = DSSObj.ActiveCircuit.Buses(busName{ii}).kVBase;
    
    i11 = sg_rgrep(['^' busName{ii}],INFO_LINE.Bus(:,1));      % current location
    i12 = sg_rgrep(['^' busName{ii}],INFO_LINE.Bus(:,2));
    i21 = sg_rgrep(['^' busNameTo{ii}{1}],INFO_LINE.Bus(:,1)); % New bus #1
    i22 = sg_rgrep(['^' busNameTo{ii}{1}],INFO_LINE.Bus(:,2));
    i31 = sg_rgrep(['^' busNameTo{ii}{2}],INFO_LINE.Bus(:,1)); % New bus #2
    i32 = sg_rgrep(['^' busNameTo{ii}{2}],INFO_LINE.Bus(:,2));
     % only include enabled lines
    enabi11 = find(INFO_LINE.enab(i11) > 0);
    enabi12 = find(INFO_LINE.enab(i12) > 0);
    enabi21 = find(INFO_LINE.enab(i21) > 0);
    enabi22 = find(INFO_LINE.enab(i22) > 0);
    enabi31 = find(INFO_LINE.enab(i31) > 0);
    enabi32 = find(INFO_LINE.enab(i32) > 0);
    i11 = i11(enabi11);
    i12 = i12(enabi12);
    i21 = i21(enabi21);
    i22 = i22(enabi22);
    i31 = i31(enabi31);
    i32 = i32(enabi32);
    % Identify lines
    ElemIdx = [];
    Element = {};
    % Identify 1st line
    if ~isempty(i11) && ~isempty(i22),
        LineNo = intersect(i11,i22);
        if ~isempty(LineNo)
            % bus found at From- and To-ends for at least one line: in case
            % of parallel lines: assuming they have the same characteristics
            ElemIdx(1) = LineNo(1);
            Element{1} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(1)}]).Name;
            ElemBusFromTo(1,:) = [1 2];
        end
    end
    if ~isempty(i12) && ~isempty(i21),
        LineNo = intersect(i12,i21);
        if ~isempty(LineNo)
            ElemIdx(1) = LineNo(1);
            Element{1} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(1)}]).Name;
            ElemBusFromTo(1,:) = [2 1];
        end
    end
    BusTokV(1) = DSSObj.ActiveCircuit.Buses(busNameTo{ii}{1}).kVBase*sqrt(3);
    if isempty(Element)
        r.EventLog{end+1} = sprintf('Warning: Reducing circuit: Split bus: Could not find 1st line to shift across: %s - %s.',...
            busName{ii},busNameTo{ii}{1});
        if DispFlag, fprintf('%s\n',r.EventLog{end}); end;
        return
    end
    % Identify 2nd line
    if ~isempty(i11) && ~isempty(i32),
        LineNo = intersect(i11,i32);
        if ~isempty(LineNo)
            % bus found at From- and To-ends for at least one line
            ElemIdx(2) = LineNo(1);
            Element{2} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(2)}]).Name;
            ElemBusFromTo(2,:) = [1 2];
        end
    end
    if ~isempty(i12) && ~isempty(i31),
        LineNo = intersect(i12,i31);
        if ~isempty(LineNo)
            ElemIdx(2) = LineNo(1);
            Element{2} = DSSObj.ActiveCircuit.CktElements(['Line.' INFO_LINE.Name{ElemIdx(2)}]).Name;
            ElemBusFromTo(2,:) = [2 1];
        end
    end
    BusTokV(2) = DSSObj.ActiveCircuit.Buses(busNameTo{ii}{2}).kVBase*sqrt(3);
    if length(Element)~=2
        r.EventLog{end+1} = sprintf('Warning: Reducing circuit: Split bus: Could not find 2nd line to shift across: %s - %s.',...
            busName{ii},busNameTo{ii}{2});
        if DispFlag, fprintf('%s\n',r.EventLog{end}); end;
        return
    end
         
    % Get wire-node relationship for From and To ends (in
    % this order --> used below)
    for kk = 1:2 % elements (shifted across)
        for jj = 1:2 % buses
            Bus = DSSObj.ActiveCircuit.CktElements(Element{kk}).Bus{ElemBusFromTo(kk,jj)};
            idx = strfind(Bus,'.');
            if isempty(idx)
                % default wire-phase connections
                WirePhase{kk,jj} = 1:DSSObj.ActiveCircuit.CktElements(Element{kk}).NumPhases;
            else
                % use existing wire-phase info
                WirePhase{kk,jj} = str2num(strrep(Bus(idx(1):end),'.',' '));
            end
        end
    end
    
    % line-impedance information
    for jj = 1:2
        zm{jj} = (INFO_LINE.rmatrix{ElemIdx(jj)} + 1i*INFO_LINE.xmatrix{ElemIdx(jj)}) * INFO_LINE.llen(ElemIdx(jj));
        z1{jj} = (INFO_LINE.r1{ElemIdx(jj)} + 1i*INFO_LINE.x1{ElemIdx(jj)}) * INFO_LINE.llen(ElemIdx(jj));
    end
    % 'ims': impedance matrix (1st phase) converted to real scalar

    % 'pos. sequence': complex ratios
    LR1{1} = z1{2} / (z1{1} + z1{2});
    LR1{2} = z1{1} / (z1{1} + z1{2});
    % select scaling factor setup
    switch Scaling
        case ch.Scaling.posseq % positive sequence
            LR{1} = LR1{1};
            LR{2} = LR1{2};
%         case ch.Scaling.ims % impedance matrix scalar

    end
    
    % move loads
    idx = strfind(INFO_LOAD.Bus,busName{ii});
    CompIdx = [];
    for jj = 1:length(idx)
        if ~isempty(idx{jj})
            CompIdx = [CompIdx jj];
        end
    end
    for jj = 1:length(CompIdx)
        idx = strfind(INFO_LOAD.Bus{CompIdx(jj)},'.');
        if isempty(idx)
            % default wire-phase connections
            CompWirePhase = 1:INFO_LOAD.NumPhases(CompIdx(jj));
        else
            % use existing wire-phase info
            CompWirePhase = str2num(strrep(INFO_LOAD.Bus{CompIdx(jj)}(idx(1):end),'.',' '));
        end
        for ll = 1:2 % lines shifted across
            % determine node connections
            node = [];
            if length(CompWirePhase) <= length(WirePhase{ll,1})
                for kk = 1:length(CompWirePhase)
                    idx = find(CompWirePhase(kk) == WirePhase{ll,1});
                    node(kk) = WirePhase{ll,2}(idx);
                end
            else
                for kk = 1:length(WirePhase{ll,1})
                    idx = find(CompWirePhase == WirePhase{ll,1}(kk));
                    node(kk) = WirePhase{ll,2}(idx);
                end
                % appending remaining connections
                node = [node CompWirePhase(length(WirePhase{ll,1})+1:end)];
            end
            NewLoadBus = [busNameTo{ii}{ll} sprintf('.%.0f',node)];
          
            if ll == 1
                % edit settings for Part #1: scale power levels
                Ps = INFO_LOAD.kW(CompIdx(jj));
                Qs = INFO_LOAD.kVAR(CompIdx(jj));
                Rs = INFO_LOAD.Ratio(CompIdx(jj));
                XFkVAs = INFO_LOAD.XFkVA(CompIdx(jj)); %*LRs{1}
                P = real((Ps + 1i*Qs) * LR{1});
                Q = imag((Ps + 1i*Qs) * LR{1});
                XFkVA = XFkVAs * abs(LR{1});
                str1 = sprintf('edit Load.%s bus1=%s XFkVA=%f kw=%f kvar=%f',...
                    INFO_LOAD.Name{CompIdx(jj)},NewLoadBus,XFkVA,P,Q);
                DSSObj.Text.Command = str1;
                r.Actions{end+1} = str1;
                r.ActComment{end+1} = sprintf('Split bus: Moved Load.%s: part 1 (Vnom=%.3fkV), from bus=%s to bus=%s, factor=%s, XFkVA=%f kw=%f kvar=%f',...
                    INFO_LOAD.Name{CompIdx(jj)},BuskV,busName{ii},NewLoadBus,num2str(LR{1}),XFkVA,P,Q);
                r.ActUnDo{end+1} = sprintf('edit Load.%s bus1=%s XFkVA=%f kw=%f kvar=%f',...
                    INFO_LOAD.Name{CompIdx(jj)},busName{ii},XFkVAs,Ps,Qs);
                % global data
                INFO_LOAD.Bus{CompIdx(jj)} = NewLoadBus;
                INFO_LOAD.kW(CompIdx(jj)) = P;
                INFO_LOAD.kVAR(CompIdx(jj)) = Q;
                INFO_LOAD.pf(CompIdx(jj)) = 0;
                INFO_LOAD.kVA(CompIdx(jj)) = 0;   
                INFO_LOAD.XFkVA(CompIdx(jj)) = 0;  
                INFO_LOAD.Ratio(CompIdx(jj)) = Rs * LR{1};  
            else
                % create Part #2: Need to trace connected components and
                % duplicate with reduced power levels
                y = sg_getObjectProperties(DSSObj,['load.' INFO_LOAD.Name{CompIdx(jj)}],'choice','basic');
                % Avoid cloning (by using like=) for now as it causes errornous circuits
                LName = sprintf('%s_p%.0f',INFO_LOAD.Name{CompIdx(jj)},ll);
                while sum(strcmpi(LoadNames,LName));
                    LName = [LName '_p2'];
                end
                LoadNames{end+1} = LName;
                str1 = sprintf('new Load.%s %s',LName,y.nvstr);
                DSSObj.Text.Command = str1;
                P = real((Ps + 1i*Qs) * LR{2});
                Q = imag((Ps + 1i*Qs) * LR{2});
                XFkVA = XFkVAs * abs(LR{2});
                str1 = sprintf('edit Load.%s bus1=%s XFkVA=%f kw=%f kvar=%f',...
                    LName,NewLoadBus,XFkVA,P,Q);
                DSSObj.Text.Command = str1;
                r.Actions{end+1} = str1;
                r.ActComment{end+1} = sprintf('Split bus: Added Load.%s: part 2 (Vnom=%.3fkV), bus=%s, factor=%s, XFkVA=%f kw=%f kvar=%f',...
                    LName,BuskV,NewLoadBus,num2str(LR{2}),XFkVA,P,Q);
                r.ActUnDo{end+1} = sprintf('diable Load.%s',LName);
                % global data
                INFO_LOAD.Name{end+1} = LName;
                INFO_LOAD.Bus{end+1} = NewLoadBus;
                INFO_LOAD.kW(end+1) = P;
                INFO_LOAD.kVAR(end+1) = Q;
                INFO_LOAD.pf(end+1) = 0;
                INFO_LOAD.kVA(end+1) = 0;  
                INFO_LOAD.XFkVA(end+1) = 0;
                INFO_LOAD.NumPhases(end+1) = y.phases;
                INFO_LOAD.enab(end+1) = 1;
                INFO_LOAD.kV(end+1) = y.kV;
                INFO_LOAD.conn{end+1} = y.conn;
                INFO_LOAD.Ratio(end+1) = Rs * LR{2};
                % INFO_LOAD.iName{end+1} = INFO_LOAD.iName{CompIdx(jj)};
                INFO_LOAD.iNameIdx(end+1) = INFO_LOAD.iNameIdx(CompIdx(jj));
            end
        end
    end
    
     % move transformers
    idx = strfind(INFO_TR.Bus1,busName{ii}); % assuming primary side gets reconnected
    CompIdx = [];
    for jj = 1:length(idx)
        if ~isempty(idx{jj})
            CompIdx = [CompIdx jj];
        end
    end
    for jj = 1:length(CompIdx)
        idx = strfind(INFO_TR.Bus1{CompIdx(jj)},'.');
        if isempty(idx)
            % determine wire-phase connections
            CompWirePhase = [1:INFO_TR.NumPhases(CompIdx(jj)) 0];
        else
            % use existing wire-phase info
            CompWirePhase = str2num(strrep(INFO_TR.Bus1{CompIdx(jj)}(idx(1):end),'.',' '));
        end 
        for ll = 1:2 % lines shifted across
            node = [];
            if length(CompWirePhase) <= length(WirePhase{ll,1})
                for kk = 1:length(CompWirePhase)
                    idx = find(CompWirePhase(kk) == WirePhase{ll,1});
                    node(kk) = WirePhase{ll,2}(idx);
                end
            else
                for kk = 1:length(WirePhase{ll,1})
                    idx = find(CompWirePhase == WirePhase{ll,1}(kk));
                    node(kk) = WirePhase{ll,2}(idx);
                end
                % appending remaining connections
                node = [node CompWirePhase(length(WirePhase{ll,1})+1:end)];
            end
            NewTrBus = [busNameTo{ii}{ll} sprintf('.%.0f',node)];
            SecondaryBus = INFO_TR.Bus2{CompIdx(jj)};
            if str2num(DSSObj.ActiveCircuit.CktElements(['transformer.' INFO_TR.Name{CompIdx(jj)}]).Properties('windings').val) > 2
                WdgBuses0 = DSSObj.ActiveCircuit.CktElements(['transformer.' INFO_TR.Name{CompIdx(jj)}]).BusNames;
                WdgBuses = WdgBuses0(3:end);
            else
                WdgBuses = [];
            end
            if ll == 2
                % secondary: new bus name
                idx = strfind(SecondaryBus,'.');
                if ~isempty(idx)
                    NodeInfo = SecondaryBus(idx(1):end);
                    SecondaryBus = [SecondaryBus(1:idx(1)-1) '_p2'];
                else
                    SecondaryBus = [SecondaryBus '_p2'];
                end
                while sum(strcmpi(DSSObj.ActiveCircuit.AllBusNames,SecondaryBus));
                    SecondaryBus = [SecondaryBus '_p2'];
                end
                if ~isempty(idx)
                    SecondaryBus = [SecondaryBus NodeInfo];
                end
                % other windings: new bus names: this code works (i.e.,
                % consistently renames buses as the OpenDSS structure is
                % not updated yet and all get '_p2' appended. Even if
                % windings are at the same bus, they end up with the same
                % new name
                for kk = 1:length(WdgBuses)
                    idx = strfind(WdgBuses{kk},'.');
                    if ~isempty(idx)
                        NodeInfo = WdgBuses{kk}(idx(1):end);
                        WdgBuses{kk} = [WdgBuses{kk}(1:idx(1)-1) '_p2'];
                    else
                        WdgBuses{kk} = [WdgBuses{kk} '_p2'];
                    end
                    while sum(strcmpi(DSSObj.ActiveCircuit.AllBusNames,WdgBuses{kk}));
                        WdgBuses{kk} = [WdgBuses{kk} '_p2'];
                    end
                    if ~isempty(idx)
                        WdgBuses{kk} = [WdgBuses{kk} NodeInfo];
                    end
                end
            end
          
            if ll == 1
                % edit settings for Part #1: reduce power levels

                % Note: scaling all windings at the same time as wdg=1 kva=
                % will otherwise cause all other windings to be set as well
                str1 = sprintf('? Transformer.%s.kvas',INFO_TR.Name{CompIdx(jj)});
                DSSObj.Text.Command = str1;
                kVAs = str2num(DSSObj.Text.Result);
                
                str1 = sprintf('edit Transformer.%s wdg=1 bus=%s',...
                    INFO_TR.Name{CompIdx(jj)},NewTrBus);
                DSSObj.Text.Command = str1;
                r.Actions{end+1} = str1;
                r.ActComment{end+1} = sprintf('Split bus: Moved Transformer.%s (part 1): bus1=%s',...
                    INFO_TR.Name{CompIdx(jj)},NewTrBus);
                str1 = sprintf('edit Transformer.%s wdg=1 bus=%s',...
                    INFO_TR.Name{CompIdx(jj)},INFO_TR.Bus1{CompIdx(jj)});
                r.ActUnDo{end+1} = str1;
                
                str1 = sprintf('edit Transformer.%s kVAs=(%s)',INFO_TR.Name{CompIdx(jj)},num2str(kVAs*abs(LR{1})));
                DSSObj.Text.Command = str1;
                r.Actions{end+1} = str1;                
                r.ActComment{end+1} = sprintf('Split bus: Scaled Transformer.%s (part 1): factor=%f, kvas=(%s)',...
                    INFO_TR.Name{CompIdx(jj)},abs(LR{1}),num2str(kVAs*abs(LR{1})));
                str1 = sprintf('edit Transformer.%s kvas=(%s)',INFO_TR.Name{CompIdx(jj)},num2str(kVAs));
                r.ActUnDo{end+1} = str1;
                % scale connected elements (loads)
                sg_ScaleSection(SecondaryBus);
                
                % global data
                INFO_TR.Bus1{CompIdx(jj)} = NewTrBus;
                INFO_TR.kVA(CompIdx(jj)) = kVAs*abs(LR{1});
                
            else
                % create Part #2: Need to trace connected components and
                % duplicate with reduced power levels
                y = sg_getObjectProperties(DSSObj,['transformer.' INFO_TR.Name{CompIdx(jj)}],'choice','basic');
                % Avoid cloning (by using like=) for now as it causes
                % errornous circuits

                TrName = sprintf('%s_p%.0f',INFO_TR.Name{CompIdx(jj)},ll);
                while sum(strcmpi(DSSObj.ActiveCircuit.Transformers.AllNames,TrName))
                    TrName = [TrName '_p2'];
                end
                str1 = sprintf('new Transformer.%s %s',TrName,y.nvstr);
                DSSObj.Text.Command = str1;
                r.Actions{end+1} = str1;
                r.ActComment{end+1} = sprintf('Split bus: new transformer (part 2): Transformer.%s',...
                    TrName);
                r.ActUnDo{end+1} =  sprintf('disable Transformer.%s',TrName);
                
                str1 = sprintf('edit Transformer.%s wdg=1 bus=%s wdg=2 bus=%s',TrName,NewTrBus,SecondaryBus);
                DSSObj.Text.Command = str1;
                r.Actions{end+1} = str1;
                r.ActComment{end+1} = sprintf('Split bus: Moved (part 2) Transformer.%s: bus1=%s bus2=%s',...
                    INFO_TR.Name{CompIdx(jj)},ll,NewTrBus,SecondaryBus);
                r.ActUnDo{end+1} = ''; % new real UnDo as this is a new transformer
                
                str1 = sprintf('edit Transformer.%s kvas=(%s)',TrName,num2str(kVAs*abs(LR{2})));
                DSSObj.Text.Command = str1;
                r.Actions{end+1} = str1;
                r.ActComment{end+1} = sprintf('Split bus: Scaled (part 2) Transformer.%s: factor=%f, kvas=(%s)',...
                    TrName,abs(LR{2}),num2str(kVAs*abs(LR{2})));
                str1 = sprintf('edit Transformer.%s kvas=(%s)',TrName, num2str(kVAs));
                r.ActUnDo{end+1} = str1;
                
                % global data
                INFO_TR.Name{end+1} = TrName;
                INFO_TR.Bus1{end+1} = NewTrBus;
                INFO_TR.Bus2{end+1} = SecondaryBus;
                INFO_TR.kVA(CompIdx(jj)) = kVAs(1)*abs(LR{1});
                
                % rename remaining windings' busnames
                for kk = 3:INFO_TR.wdgs(CompIdx(jj))
                     str1 = sprintf('edit Transformer.%s wdg=%.0f bus=%s',...
                         TrName,kk,WdgBuses{kk-2});
                     DSSObj.Text.Command = str1;
                     r.Actions{end+1} = str1;
                     r.ActComment{end+1} = sprintf('Split bus: renamed bus (part 2) Transformer.%s wdg=%.0f bus=%s',...
                         TrName,kk,WdgBuses{kk-2});
                     r.ActUnDo{end+1} = sprintf('edit Transformer.%s wdg=%.0f bus=%s',...
                         TrName,kk,WdgBuses0{kk});
                end
                % 'clone' section downstream of transformer secondary
                sg_DuplicateSection(INFO_TR.Bus2{CompIdx(jj)},SecondaryBus);
            end
        end
    end 
end
r.status = 1;

    function sg_ScaleSection(Bus)
        % Scale 1st part of a feeder section (load) that was moved from another bus.
        % function sg_ScaleSection(BusName)
        %
        % Nested for efficiency.
        % For now: assume only loads are connected
        
        sidx = strfind(Bus,'.');
        if ~isempty(sidx)
            Bus = Bus(1:sidx(1)-1);
        end
        eidx = sg_rgrep(['^' Bus],INFO_LOAD.Bus);      % current location
        
        for mm = 1:length(eidx)
            Ps = INFO_LOAD.kW(eidx(mm));
            Qs = INFO_LOAD.kVAR(eidx(mm));
            XFkVAs = INFO_LOAD.XFkVA(eidx(mm));
            if isreal(LR{1})
                P = Ps * LR{1};
                Q = Qs * LR{1};
                XFkVA = XFkVAs * LR{1};
            else
                P = real((Ps + 1i*Qs) * LR{1});
                Q = imag((Ps + 1i*Qs) * LR{1});
                XFkVA = XFkVAs * abs(LR{1});
            end
            str1 = sprintf('edit Load.%s xfkva=%f kw=%f kvar=%f',INFO_LOAD.Name{eidx(mm)},XFkVA,P,Q);
            DSSObj.Text.Command = str1;
            r.Actions{end+1} = str1;
            r.ActComment{end+1} = sprintf('Split bus: Moved/Scaled Part 1: Load.%s: bus=%s, scale=%s, xfkva=%f kw=%f kvar=%f',...
                INFO_LOAD.Name{eidx(mm)},INFO_LOAD.Bus{eidx(mm)},num2str(LR{1}),XFkVA,P,Q);
            str1 = sprintf('edit Load.%s xfkva=%f kw=%f kvar=%f',INFO_LOAD.Name{eidx(mm)},XFkVAs,Ps,Qs);
            r.ActUnDo{end+1} = str1;
            % update global data
            INFO_LOAD.kW(eidx(mm))   = P;
            INFO_LOAD.kVAR(eidx(mm)) = Q;
            INFO_LOAD.XFkVA(eidx(mm)) = XFkVA;
            INFO_LOAD.Ratio(eidx(mm)) = INFO_LOAD.Ratio(eidx(mm)) * LR{1};
        end
    end

    function sg_DuplicateSection(CurrentBus,NewBus)
        % Duplicate part of a feeder as part of moving loads from one bus to two neighboring buses.
        % function sg_DuplicateSection(CurrentBus,NewBus)
        %
        % Nested for efficiency. 
        % For now: assume only loads are connected
        
        sidx = strfind(CurrentBus,'.');
        if ~isempty(sidx)
            CurrentBus = CurrentBus(1:sidx(1)-1);
        end
        eidx = sg_rgrep(['^' CurrentBus],INFO_LOAD.Bus);      % current location
        
        for mm = 1:length(eidx)
            % Avoid using "like=" for now

            y = sg_getObjectProperties(DSSObj,['load.' INFO_LOAD.Name{eidx(mm)}],'choice','basic');
            str1 = sprintf('new Load.%s_p%.0f %s',INFO_LOAD.Name{eidx(mm)},ll,y.nvstr);
            DSSObj.Text.Command = str1;
            r.Actions{end+1} = str1;
            r.ActComment{end+1} = sprintf('Split bus: 2nd Part: New Load.%s_p%.0f',INFO_LOAD.Name{eidx(mm)},ll);
            r.ActUnDo{end+1} = sprintf('disable Load.%s_p%.0f',INFO_LOAD.Name{eidx(mm)},ll);
            Ps = INFO_LOAD.kW(eidx(mm));
            Qs = INFO_LOAD.kVAR(eidx(mm));
            XFkVAs = INFO_LOAD.XFkVA(eidx(mm));
            if isreal(LR{2})
                P = Ps * LR{2};
                Q = Qs * LR{2};
                XFkVA = XFkVAs * LR{2};
            else
                P = real((Ps + 1i*Qs) * LR{2});
                Q = imag((Ps + 1i*Qs) * LR{2});
                XFkVA = XFkVAs * abs(LR{2});
            end
            str1 = sprintf('edit Load.%s_p%.0f bus1=%s xfkva=%f kw=%f kvar=%f',...
                INFO_LOAD.Name{eidx(mm)},ll,NewBus,XFkVA,P,Q);
            DSSObj.Text.Command = str1;
            r.Actions{end+1} = str1;
            r.ActComment{end+1} = sprintf('Split bus: Scaled 2nd part: Load.%s_p%.0f: bus=%s, scale=%s, xfkva=%f kw=%f kvar=%f',...
                INFO_LOAD.Name{eidx(mm)},ll,NewBus,num2str(LR{2}),XFkVA,P,Q);
            r.ActUnDo{end+1} = sprintf('disable Load.%s_p%.0f',INFO_LOAD.Name{eidx(mm)},ll);
            % update global data
            INFO_LOAD.Name{end+1}   = sprintf('%s_p%.0f',INFO_LOAD.Name{eidx(mm)},ll);
            INFO_LOAD.Bus{end+1}   = NewBus;
            INFO_LOAD.kW(end+1)   = P;
            INFO_LOAD.kVAR(end+1) = Q;
            INFO_LOAD.XFkVA(end+1) = XFkVA;
            INFO_LOAD.Ratio(end+1) = INFO_LOAD.Ratio(eidx(mm)) * LR{2};
            INFO_LOAD.iNameIdx(end+1) = INFO_LOAD.iNameIdx(eidx(mm));
        end
    end
end