function y=sg_openDssGetLoadInfo(varargin)
%  Get Load Information
%  function y=sg_openDssGetLoadInfo(DSSObj)
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%  Options;
%    Loads - Either a cell array of strings or a single string.  If a cell
%      array, this is interpreted as a list of Load names for which to get
%      information.  If a string, this is interpreted as a regular
%      expression pattern used to match Load names.  The default value is the
%      regular expression '.*', indicating that information for all
%      Loads should be returned. 
%  Returns y
%    y - a structure of information.
%
% Examples: 
%   y=sg_openDssGetLoadInfo(DSSObj);
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% August 31, 2014

DSSObj = varargin{1};

opts = struct('Loads','.*');
opts = sg_updateOpts(opts,varargin,1);

y = struct();

if (iscell(opts.Loads) == 0)
    lv = DSSObj.ActiveCircuit.Loads.AllNames;
    i1 = sg_rgrep(opts.Loads,lv);
    opts.Loads = lv(i1);
end

N = length(opts.Loads);

y.N = N;                     % number of initial loads (before possibly splitting)
y.Name = opts.Loads;
y.Bus = repmat({'Bus'},1,N);
y.NumPhases = zeros(1,N);
y.kW = zeros(1,N);
y.pf = zeros(1,N);
y.kVAR = zeros(1,N);
y.kVA = zeros(1,N);
y.conn = cell(1,N);
y.enab = zeros(1,N);
y.kV = zeros(1,N);
y.Ratio = ones(1,N);  % ratio of (profile) load connected under this name
y.iNameIdx = 1:N;     % index of initial load (name) (i.e., the load in the original profile data)

for n = 1:length(opts.Loads)
    x = DSSObj.ActiveCircuit.CktElements(['Load.' y.Name{n}]);
    y.Bus{n} = x.BusNames{1};
    y.NumPhases(n) = x.NumPhases;
    y.kW(n) = str2num(x.Properties('kW').Val);
    y.pf(n) = str2num(x.Properties('pf').Val);
    y.kVAR(n) = str2num(x.Properties('kVAR').Val);
    y.kVA(n) = str2num(x.Properties('kVA').Val);
    y.conn{n} = x.Properties('conn').Val;
    y.XFkVA(n) = str2num(x.Properties('XFkVA').Val);
    y.enab(n) = x.Enabled;
    y.kV(n) = str2num(x.Properties('kV').Val);
end