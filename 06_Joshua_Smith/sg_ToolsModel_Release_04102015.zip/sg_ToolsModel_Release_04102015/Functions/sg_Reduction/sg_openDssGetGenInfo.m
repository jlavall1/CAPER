function y = sg_openDssGetGenInfo(varargin)
%  Get Generator Information
%  function y = sg_openDssGetGenInfo(DSSObj)
%
%  Parameters:
%    DSSObj - OpenDSS COM interface connection
%  Options;
%    Generators - Either a cell array of strings or a single string.  If a cell
%      array, this is interpreted as a list of Generator names for which to get
%      information.  If a string, this is interpreted as a regular
%      expression pattern used to match Load names.  The default value is the
%      regular expression '.*', indicating that information for all
%      Loads should be returned. 
%  Returns y
%    y - a structure of information.
%
% Examples: 
%   y = sg_openDssGetGenInfo(DSSObj);
%   
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% January 30, 2015

DSSObj = varargin{1};

opts = struct('Generators','.*');
opts = sg_updateOpts(opts,varargin,1);

y = struct();

if (iscell(opts.Generators) == 0)
    lv = DSSObj.ActiveCircuit.Generators.AllNames;
    if ~strcmpi(lv{1},'none')
        i1 = sg_rgrep(opts.Generators,lv);
        opts.Generators = lv(i1);
    else
        opts.Generators = [];
    end
end

N = length(opts.Generators);
y.Name = opts.Generators;
y.Bus = repmat({'Bus'},1,N);
y.NumPhases = zeros(1,N);

y.kW = zeros(1,N);
y.pf = zeros(1,N);
y.kVAR = zeros(1,N);
y.kVA = zeros(1,N);
y.conn = cell(1,N);
y.enab = zeros(1,N);
y.kV = zeros(1,N);

for (n = 1:length(opts.Generators))
    name = y.Name{n};
    x = DSSObj.ActiveCircuit.CktElements(['Generators.' y.Name{n}]);
    y.Bus{n} = x.BusNames{1};
    y.NumPhases(n) = x.NumPhases;

    y.kW(n) = str2num(x.Properties('kW').Val);

    y.pf(n) = str2num(x.Properties('pf').Val);

    y.kVAR(n) = str2num(x.Properties('kVAR').Val);

    y.kVA(n) = str2num(x.Properties('kVA').Val);
    y.conn{n} = x.Properties('conn').Val;
    y.enab(n) = x.Enabled;
    y.kV(n) = str2num(x.Properties('kV').Val);
end