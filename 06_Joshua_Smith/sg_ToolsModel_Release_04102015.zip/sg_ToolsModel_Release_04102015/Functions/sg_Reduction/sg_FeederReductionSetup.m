function [results,DSSObj] = sg_FeederReduction(varargin)
% OpenDSS setup (helper function) for feeder reduction algorithm.
% function [results,DSSObj] = sg_FeederReduction(model)% 
%
% Inputs:  model	... a string indicating the name of an OpenDSS model file.
%    	  'DSSObj' 	... OpenDSS COM interface connection (default = '' indicating that a new
%      					connection should be created.
%    	  'profile' ... a structure with profiles for component parameters over time.
%      					Alternatively, this can be a string, specifying the name of a file
%      					to read in for the profile.  (default = '', indicating that a single
%      					snapshot is to be taken.
%   'profilePoints'	... an integer indicating the number of points in the
%      					profile to run (default = -1, indicating run all points).
%    	'resultExt'	... a handle to a function of the form
%       				ynew = f(DSSObj,y,N), where y is a data structure (updated with new
%       				data after each run), and DSSObj is the OpenDSS COM interface
%       				connection.  This function will be called after each run, so that
%       				the function can update the structure y, with new data, and return
%       				this.  The function should expect y to be a scalar value of zero
%       				after the initial run.  N is the total number of runs.  
%       				(Default is '', indicating that a standard data structure 
%						should be returned).
%    	'initParams'... a cell array specifying the names of parameters to be
%      					set prior to the first snapshot (default is is an empty cell
%      					array, indicating that no parameters need to be set).
%    	'initVals'	... a cell array specifying the values to which the parameters
%      					specified in initParmams should be set (default is an empty cell
%      					array).
%    'initValsFmt' 	... a cell array specifying the format string to use for the
%      					values in initVals (e.g. %f).  By default, this is an empty cell
%      					array, in which case, '%.0f' is used for all values.  A single
%      					format string can also be supplied, in which case, this will be used
%      					for all values in initVals
%    	'controls'	... a cell array of control objects.
%    	'DispFlag'	... display events/messages (0/1), default: 1
%
% Outputs: results	... structure
%           .t = 0
%           .status ... 0/1 status information
%           .Events ... list of events 
%		   DSSObj	... handle to active OpenDSS model
%
% Example Call(s):
%
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%% Default setup and handling of options
model = varargin{1};
EventLog = {};   % keeps track of warning/error messages (cell array)
DispFlag = 1;    % turn on/off console display (0/1)
status   = 0;    % power flow solution status (0/1)
LoadScale = 1;   % scaling factor for loads in profile
GenScale  = 1;   % scaling factor for generators in profile

opts = struct('DSSObj','','profile','','resultExt','','profilePoints',-1,...
    'DispFlag',DispFlag,'LoadScale',LoadScale,'GenScale',GenScale);
opts.initParams={};
opts.initVals={};
opts.initValsFmt={};
opts.controls={};
opts = sg_updateOpts(opts,varargin,1);

results = [];
time = [];

if(ischar(opts.resultExt)==1)
    opts.resultExt = @sg_resultExtBase; 
end

if(ischar(opts.DSSObj)==1)
    % Instantiate the OpenDSS Object
    DSSObj = actxserver('OpenDSSEngine.DSS');
    % Start up the Solver
    if ~DSSObj.Start(0),
        EventLog{end+1} = 'Error: Unable to start the OpenDSS Engine';
        if opts.DispFlag
            disp('Unable to start the OpenDSS Engine')
        end
        results.status   = status;
        results.EventLog = EventLog;
        return
    else
        EventLog{end+1} = 'Started OpenDSS Engine';
    end
else
    DSSObj = opts.DSSObj;
end

%% Handles to OpenDSS 
DSSText     = DSSObj.Text;
DSSCircuit  = DSSObj.ActiveCircuit;
DSSSolution = DSSCircuit.Solution;
DSSloads    = DSSCircuit.Loads;


%% Compile the model (and check for errors in circuit/OpenDSS setup).

%  If an empty string is passed for the model, assume that a model has
%  already been loaded and compiled in the DSSObj.
if(strcmp(model,'')==0)
    fsc = filesep;
    if isempty(strfind(model,fsc))
        % check for fully qualified file name based on file separation character
        model = [pwd fsc model];
    end
    str1 = sprintf('Compile (%s)',model);
    DSSText.command = str1;
    if ~isempty(DSSText.Result)
        txt = DSSText.Result;
        EventLog{end+1} = sprintf('Error: OpenDSS: %s',txt);
        if opts.DispFlag
            fprintf(' OpenDSS: %s\n',DSSText.Result);
        end
        results.status   = status;
        results.EventLog = EventLog;
        return
    end
end

% 'Compile' silently keeps processing data files: Need to use a command to
% check for errors in setup
DSSText.command = 'Calcv';
if ~isempty(DSSText.Result)
    EventLog{end+1} = sprintf(['Error: OpenDSS: %s\n',DSSText.Result]);
    if opts.DispFlag
        fprintf(' OpenDSS: %s\n',DSSText.Result);
    end
    results.status   = status;
    results.EventLog = EventLog;
    return
end

%%  Initialize any specified parameters.

if(length(opts.initParams)>0)
    Ni=length(opts.initParams);
    if(length(opts.initValsFmt)==1)
        opts.initValsFmt=repmat(opts.initValsFmt,1,Ni);
    elseif(length(opts.initValsFmt)==0)
        opts.initValsFmt=repmat({'%.0f'},1,Ni);
    end
    for(n2=1:length(opts.initParams))
       str1=sprintf(['edit %s=' opts.initValsFmt{n2}],opts.initParams{n2},opts.initVals{n2});
       % fprintf(1,'%s\n',str1);
       DSSText.Command=str1;
    end
end

%% initial Power flow: compute a (valid) solution before reduction
%  Solve the model.
DSSText.command = 'Calcv';
if ~isempty(DSSText.Result)
    EventLog{end+1} = sprintf('Error: OpenDSS: %s\n',DSSText.Result);
    if opts.DispFlag
        fprintf(' OpenDSS: %s\n',DSSText.Result);
    end
    results.status   = status;
    results.EventLog = EventLog;
    return
end
DSSSolution.Solve;
% results = opts.resultExt(DSSObj,results,1);
try
    results = opts.resultExt(DSSObj,results,1);
    status = 1;
catch
    % data extraction failed: providing error message
    le = lasterror;
    EventLog{end+1} = sprintf('Error: Extracting result data:\n  %s\nFile: %s, Line: %.0f\n',le.message,le.stack(1).name,le.stack(1).line);
    if opts.DispFlag
        fprintf('\nError extracting result data:\n %s\nStack:\n',le.message);
        for ii=1:length(le.stack)
            fprintf(' File: %s, Line: %.0f\n',le.stack(ii).name,le.stack(ii).line);
        end
    end
end

results.t        = 0;
results.status   = status;
results.EventLog = EventLog;