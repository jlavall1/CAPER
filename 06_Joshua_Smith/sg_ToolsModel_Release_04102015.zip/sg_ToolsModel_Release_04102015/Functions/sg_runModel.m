function r = sg_runModel(varargin)
% Computes power flows
% function r = sg_runModel(varargin)
%
% Computes power flows for a given model and corresponding load and generation (PV) profile.
%
% Inputs:  'model','m'     ... OpenDSS Feeder Model filename (*.dss)
%          'profile','p'   ... Excel spreadsheet (*.xlsx) with profile data
%          'rExt','re'     ... cell array, (optional) results extraction configuration,
%                              default: all base data is returned (ExtBase)
%          'fnResults','f' ... filename for results data (*.mat), default:
%                              'Results.mat' , use empty ('') in case no data to be saved
%          'dp'            ... number of profile data points to be used
%          'DispFlag'      ... display flag (0/1), default: 0
%
% Outputs: r.   ... data (results) structure
%
% Examples(s):
%		r = 
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%% Case setup and option handling
% Data/result files
y.Feeder.model     = '';
y.Feeder.profile   = '';
y.Feeder.resultExt = @(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N); % keep data for post-processing
y.Feeder.fnResults = 'Results';
dp                 = 0;
DispFlag           = 0;
EventLog           = {};
r                  = [];
LoadScale          = 1;
GenScale           = 1;

for ii = 1:2:length(varargin)
    switch lower(varargin{ii})
        case {'model','m'}
            y.Feeder.model = varargin{ii+1};
        case {'profile','p'}
            y.Feeder.profile = varargin{ii+1};
        case {'rext','re'}
            extString = '';
            for jj = 1:length(varargin{ii+1})
                extString = [extString ',''' varargin{ii+1}{jj} ''''];
            end
            y.Feeder.resultExt = eval(['@(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N' extString ')']);
        case {'fnresults','f'}
            y.Feeder.fnResults = varargin{ii+1};
        case {'dp'}
            dp = varargin{ii+1};
        case {'dispflag'}
            DispFlag = varargin{ii+1};
        case {'loadscale'}
            LoadScale = varargin{ii+1};
        case {'genscale'}
            GenScale = varargin{ii+1};
        otherwise
            if DispFlag
                fprintf(' Unknown option: %s\n',varargin{ii});
            end
    end
end

%% Use GUI in case no data file is specified
fsc = filesep;
if isempty(y.Feeder.model)
    % select data file using GUI
    [filename,pathname] = uigetfile('*.dss','Select OpenDSS case file ...');
    if pathname == 0
        if DispFlag
            fprintf('\n You must select a valid OpenDSS (*.dss) file! Terminating.\n');
        end
        EventLog{end+1} = 'Error: No valid OpenDSS file selected.';
        r.EventLog = EventLog;
        return
    end
    y.Feeder.model = [pathname filename];
end
if isempty(y.Feeder.profile)
    % select data file using GUI
    [filename,pathname] = uigetfile({'*.xlsx','*.xls'},'Select Profile data file ...');
    if pathname == 0
        % keep running: simple compute a power flow with feeder data
        pathname = '';
        filename = '';
    end
    y.Feeder.profile = [pathname filename];
end
%% 
[pathstr,fname,fext] = fileparts(y.Feeder.model);


%% Open and configure OpenDSS connection
try
    [DSSObj,EventLog] = sg_startOpenDSS('DispFlag',DispFlag);
catch
    % in case helper functions are not on the path yet
    startup;
    [DSSObj,EventLog] = sg_startOpenDSS('DispFlag',DispFlag);
end
for ii = 1:length(EventLog)
    if strfind(EventLog{ii},'Error:')
        r.EventLog = EventLog;
        return
    end
end

%% Execute model
tic;
if isempty(dp)
    [r,DSSObj,time] = sg_runOpenDSSSim(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,...
        'resultExt',y.Feeder.resultExt,'DispFlag',DispFlag,'loadscale',LoadScale,'genscale',GenScale);
else
    [r,DSSObj,time] = sg_runOpenDSSSim(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,...
        'resultExt',y.Feeder.resultExt,'profilePoints',dp,'DispFlag',DispFlag,'loadscale',LoadScale,'genscale',GenScale);
end
if ~isempty(EventLog)
    r.EventLog = [EventLog r.EventLog];
end
r.Tel = toc;
r.t   = time;
r.Feeder = y.Feeder;
r.CaseSetting.Scaling = [LoadScale GenScale];

%% Save results
if r.status
    if ~isempty(y.Feeder.fnResults)
        if ~isempty(dir([pathstr fsc r.Feeder.fnResults '.mat']))
            r.Feeder.fnResults = [r.Feeder.fnResults '_' datestr(now,'yyyymmddTHHMMSS')];
        end
        save([pathstr fsc r.Feeder.fnResults],'r');
        %     EventLog = sprintf('Saved results: %s.mat',[pathstr fsc r.Feeder.fnResults]);
        EventLog = sprintf('Saved results: %s.mat',[r.Feeder.fnResults]);
        r.EventLog = [r.EventLog EventLog];
    end
end
