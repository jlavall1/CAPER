function r=sg_evalSim(varargin)

%  Evaluate Simulation
%  r=sg_evalSim(x)
%  Parameters:
%    x - a structure with parameter names and values at which to execute 
%      the simulation 
%      PVProfile - a string specifying the name of a file containing the PV
%        profile to be used (default='', indicating that a default profile
%        should be used)
%      LoadProfile - a string specifying the name of a file containing the load
%        profile to be used (default='', indicating that a default profile
%        should be used)
%      Zsrc - the source impedance (pu) (default = 0.1)
%      LUF - load utilization factor (default = -1, indicating that the
%        default for the system should be used).
%      LoadPF - load power factor (default=0.8)
%      PVres - specifies the amount of residential PV power as a fraction
%        of the base MVA of the load transformers (default=0.1).
%      BulkPVPos - a value between 0 and 1 specifying the location of the
%        bulk PV (if any) along the feeder.  Here, a value of 0 indicates a
%        position close to the substation, and a value of 1 indicates
%        positioning at the bus that is the longest distance from the
%        substation (default = 0.5).
%      ResPVPos - a value between 0 and 1 specifying the location at which
%        to begin placing the residential PV along the feeder.  Here, a value of 0 indicates a
%        position close to the substation, and a value of 1 indicates
%        positioning at the bus that is the longest distance from the
%        substation (default = 0.5).
%      PVresDist - a string indicating the positioning of the residential
%        PV along the feeder {'beginning', 'end'} (default='end').
%      PVctl - A string indicating a type of mitigation method
%        to use.  Options include:
%          'none'  - No reactive power control to be employed (default).
%          'VoltPF' - Volt-PF characteristic to be employed by PVs.
%          'VoltVar' - Volt-VAR characteristic to be employed by PVs.
%          'PPF' - Power-PF characteristic (German LV curve).
%      PVctlXDBwidth - specifies the width of the x-axis deadband for the PV
%        control characteristic (default = 0.001 pu)
%      PVctlXwidth - specifies the total x-axis width (pu) for the
%        PV control characteristic (default=0.1 pu)
%      PVctlXcenter - specifies the x-axis center of the PV control
%        characteristic (default=1.0)
%      PVctlYwidth - specifies the total y-axis width of the PV control
%        characteristic (a value of -1 specifies that default mode appropriate 
%        values should be use, 0.2 for PVctl='VoltPF', 1 for PVctl='VoltVar')
%      PVctlmXcenter - a parameter to specify a linear decrease to the x-axis
%        center of the characteristic as a function of the normalized
%        distance from the substation of the node tp which the PV inverter
%        is connected (default = 0)
%      PVctlORF - a power overrating factor for the PV inverters (default=1e3, so
%        that reactive power is essentially not limited).
%      CapDisable - an integer (bitmap) specifying whether cap controls should be
%        enabled (0) or disabled (default=0).
%      
%  Options:
%    profilePoints - passed to sg_runOpenDSSSim()
%    DSSObj - a connection to an openDSS model (default='')
%    target - a string indicating the name of a directory in which to write
%      the model files (default = '', indicating that the model files
%      should not be written).
%    capControls - a string indicating the name of a file including
%      capacitor controls (specified using classes implemented in MATLAB).
%    configConstants - a structure of constants used for configuration.
%       model  -  Name of OpenDSS model file
%       SSXfmrSb - Base apparent power of the substation transformer (kVA).
%       SSBasekv - Base voltage at the substation.
%       SSXfmrXtoR - X/R ratio of the substation transformer.
%       ScapacityFeeder=9e3;  %  Maximum capacity of the feeder (kVA).
%       SmaxFeeder=6e3;  %  Maximum loading on the feeder (kVA).
%       VbMain=7.2;  %  Lowest voltage level (kV) of the main trunk. 
%       VbRes=1;  %  Maximum voltage level (kV) of residential loads.
%       dirProfiles='Profiles';
%
%  Returns r, a structure of results from the simulation.

opts=struct();
opts.DSSObj='';
opts.profilePoints=-1;
opts.target='';
opts.Niterations=1;
opts.dVmax=-1;
opts.capControls='';
opts.configConstants=0;

opts=sg_updateOpts(opts,varargin,1);

x=varargin{1};

xx=struct();  %  Structure with default values.
xx.PVpen=0.38; %  PV penetration level.
xx.LoadProfile='Load_weekday_1';
xx.PVProfile='PV_sunny_1';
xx.Zsrc=0.1;  %  Source impedance.
xx.LUF=-1;  %  Load utilization factor.  Default is -1, meaning calculate from system data.
xx.LoadPF=.8;  %  Load power factor.
xx.PVres=0.001;
xx.BulkPVPos=0.5;
xx.ResPVPos=-1;
xx.MitigationMethod='none';  %  Obsolete, but can still be used to set PVctl.
xx.PVctl='none';
xx.PVctlXDBwidth=.001;
xx.PVctlXwidth=0.1;
xx.PVctlXcenter=1;
xx.PVctlYwidth=-1;
xx.PVctlmXcenter=0;
xx.PVctlRes=1;
xx.PVctlORF=1e3;
xx.CapDisable=0;
xx.BulkPVP=-1;

nv=fieldnames(x);
for(n=1:length(nv))
    try
        nm=nv{n};
        xx.(nm)=x.(nm);
    end
end

%  Select the first cell of any configuration parameters that are cell
%  arrays.

fnvt=fieldnames(xx);
for(n=1:length(fnvt))
    if(iscell(xx.(fnvt{n}))) xx.(fnvt{n})=xx.(fnvt{n}){1}; end
end


if(strcmp(xx.MitigationMethod,'none')==0)
    xx.PVctl=xx.MitigationMethod; 
end

% xx.ResPVPos=-1;
% xx.PVProfileType='cloudy';

if(isstruct(opts.configConstants)==1)
    k=opts.configConstants;
elseif(ischar(opts.configConstants)==1)
    k=sg_loadStruct(opts.configConstants);
else
    k=struct();  %  Structure of constants for the case.
    k.model  = 'Feeder_3.dss';  %  Name of OpenDSS model file.
    k.SSXfmrSb=12e3;  %  Base apparent power of the substation transformer (kVA).   (was 18 MVA)
    k.SSBasekv=12.47;
    k.SSXfmrXtoR=5.737;
    k.ScapacityFeeder=9e3;  %  Maximum capacity of the feeder (kVA).
    k.SmaxFeeder=6e3;  %  Maximum loading on the feeder (kVA).
    k.VbMain=7.2;  %  Lowest voltage level (kV) of the main trunk. 
    k.VbRes=1;  %  Maximum voltage level (kV) of residential loads.
    k.dirProfiles='../Profiles';
end


% k.resultExt = @(DSSObj,y,N) sg_resultExtBase(DSSObj,y,N);  %  Function handle for results extraction.
k.resultExt = @(DSSObj,N) sg_resultExtBase_gv(DSSObj,N);  %  Function handle for results extraction.

%k.Ppvinst=2300;  % Installed PV in the real system (used for scaling PV profiles) (kW).
%k.Vsrc='Vsource.Feeder_3';
% k.NumPVs=8;  %  Number of PV units in the model.
% k.PVpen=0.25;  %  Nominal PV penetration for the model.
% k.MinSb=.001;  %  Minimum base apparent power.
% k.nvpv=1:8;  %  Numbers associated with PV units.

%  Controls
ctlv={};Nctl=0;

%  Add controls for capacitor banks.
if(~isempty(opts.capControls))
    ctlv=sg_loadControlsList(opts.capControls);
    Nctl=length(ctlv);
    %  Apply disable.
    for(n=1:Nctl)
        ctlv{n}.disable = bitget(xx.CapDisable,n);
    end
end

% %  Add controls for capacitor banks.
% Nctl=Nctl+1;ctlv{Nctl}=sg_CapCtl_pf_Q('Capacitor.B30020P','B30000P_B30010P','pfoff',-.99,'pfon',.99,'delay',240,'delayoff',60,'kvarmin',650,'state',0,'disable',bitget(xx.CapDisable,1));
% Nctl=Nctl+1;ctlv{Nctl}=sg_CapCtl_pf_Q('Capacitor.B30030P','B30000P_B30010P','pfoff',-.99,'pfon',.99,'delay',180,'delayoff',180,'kvarmin',650,'state',0,'disable',bitget(xx.CapDisable,2));
% Nctl=Nctl+1;ctlv{Nctl}=sg_CapCtl_pf_Q('Capacitor.B30040P','B30000P_B30010P','pfoff',-.99,'pfon',.99,'delay',120,'delayoff',120,'kvarmin',650,'state',0,'disable',bitget(xx.CapDisable,3));
% Nctl=Nctl+1;ctlv{Nctl}=sg_CapCtl_pf_Q('Capacitor.B30060P','B30000P_B30010P','pfoff',-.99,'pfon',.99,'delay',60,'delayoff',240,'kvarmin',650,'state',0,'disable',bitget(xx.CapDisable,5));
% 


%  Load in the model (further information is obtained directly from the
%  model).
%[r,DSSObj]=sg_runOpenDSSSim(k.model,'resultExt',k.resultExt,'DSSObj',opts.DSSObj,'DispFlag',1,'AllowForms',0);
[r,DSSObj]=sg_runOpenDSSSim_gv(k.model,'resultExt',k.resultExt,'DSSObj',opts.DSSObj,'DispFlag',1,'AllowForms',0);


%  Set the source impedance.
k.Zb=(k.SSBasekv^2)/(k.SSXfmrSb*1e-3);
val=xx.Zsrc*k.Zb;  %  Reactance.
param='Vsource.source X1';
sg_scaleParam(DSSObj,param,val,'scale',0);
val=val/k.SSXfmrXtoR;  %  Resistance.
param='Vsource.source R1';
sg_scaleParam(DSSObj,param,val,'scale',0);


%  Load in the load profile.
fn=sprintf('%s/%s.csv',k.dirProfiles,xx.LoadProfile);
LoadProfile=sg_loadTable(fn);

%  Load in the PV profile.
fn=sprintf('%s/%s.csv',k.dirProfiles,xx.PVProfile);
PVProfile=sg_loadTable(fn);


%  Scale the load based on the specified load utilization factor.
% k.LUF=k.PmaxFeeder/k.SSXfmrSb;  %  LUF for the base case.
k.LUF=k.SmaxFeeder/k.ScapacityFeeder;  %  LUF for the base case.
if(xx.LUF<0)
    xx.LUF=k.LUF; 
end
loadScale=xx.LUF/k.LUF;  %  Scale factor by which to scale load tranformers.
LoadProfile.S=LoadProfile.S*xx.LUF*k.ScapacityFeeder;
LoadProfile.P=LoadProfile.S*xx.LoadPF;
LoadProfile.Q=LoadProfile.S*sqrt(1-xx.LoadPF^2);

%  Scale the load transformers.
nvload=DSSObj.ActiveCircuit.Loads.AllNames;
nvXfmr=DSSObj.ActiveCircuit.Transformers.AllNames;
nvloadXfmr=nvXfmr;
nvloadBus=nvload;  %  Just initialize length (these will be overwritten).
Sbv=-1*ones(1,length(nvload));
for(n=1:length(nvload))
    i1=sg_rgrep(nvload{n},nvXfmr);
    %fprintf(1,'Processing number %d (%s).\n',n,nvload{n});
    if(length(i1)==1)
        nm=nvXfmr{i1};
        str1=sprintf('Transformer.%s.kva',nm);
        val=sg_getParam(DSSObj,str1);
        Sbv(n)=str2num(val);
        nvloadXfmr{n}=nm;
        str1=sprintf('Transformer.%s kva',nm);
        sg_scaleParam(DSSObj,str1,loadScale);  % Scale up the load transformer.
        str1=sprintf('Load.%s.bus1',nvload{n});
        nvloadBus{n}=sg_getParam(DSSObj,str1);
    end
end
Sbtot=sum(Sbv);

%  Construct the profile.
Nt=length(nvload)+1;
Nrt=length(LoadProfile.t);
nvprofile=cell(1,Nt);
Mprofile=zeros(Nrt,Nt);
nvprofile{1}='time';
Mprofile(:,1)=LoadProfile.t;
for(n=1:length(nvload))
    nvprofile{n+1}=sprintf('Load.%s kw',nvload{n});
    Mprofile(:,n+1)=LoadProfile.P*Sbv(n)/Sbtot;
    str1=sprintf('Load.%s pf',nvload{n});
    sg_scaleParam(DSSObj,str1,xx.LoadPF,'scale',0);
end


% Nt=2*length(nvload)+1;
% Nrt=length(LoadProfile.t);
% nvprofile=cell(1,Nt);
% Mprofile=zeros(Nrt,Nt);
% nvprofile{1}='time';
% Mprofile(:,1)=LoadProfile.t;
% for(n=1:length(nvload))
%     nvprofile{2*n}=sprintf('Load.%s kw');
%     Mprofile(:,2*n)=LoadProfile.P*Sbv(n)/Sbtot;
%     %  Reactive power.
%     nvprofile{2*n+1}=sprintf('Load.%s kvar');
%     Mprofile(:,2*n+1)=LoadProfile.Q*Sbv(n)/Sbtot;
% end


%  PV
%  Determine the requested total PV power.
if(xx.BulkPVP<0)
    Ppvp=xx.PVpen*k.SmaxFeeder*loadScale;
    %  Determine the total residential PV power.
    if(iscell(xx.PVres)) xx.PVres=cell2mat(xx.PVres); end
    Ppvres=Sbtot*xx.PVres;
    %  Determine the amount of bulk PV power.
    Ppvbulk=Ppvp-Ppvres;
    if(Ppvbulk<0)
        Ppvbulk=0.001;
        Ppvres=Ppvp;
    end
else  % Override PVpen parameter to directly specify the bulk PV power (kW).
    Ppvbulk=xx.BulkPVP;
    Ppvres=Sbtot*xx.PVres;
end


%  Place the bulk PV.
%  Find candidate buses.
i1=find(r.Bus.Vpu.VbkV>=(0.9*k.VbMain));  %  Indices of nodes with voltage rating indicative of the main trunk.
nmvt=r.Bus.Vpu.names(i1);  %  Names of nodes on the main trunk.
dv=r.Bus.Vpu.distance(i1);  %  Distances from the substation of each node on the main trunk.
dtarget=xx.BulkPVPos*max(dv);  %  Target distance at which to place the bulk PV.
ddevv=abs(dv-dtarget);  %  Distance of each node from the target distance.
ddevmin=min(ddevv);  %  Distance of closest node to the target distance.
ii=min(find(ddevv==ddevmin));  %  Index of closest node to the target distance.
tbusnm=nmvt{ii};  %  Name of closest node.
%  Strip off node specific information to get bus name.
p='(?<bus>.+)\..+';
rt=regexp(tbusnm,p,'names');
busnm=rt.bus;
%  Add the bulk PV to the system.
str1=sprintf('New Generator.%s_PVBulk bus1=%s model=1 kW=%f PF=1 phases=3 conn=wye kv=%f',busnm,busnm,Ppvbulk,sqrt(3)*r.Bus.Vpu.VbkV(i1(ii)));
DSSObj.Text.Command=str1;

%  Add the bulk PV power profile.
Nt=length(nvprofile);
nvprofile{Nt+1}=sprintf('Generator.%s_PVBulk kW',busnm);
Mprofile(:,Nt+1)=Ppvbulk*PVProfile.P;

%  Add the residential PV.
%Ppvres
%xx.ResPVPos
%i1=find(r.Bus.Vpu.VbkV<=k.VbRes);  %  Indices of nodes with voltage rating indicative of residential load buses.
% nvload;
% nvloadBus;
%Sbtot=sum(Sbv);
p='(?<bus>[^\.]+)\..+';
nvPvresProf=nvloadBus;  %  Initialize, but these will be over-written.
if(xx.ResPVPos==-1)  % Proportionally distributed PV.
     Pvres=(Ppvres/Sbtot)*Sbv;
else
    
end
%Psyn=sg_synthesizeProfile(PVProfile.t,PVProfile.P,'N',length(Pvres),'method','shift');  %  Synthetic PV profiles for each site.
Psyn=repmat(PVProfile.P,1,length(Pvres));
for(n=1:length(nvload))
      bus=nvloadBus{n};
      rt=regexp(bus,p,'names');
      busnm=rt.bus;
      str1=sprintf('Load.%s.phases',nvload{n});
      phases=str2num(sg_getParam(DSSObj,str1));
      str1=sprintf('Load.%s.kV',nvload{n});
      kV=str2num(sg_getParam(DSSObj,str1));
      if(phases==1)
          str1=sprintf('New Generator.%s_pvres bus1=%s model=1 kW=%f pf=1 phases=1 kv=%f',busnm,bus,Pvres(n),kV);
      else
          str1=sprintf('New Generator.%s_pvres bus1=%s model=1 kW=%f pf=1 phases=3 conn=wye kv=%f',busnm,bus,Pvres(n),kV);
      end
      DSSObj.Text.Command=str1;
      nvPvresProf{n}=sprintf('Generator.%s_pvres kW',busnm);
      Psyn(:,n)=Pvres(n)*Psyn(:,n);
 end

%  Add the residential PV profile.
nvprofile=[nvprofile nvPvresProf'];
Mprofile=[Mprofile Psyn];

%  Save the model.
if(~isempty(opts.target))
    str1=sprintf('Save Circuit file=%s dir=%s','Test',opts.target);
    DSSObj.Text.command=str1;
end

%  Build the profile structure.
profile=struct();
profile.time=Mprofile(:,1);
profile.param=nvprofile(2:end);
profile.val=Mprofile(:,2:end);
profile.fmt={};
for(n=1:length(profile.param))
    profile.fmt{n}='%f'; 
end

% xx.PVctl='none';
% xx.PVctlXDBwidth=.04;
% xx.PVctlXwidth=0.1;
% xx.PVctlXcenter=1;
% xx.PVctlYwidth=-1;
% xx.PVctlmXcenter=0;


%  Include any additional controls.
%opts=struct('model',1,'kW',2300,'pf',1,'kvar',0,'phases',3,'conn','wye','kv',0.48,'Maxkvar',500,'Minkvar',-500,...
%                'mode',1,'XsetPt',[],'YsetPt',[],'pvSb',1,'Vlimits',[]);
%Nctl=Nctl+1;ctlv{Nctl}=sg_CapCtl_pf_Q('Capacitor.B30020P','B30000P_B30010P','pfoff',-.99,'pfon',.99,'delay',240,'delayoff',60,'kvarmin',650,'state',0);

nvGen=DSSObj.ActiveCircuit.Generators.AllNames;
nvNode=DSSObj.ActiveCircuit.AllNodeNames;
dvNode=DSSObj.ActiveCircuit.AllNodeDistances;
dvNode=dvNode/max(dvNode);  %  Normalized distances.
Xset=[.95 .98 1.02 1.05];
Xset(1)=xx.PVctlXcenter-xx.PVctlXwidth/2;
Xset(2)=xx.PVctlXcenter-xx.PVctlXDBwidth/2;
Xset(3)=xx.PVctlXcenter+xx.PVctlXDBwidth/2;
Xset(4)=xx.PVctlXcenter+xx.PVctlXwidth/2;
if(strcmp(xx.PVctl,'none')==0)
    if(xx.PVctlRes==0)
        i1=sg_rgrep('_PVBulk',nvGen,'caseSensitive',0);
        nnv=i1;
    else
        nnv=1:length(nvGen);
    end
    %for(n=1:length(nvGen))
    for(nnn=1:length(nnv))
        n=nnv(nnn);
         str1=sprintf('Generator.%s.kW',nvGen{n});
         P=str2num(sg_getParam(DSSObj,str1));
         nm=sprintf('Generator.%s',nvGen{n});
         str1=sprintf('%Generator.%s.bus1',nvGen{n});
         busnm=sg_getParam(DSSObj,str1);
         %  If needed, remove the .0 at the end of the name.
        if(strcmp(busnm([end-1,end]),'.0')==1)
            busnm=busnm(1:(end-2)); 
        end
        i1=min(sg_rgrep(busnm,nvNode));
        busdist=dvNode(i1);
        Xset=Xset-xx.PVctlmXcenter*busdist;
         if(strcmp(xx.PVctl,'VoltPF')==1)
             if(xx.PVctlYwidth==-1) xx.PVctlYwidth=.2; end
             Yset=[1-xx.PVctlYwidth/2 1 1 1+xx.PVctlYwidth/2];
             Nctl=Nctl+1;ctlv{Nctl}=sg_DGVarCtl(nm,'mode',5,'XsetPt',Xset,'YsetPt',Yset,...
                 'pvPb',P,'pvSb',P*xx.PVctlORF);
         elseif(strcmp(xx.PVctl,'VoltVar')==1)
             if(xx.PVctlYwidth==-1) xx.PVctlYwidth=1; end
             Yset=[xx.PVctlYwidth/2 0 0 -xx.PVctlYwidth/2];
             Nctl=Nctl+1;ctlv{Nctl}=sg_DGVarCtl(nm,'mode',4,'XsetPt',Xset,'YsetPt',Yset,...
                 'pvPb',P,'pvSb',P*xx.PVctlORF);
         elseif(strcmp(xx.PVctl,'PPF')==1)
             if(xx.PVctlYwidth==-1) xx.PVctlYwidth=.3; end
             Xset=[0 0.5 1];
             Yset=[1 1 1+xx.PVctlYwidth/2];
             Nctl=Nctl+1;ctlv{Nctl}=sg_DGVarCtl(nm,'mode',3,'XsetPt',Xset,'YsetPt',Yset,...
                 'pvPb',P,'pvSb',P*xx.PVctlORF);
         end
     end
end

% Run the simulation.
tic;
% [r,DSSObj,time] = sg_runOpenDSSSim(y.Feeder.model,'DSSObj',DSSObj,'profile',y.Feeder.profile,'resultExt',y.Feeder.resultExt,'profilePoints',1);
% [r,DSSObj,time] = sg_runOpenDSSSim('','DSSObj',DSSObj,'profile',profile,'resultExt',k.resultExt,...
%     'profilePoints',opts.profilePoints,'controls',ctlv,'Niterations',opts.Niterations,'dVmax',opts.dVmax);
[r,DSSObj,time] = sg_runOpenDSSSim_gv('','DSSObj',DSSObj,'profile',profile,'resultExt',k.resultExt,...
    'profilePoints',opts.profilePoints,'controls',ctlv,'Niterations',opts.Niterations,'dVmax',opts.dVmax);
if r.status
    r.Tel = toc;
    r.t   = time;
    r.Feeder = k.model;
else
    fprintf(' No power flow results computed by OpenDSS.\n');
    return
end


