function [VI,Rslf,Rs]=sg_hfVI(varargin)
% Computes High Frequency Variability Index
% function r = sg_hfVI(t,P)
%
% Computes High Frequency Variability Index
%
% Inputs:  't'     ... Time array (s)
%          'P'     ... Power array.
%
% Outputs: 'VI   ... High frequency variability index.
%
% Examples(s):
%		r = sg_hfVI(t,P);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682


t=varargin{1};
P=varargin{2};

opts=struct('zeroEdges',-1);
opts=sg_updateOpts(opts,varargin,2);

Rs=1e3*P./max(P);

[Rslf,Rshf]=sg_separateProfile(t,Rs,'zeroEdges',opts.zeroEdges);

VI=sg_VI(t,Rs,t,Rslf);