function ca=sg_loadControlsList(filename)

ca={};
N=0;

fid=fopen(filename);
try
    while 1
        str1=fgetl(fid);
        if(~ischar(str1)) break; end
        N=N+1;
        str2 = sprintf('ca{%d} = %s',N,str1);
        eval(str2);
    end
end

fclose(fid);
