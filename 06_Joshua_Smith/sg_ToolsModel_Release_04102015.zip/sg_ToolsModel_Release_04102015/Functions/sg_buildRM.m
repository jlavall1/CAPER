function R=sg_buildRM(varargin)
% Build Response Matrix
% function r = sg_buildRM(fntab,fnRM,f)
%  
% 
%
% Inputs: fntab	... file name for the data table.
%    	  fnRM 	... name of the target response matrix file
%    	  f		... function handle for function accepting two structures 
%   				and returning a structure of response variables.
%   'overwrite'	... if set to 1, overwrite all table entries.  
%   				If set to 0, use values for existing entries in      
% 					the response matrix (default=1).
%   	  'id'	... a string indicating the name of the column to 
%   				be treated as an ID - should have a unique value 
%					for each row (default is 'Number').
%   	  'N'	...	the number of entries to process (default is -1, 
%      				indicating that all should be processed)
% 
% Outputs: r.	... data (results) structure
%
% Example Call(s):
%      r = sg_buildRM(fntab,fnRM,f,'overwrite',0);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%%
fntab=varargin{1};
fnRM=varargin{2};
f=varargin{3};

opts=struct('overwrite',1,'id','Number','N',-1);
opts=sg_updateOpts(opts,varargin,3);

% fntab=sprintf('%s/%s',DIRTABS,fntab);
% fnRM=sprintf('%s/%s',DIRRM,fnRM);

T=sg_loadTable(fntab);
try
    T.Date=cellstr(T.Date); 
end
RMex=exist(fnRM);
if(RMex~=0)
    RM=sg_loadTable(fnRM); 
    try
       RM.Date=cellstr(RM.Date); 
    end
    RMid=RM.(opts.id);
end
    
sT=sg_sliceStruct(T,1);
r=f(sT);
R=r;
Tid=T.(opts.id);

fnv=fieldnames(T);
if(opts.N==-1)
    NN=2:length(T.(fnv{1}));
else
    NN=opts.N;
end
for(n=NN)
    if((opts.overwrite==0)&(RMex~=0))
        i1=find(RMid==Tid(n));
        if(length(i1)==1)
            r=sg_sliceStruct(RM,i1);
            R=sg_rbind(R,r);
            continue;
        end
    end
    fprintf(1,'Calculating r for %d.\n',n);
    sT=sg_sliceStruct(T,n);
    r=f(sT);
    R=sg_rbind(R,r);
    
    %  Code to debug a problem.
    fnvR=fieldnames(R);
    Nxxxx=length(R.(fnvR{1}));
    for(nxxxx=2:length(fnvR))
        Nyyyy=length(R.(fnvR{nxxxx}));
        if(Nyyyy~=Nxxxx)
            fprintf(1,'****Lengths not the same!*****\n');
            break;
        end
    end
    
end

try
  sg_writeTable(fnRM,R);
catch
   fprintf(1,'\nError attempting to write matrix to file %s.\n',fnRM);
end

%R=T;