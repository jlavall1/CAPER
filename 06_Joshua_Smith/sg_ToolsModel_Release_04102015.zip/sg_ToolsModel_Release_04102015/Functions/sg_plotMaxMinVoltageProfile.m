function [y,varargout] = sg_plotMaxMinVoltageProfile(varargin)
% Plot voltage profiles that contain the highest and lowest values
% function y = sg_plotMaxMinVoltageProfile(varargin)
%
% Function to extract and display information concerning the highest and
% lowest voltage profiles experienced during the simulated time period.
%
% Inputs: 	r       ... data structure with results (as first argument)
%        'data'  	... uses r as data structure with results
%        'figno' 	... figure number, default: 11
%        'vscale'  	... absolute y-min/y-max used for plot(s), 
%						default: [], automatically scaling to zoom-in
% 
% Outputs:  y.			... data (results) structure with Min-Max data
% 			.TidxMax	...
% 			.BidxMax	...
% 			.BusMax 	...
% 			.VpuMax		...
% 			.MaxStr		...
% 			.TidxMin 	...
% 			.BidxMin 	...
% 			.BusMin  	...
% 			.VpuMin  	...
% 			.MinStr  	...
% 			.h       	...
%
% Example Call(s): 
%		y = sg_plotMaxMinVoltageProfile(r);
%		...
%       y = sg_plotMaxMinVoltageProfile('data',r);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%% Parameters
figNo    = 11;
vscale   = [];
DispFlag = 1;  % message display flag (0/1)
fname    = '';  % path\file name to data file (*.mat)
y        = [];
EventLog = {}; % event messages
nout = max(nargout,1)-1;
if nout == 1
    varargout{1} = [];
end
r = [];

%% Options
if isempty(varargin)
    %% Use GUI in case of no data
    fsc = filesep;
    % select data file using GUI
    [filename,pathname] = uigetfile('*.mat','Select a SUNGRIN results file ...');
    if pathname == 0
        if DispFlag
            fprintf('\n You must select a valid (*.mat) file! Terminating.\n');
        end
        EventLog{end+1} = 'Error: No valid data file selected.';
        y.EventLog = EventLog;
        if nout == 1
            r.EventLog = EventLog;
            varargout{1} = r;
        end
        return
    end
    cudir = pwd;
    cd(pathname);
    r = load(filename);
    strName = fieldnames(r);
    r = r.(strName{1});
    cd(cudir);
elseif isstruct(varargin{1})
    r = varargin{1};
    if length(varargin) > 1
        varargin = varargin(2:end);
    else
        varargin = [];
    end
end
if ~isempty(varargin)
    for ii=1:2:length(varargin)
        switch lower(varargin{ii})
            case 'figno'
                figNo = varargin{ii+1};
            case 'dispflag'
                DispFlag = varargin{ii+1};
            case 'data'
                r = varargin{ii+1};
            case 'fname'
                fname = varargin{ii+1};
            case 'vscale'
                vscale = varargin{ii+1};
        end
    end
end
if ~isempty(fname)
    try
        r = load(fname,'-mat');
        strName = fieldnames(r);
        r = r.(strName{1});
    catch
        le = lasterror;
        EventLog{end+1} = sprintf('Error: Plotting min-miax voltage profiles:  %s, File: %s, Line: %.0f',le.message,le.stack(1).name,le.stack(1).line);
        if DispFlag
            fprintf('\n Error loading results data:\n  %s\n',le.message);
            fprintf('\n File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
        end
        y.EventLog = EventLog;
        r.EventLog = EventLog;
        if nout == 1
            varargout{1} = r;
        end
        return
    end
end
if isempty(r)
    % e.g., empty string --> load using GUI
    fsc = filesep;
    % select data file using GUI
    [filename,pathname] = uigetfile('*.mat','Select a SUNGRIN results file ...');
    if pathname == 0
        if DispFlag
            fprintf('\n You must select a valid (*.mat) file! Terminating.\n');
        end
        EventLog{end+1} = 'Error: No valid data file selected.';
        y.EventLog = EventLog;
        if nout == 1
            r.EventLog = EventLog;
            varargout{1} = r;
        end
        return
    end
    cudir = pwd;
    cd(pathname);
    r = load(filename);
    cd(cudir);
    strName = fieldnames(r);
    r = r.(strName{1});
end

try
    %% Locate time-bus pairs
    % maximum voltage
    [y1,idx1] = max(r.Bus.Vpu.val,[],1);
    [VMax,idx2] = max(y1);
    TidxMax = idx1(idx2); % time of occurrance
    BidxMax = idx2;       % corresponding bus
    % minimum voltage
    [y1,idx1] = min(r.Bus.Vpu.val,[],1);
    [VMin,idx2] = min(y1);
    TidxMin = idx1(idx2); % time of occurrance
    BidxMin = idx2;       % corresponding bus
    
    %% Add as two separate plots and indicate time
    y1 = sg_plotVoltageProfile('data',r,'index',TidxMin,'figno',figNo,'vscale',vscale,'c',2,'cdistoffy',0);
    if TidxMin ~= TidxMax
        y2 = sg_plotVoltageProfile('data',r,'index',TidxMax,'clf',0,'figno',figNo,'vscale',vscale,'c',2,'cdistoffy',-1/18);
        title(['Min: ' y1.titlestr ' - Max: ' y2.titlestr])
    else
        y2.titlestr = '';
        title(['Min/Max: ' y1.titlestr])
    end
    set(gcf,'Name','MaxMinVoltProfile');
    
    %% Return related data as structure
    y.TidxMax = TidxMax;
    y.BidxMax = BidxMax;
    y.BusMax  = r.Bus.AllNodeNames{BidxMax};
    y.VpuMax  = VMax;
    y.MaxStr  = y2.titlestr;
    
    y.TidxMin = TidxMin;
    y.BidxMin = BidxMin;
    y.BusMin  = r.Bus.AllNodeNames{BidxMin};
    y.VpuMin  = VMin;
    y.MinStr  = y1.titlestr;
    
    y.h       = gcf;
catch
    % plotting failed: providing error message
    le = lasterror;
    EventLog{end+1} = sprintf('Error: Plotting feeder:\n  %s\nFile: %s, Line: %.0f\n',le.message,le.stack(1).name,le.stack(1).line);
    if DispFlag
        fprintf('\n Error extracting result data:\n  %s\n',le.message);
        fprintf('\n File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
    end
end
y.EventLog = EventLog;
if nout == 1
    r.EventLog = EventLog;
    varargout{1} = r;
end