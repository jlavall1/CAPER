function [f,X]=sg_DTFS(t,x)
% Compute discrete time Fourier transform.
% function [f,X] = sg_DTFS(t,x)
%
% 
%
% Inputs: 	t  	... time array
%			x	... quantity of interest array 	
%
% Outputs: 	f 	... array of frequencies
%			X	... array of complex magnitudes
%
% Example Call(s):
%      [f,X] = sg_DTFS(t,x);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%%
fSample=1/(t(2)-t(1));

index1=1;
index2=length(t);
N=index2-index1+1;

f = fSample*([1:(floor(N/2)+1)]-1)/N;
X=fft(x,N)/(N);

X=2*X(1:length(f)); % just keep the left side of the FFT
X(1)=X(1)/2; % DC component