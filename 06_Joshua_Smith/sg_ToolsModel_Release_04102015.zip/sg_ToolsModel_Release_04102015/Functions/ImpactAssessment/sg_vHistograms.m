function r = sg_vHistograms(varargin)
% Determines voltage statistics in form of histograms.
% function r = sg_vHistograms(varargin)
%
% This function analyses bus voltages in form of histograms.  
% Low voltage buses are analyzed separately. 
%
% Inputs:	r     		... the results data structure created during time series computations
%       	'PlotCum' 	...	show cumulative digrams (1/0)
%       	'fno'      	... (starting) figure number (default 21)
%       	'SubPlots' 	... use one figure with subplots or individual figures
%			'vBins'		... voltage bins: default from min(V) to max(V), every 1%
%			'dvBins'	... voltage change: default from min to max, every 0.1%
%
% Outputs:  r           	... updated data structure
%       	.IA.vHistograms ... structure
%
% Example Call(s):
%
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%% Parameter and option handling, defaults
r = varargin{1};   % data (structure)
vBins  = [];       % every 1 percent from min(V) to max(V), rounded bin edges
dvBins = [];       % every 0.1 percent from min(dV) to max(dV), rounded bin edges
vStep  = 0.01;     % for default bins: width (pu)
dvStep = 0.001;    % for default bins: width (pu)
fno    = 21;       % (starting) figure number
rWidth = 0.9;      % relative bar width (gap helps recognize bins)
PlotCum = 1;       % plot cumulative sum figure (1/0)
SubPlots = 1;      % subplots or individual figures (1/0)
EventLog = {};     % event information

opts = struct('vBins',[], 'dvBins',[], 'fno',fno, 'PlotCum',PlotCum, 'SubPlots',SubPlots);
opts = sg_updateOpts(opts,varargin,1);

%% Analysis setup/helpers
idxVLow = find(r.Bus.Vpu.VbkV <= 1e3); % low voltages buses
idxVMed = find(r.Bus.Vpu.VbkV > 1e3);  % medium voltages buses
vMin = floor(min(min(r.Bus.Vpu.val))*100)/100;
vMax = ceil(max(max(r.Bus.Vpu.val))*100)/100;
nT   = size(r.Bus.Vpu.val,1);
nBus = size(r.Bus.Vpu.val,2);
dV   = diff(r.Bus.Vpu.val);
dvMin = floor(min(min(dV))*1000)/1000;
dvMax = ceil(max(max(dV))*1000)/1000;

% setup for using histc: edges, 1st and last bins are inclusive of min/max values
if isempty(opts.vBins)
    opts.vBins = [vMin:vStep:vMax-vStep,vMax];
else
    % for x-axis setting in custom mode
    vMin = min(min(opts.vBins),vMin);
    vMax = max(max(opts.vBins),vMax);
end
if isempty(opts.dvBins)
    opts.dvBins = [dvMin:dvStep:dvMax-dvStep,vMax];
end

%% Histogram(s)
% overall
if size(r.Bus.Vpu.val,1) > 1
    histAll = sum(histc(r.Bus.Vpu.val,opts.vBins)/nT,2)/nBus;
else
    histAll = histc(r.Bus.Vpu.val,opts.vBins)/nBus;
end
cumAll  = cumsum(histAll);
% overall (changes)
if size(r.Bus.Vpu.val,1) > 1
    histAlldV = sum(histc(dV,opts.dvBins)/(nT-1),2)/nBus;
else
    histAlldV = [];
end
cumAlldV  = cumsum(histAlldV);
% low voltage buses
if size(r.Bus.Vpu.val,1) > 1
    histLV = sum(histc(r.Bus.Vpu.val(:,idxVLow),opts.vBins)/nT,2)/length(idxVLow);
else
    histLV = histc(r.Bus.Vpu.val(:,idxVLow),opts.vBins)/length(idxVLow);
end
cumLV  = cumsum(histLV);

%% Plots
% Up to six figures, individual or as subplots, w/ or w/o cumulative sums
fno0 = opts.fno-1;
figure(opts.fno)
clf
if opts.SubPlots
    subplot(3,1+opts.PlotCum,opts.fno-fno0);
end
bar(opts.vBins(1:end-1)+diff(opts.vBins)/2,histAll(1:end-1)*100,'barwidth',rWidth);
xlabel('voltage (pu)')
ylabel('buses (%)')
xlim([vMin vMax])
set(gca,'XTick',opts.vBins)
set(gcf,'name','Voltage Histogram: Overall')

if opts.PlotCum
    opts.fno = opts.fno + 1;
    if opts.SubPlots
        subplot(3,1+opts.PlotCum,opts.fno-fno0);
    else
        figure(opts.fno)
    end
    bar(opts.vBins(1:end-1)+diff(opts.vBins)/2,cumAll(1:end-1)*100,'barwidth',rWidth);
    xlabel('voltage (pu)')
    ylabel('cumulative (%)')
    xlim([vMin vMax])
    set(gca,'XTick',opts.vBins)
    set(gcf,'name','Voltage Histogram cumulative sum: Overall')
end

opts.fno = opts.fno + 1;
if opts.SubPlots
    subplot(3,1+opts.PlotCum,opts.fno-fno0);
else
    figure(opts.fno)
end
if ~isempty(histAlldV)
    bar((opts.dvBins(1:end-1)+diff(opts.dvBins)/2)*1e3,histAlldV(1:end-1)*100,'barwidth',rWidth);
    xlabel(sprintf('voltage change (pu * 1000 / %.1f min)',(r.t(2)-r.t(1))/60))
    ylabel('buses (%)')
    xlim([dvMin dvMax]*1e3)
    set(gca,'XTick',opts.dvBins*1e3)
    set(gcf,'name','Voltage Change Histogram: Overall')
end

if opts.PlotCum
    opts.fno = opts.fno + 1;
    if opts.SubPlots
        subplot(3,1+opts.PlotCum,opts.fno-fno0);
    else
        figure(opts.fno)
    end
    if ~isempty(histAlldV)
        bar((opts.dvBins(1:end-1)+diff(opts.dvBins)/2)*1e3,cumAlldV(1:end-1)*100,'barwidth',rWidth);
        xlabel(sprintf('voltage change (pu * 1000 / %.1f min)',(r.t(2)-r.t(1))/60))
        ylabel('cumulative (%)')
        xlim([dvMin dvMax]*1e3)
        set(gca,'XTick',opts.dvBins*1e3)
        set(gcf,'name','Voltage Change Histogram cumulative sum: Overall')
    end
end

opts.fno = opts.fno + 1;
if opts.SubPlots
    subplot(3,1+opts.PlotCum,opts.fno-fno0);
else
    figure(opts.fno)
end
bar(opts.vBins(1:end-1)+diff(opts.vBins)/2,histLV(1:end-1)*100,'barwidth',rWidth);
xlabel('voltage (pu)')
ylabel('LV-buses (%)')
xlim([vMin vMax])
set(gca,'XTick',opts.vBins)
set(gcf,'name','Voltage Histogram: Low voltage buses')

if opts.PlotCum
    opts.fno = opts.fno + 1;
    if opts.SubPlots
        subplot(3,1+opts.PlotCum,opts.fno-fno0);
    else
        figure(opts.fno)
    end
    bar(opts.vBins(1:end-1)+diff(opts.vBins)/2,cumLV(1:end-1)*100,'barwidth',rWidth);
    xlabel('voltage (pu)')
    ylabel('cumulative (%)')
    xlim([vMin vMax])
    set(gca,'XTick',opts.vBins)
    set(gcf,'name','Voltage Histogram cumulative sum: Low voltage buses')
end
if opts.SubPlots
    set(gcf,'name','Voltage Histograms')
end

% Return structure
r.IA.vHistograms.histAll.val    = histAll;
r.IA.vHistograms.histAll.Bins   = vBins;
r.IA.vHistograms.histAlldV.val  = histAlldV;
r.IA.vHistograms.histAlldV.Bins = dvBins;
r.IA.vHistograms.histLV.val     = histLV;
r.IA.vHistograms.histLV.Bins    = vBins;

% Event log update
EventLog{end+1} = 'Voltage histogram(s). Done.';
r.EventLog = EventLog;