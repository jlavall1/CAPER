function r = sg_PlotSwTaps(varargin)
% Plots switching event of controlled taps vs. time.
% function r = sg_PlotSwTaps(varargin)
%
% Plots tap position information (vs. time).
%
% Inputs: r.         ... results data structure
%         'fno'      ... figure number (default: 30), plots if fno > 0
%
% Outputs: r.         ... data structure
%           ..RegControl.SwCount ... cumulative switching event counts
%           .EventLog ... string array with event messages
%
% Example Call(s):
%      r = sg_PlotSwTaps(r);
%      r = sg_PlotSwTaps('data',r);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%% Defaults
fno      = 34;   % figure number used
DispFlag = 0;    % command line display flag (0/1), default: off
lWidth   = 2;    % line width in plots
daySec   = 60*60*24; % seconds/day
EventLog = {};  % event information 

%% Handle options
if ~isempty(varargin)
    if isstruct(varargin{1})
        r = varargin{1};
        ArgIdx = 2;
    else
        ArgIdx = 1;
    end
    for ii = ArgIdx:2:length(varargin)
        switch varargin{ii}
            case {'data','d'}
                r = varargin{ii+1};
            case 'subplot'
                subFlag = varargin{ii+1};
            case 'fno'
                fno = varargin{ii+1};
            otherwise
                fprintf(' Unknown option: %s\n',varargin{ii});
        end
    end
else
    if DispFlag
        fprintf('\n Need at least results structure as input.\n');
    end
    EventLog{end+1} = 'Error: No input data to sg_PlotSwTaps().';
    r.EventLog = EventLog;
    return
end

%% Names
names  = r.RegControl.TapNum.names;
NoTaps = length(names);

if NoTaps == 0
    r.EventLog{end+1} = 'No taps found--no switching data.';
    return
end

%% Count turn-on events for each capacitor
SwEvents = diff(r.RegControl.TapNum.val);
r.RegControl.SwCount  = zeros(size(r.RegControl.TapNum.val));
for ii = 1:size(SwEvents,1)
    Event = (SwEvents(ii,:) ~= 0);
    r.RegControl.SwCount(ii+1,:) = r.RegControl.SwCount(ii,:) + Event;
end

%% Figure(s)
if NoTaps > 0
    figure(fno);
    clf
    plot(r.t/daySec,r.RegControl.TapNum.val,'linewidth',lWidth);
    grid on
    ylabel('Tap position(s)');
    xlabel('time (days)');
    set(gcf,'name',['Tap positions vs. time']);
    legend(names,'location','bestoutside')
    
    % cumulative event count
    fno = fno + 1;
    figure(fno);
    clf
    plot(r.t/daySec,r.RegControl.SwCount,'linewidth',lWidth);
    grid on
    ylabel('event count');
    xlabel('time (days)');
    set(gcf,'name',['Tap switching event count vs. time']);
    legend(names,'location','best');
    
    EventLog{end+1} = 'Tap position plot. Done.';
    r.EventLog = EventLog;
else
    EventLog{end+1} = 'Note: No tap regulators in model.';
    r.EventLog = EventLog;
end
