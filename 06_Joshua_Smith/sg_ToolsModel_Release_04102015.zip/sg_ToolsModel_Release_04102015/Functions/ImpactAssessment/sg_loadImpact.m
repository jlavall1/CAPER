function r = sg_loadImpact(varargin)
% Determines Load Impact Indices
% function r = sg_loadImpact(varargin)
%
% This function calculates modified Impact indices SAIDI, CAIDI, SAIFI-> SALII, CALII, SALIFI.  
%
% Inputs: r			... the results (.mat) file output of the OpenDSS simulation loaded into workspace
%		'limits' 	... per unit lower and upper limits of voltage
%		'plot'		... 0-no, 1-yes (default)
%		'fno'		... figure number (default 15)
%
% Outputs: r.		... data (results) structure
%			.IA.loadImpact.	... load impact substructure:
% 						.SALII	... System Average LOAD Impact Index 
% 						.CALII	... Customer Average LOAD Impact Index
% 						.SALIFI	... System Average LOAD Impact Frequency Index
%
% Example Call(s):
% 		r = sg_loadImpact(r,'limits',[0.95 1.05],'plots',0);
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%% Defaults
plotFlag = 1;     % plot: yes
fno      = 15;    % figure number used
fsText   = 10;    % font size for labels/text
DispFlag = 0;     % turn on/off console display (0/1)
limits = [0.95 1.05]; % per unit lower and upper limits of voltage

r.status   = 0;   % success status (0/1)
r.EventLog = {};  % keeps track of warning/error messages (cell array)

if isempty(varargin) || (length(varargin) == 1 && ~isstruct(varargin{1}))
    r.EventLog{end+1} = sprintf('Error: Load Impact Indices: Need data structure as input.');
    if DispFlag,
        fprintf('%s\n',r.EventLog{end});
    end
    return
end
if isstruct(varargin{1})
    r = varargin{1};
    argIdx = 2;
else
    argIdx = 1;
end

%% Handle options
if length(varargin) > 1
    for ii = argIdx:2:length(varargin)
        switch varargin{ii}
            case {'data','d'}
                r = varargin{ii+1};
            case 'plot'
                plotFlag = varargin{ii+1};
            case 'fno'
                fno = varargin{ii+1};
            case 'limits'
                limits = varargin{ii+1};
            otherwise
                fprintf(' Unknown option: %s\n',varargin{ii});
        end
    end
end

%% Compute indices
r=sg_findVoltageExcursion('data',r,'limits',limits,'plot',0);
if r.status
    r.status   = 0;
    r.EventLog = {};
else
    return
end

if (isempty(r.IA.VoltageExcursion.iBusLoad))
    r.IA.loadImpact.SALII=0;
    r.IA.loadImpact.CALII=0;
    r.IA.loadImpact.SALIFI=0;
else
    iE = r.IA.VoltageExcursion.Excursion(r.IA.VoltageExcursion.iBusLoad(:,1));

    vBusN=r.Bus.Vpu.names(r.IA.VoltageExcursion.iBusLoad(:,1));
    
    if ~cellfun('isempty',regexp(vBusN,'^.{6}[p]'))
        for n=1:length(vBusN)
            vBusN{n}=vBusN{n}(1:7);
        end
        bNam=unique(vBusN);
        iEnew = cell(length(bNam),1);
        for n=1:length(bNam)
             i1 = find(~cellfun('isempty',regexp(vBusN,bNam(n))));
             iEnew{n} = {unique([iE{i1(1)},iE{i1(2)},iE{i1(3)}])};
        end
        
        iBusLoadnew=unique(r.IA.VoltageExcursion.iBusLoad(:,2));
        
        Ni=zeros(size(bNam));
        Nt=Ni;
        dt=r.t(2)-r.t(1);
        
        %Total Energy over all Load buses
        Stot=r.Load.S1.val+r.Load.S2.val+r.Load.S3.val;
        Ntot=trapz(real(Stot))*dt;
        
        for n=1:length(bNam)
            pLoad=Stot(:,iBusLoadnew(n));
            p=zeros(size(pLoad));
            p(cell2mat(iEnew{n}))=real(pLoad(cell2mat(iEnew{n})));
            Ni(n)=trapz(p)*dt;
            Nt(n)=trapz(real(pLoad))*dt;
        end
    else
        Ni=zeros(size(vBusN));
        Nt=Ni;
        dt=r.t(2)-r.t(1);

        %Total Energy over all Load buses
        Stot=r.Load.S1.val+r.Load.S2.val+r.Load.S3.val;
        Ntot=trapz(real(Stot))*dt;

        for n=1:length(vBusN)
            pLoad=Stot(:,r.IA.VoltageExcursion.iBusLoad(n,2));
            p=zeros(size(pLoad));
            p(iE{n})=real(pLoad(iE{n}));
            Ni(n)=trapz(p)*dt;
            Nt(n)=trapz(real(pLoad))*dt;
        end
    end
    
    r.IA.loadImpact.SALII=sum(Ni)/sum(Ntot);
    if(isnan(r.IA.loadImpact.SALII) || isinf(r.IA.loadImpact.SALII))
        r.IA.loadImpact.SALII=0;
    end

    r.IA.loadImpact.CALII=sum(Ni)/sum(Nt);
    if(isnan(r.IA.loadImpact.CALII) || isinf(r.IA.loadImpact.CALII))
        r.IA.loadImpact.CALII=0;
    end

    r.IA.loadImpact.SALIFI=r.IA.loadImpact.SALII/r.IA.loadImpact.CALII;
    if(isnan(r.IA.loadImpact.SALIFI) || isinf(r.IA.loadImpact.SALIFI))
        r.IA.loadImpact.SALIFI=0;
    end
end

%% Display as figure/table
if(plotFlag==1)
    figure(fno)
    clf;
    set(gca,'position',[0 0 1 1]);
    set(gca,'xtick',[])
    set(gca,'ytick',[])
    set(gcf,'name','Load Impact Indices');
    
    Names = fieldnames(r.IA.loadImpact);
    desc={'System Average Load Impact Index';...
        'Customer Average Load Impact Index';...
        'System Average Load Impact Frequency Index'};
    Rtext = cell(length(Names),3);    
    for ii = 1:length(Names)
        Rtext{ii,1} = sprintf('%s: ',strrep(Names{ii},'_',' '));
        Rtext{ii,2} = sprintf('%.5f %s',r.IA.loadImpact.(Names{ii}));
        Rtext{ii,3} = num2str(desc{ii});
        text(.2,length(Names)-ii/2+1,Rtext{ii,1},'fontsize',fsText,'HorizontalAlignment','right');
        text(.25,length(Names)-ii/2+1,Rtext{ii,2},'fontsize',fsText,'HorizontalAlignment','center');
        text(.3,length(Names)-ii/2+1,Rtext{ii,3},'fontsize',fsText,'HorizontalAlignment','left');
    end
    text(.5,length(Names)+1,'Load Impact Indices:','fontsize',fsText,...
        'HorizontalAlignment','center','color',[0 0 1]);
    xlim([0 1]);
    ylim([0 length(Names)+2]);
end

r.status   = 1;