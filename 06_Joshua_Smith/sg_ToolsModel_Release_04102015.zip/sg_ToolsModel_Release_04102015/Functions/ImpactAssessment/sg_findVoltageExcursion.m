function r = sg_findVoltageExcursion(varargin)
% Determines voltage excursion incidents.
% function r = sg_findVoltageExcursion(varargin)
%
% Helper function which determines and returns voltage excursions. 
% The structure returned contains indices of loads and generators  
% connected to buses containing voltage excursions.
%
% Inputs: r		... the results (.mat) file output of the OpenDSS 
% 					simulation loaded into workspace
% 		'limits'... per unit lower and upper limits of voltage 
%					(default [0.95 1.05])
% 		'fno'	... figure number (default 40)
% 		'plot' 	... 0-no, 1-yes(default)
%		'type'	... low voltage buses ('LV') or medium voltage buses ('MV'),
%					default finds both low voltage and medium voltage buses
%
% Outputs: r.			... data (results) structure with added fields:
% 			.IA.VoltageExcursion.		... voltage excursion substructure:
%								.Excursion	... cell array containing 
%												voltage excursion values per bus
% 								.iBusLoad	... Bus and Load indices which contain 
%												voltage excursion
% 								.iBusGen	... Bus and Gen indices which contain 
%												voltage excursion
%
% Example Call(s):
%		r = sg_findVoltageExcursion(r);
%		...
%		r = sg_findVoltageExcursion(r,'limit',[0.94 1.03],'type','MV');
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%% Defaults
plotFlag = 1;     % plot: yes
fno      = 40;    % figure number used
fsText   = 10;    % font size for labels/text
DispFlag = 0;     % turn on/off console display (0/1)
limits = [0.95 1.05]; % per unit lower and upper limits of voltage

r.status = 0;     % success status (0/1)
EventLog = {};    % keeps track of warning/error messages (cell array)

if isempty(varargin) || (length(varargin) == 1 && ~isstruct(varargin{1}))
    r.EventLog{end+1} = sprintf('Error: Voltage Excursion: Need data structure as input.');
    if DispFlag,
        fprintf('%s\n',r.EventLog{end});
    end
    return
end
if isstruct(varargin{1})
    r = varargin{1};
    argIdx = 2;
else
    argIdx = 1;
end

%% Handle options
if length(varargin) > 1
    for ii = argIdx:2:length(varargin)
        switch varargin{ii}
            case {'data','d'}
                r = varargin{ii+1};
            case 'plot'
                plotFlag = varargin{ii+1};
            case 'fno'
                fno = varargin{ii+1};
            case 'limits'
                limits = varargin{ii+1};
            otherwise
                fprintf(' Unknown option: %s\n',varargin{ii});
        end
    end
end

BusNames = r.Bus.Vpu.names;
LoadNames = r.Load.names;
if isfield(r.Generator,'BusNames')
    GenNames = r.Generator.BusNames;
else
    GenNames = [];
end

%find total instances of voltage excursion per bus
Excursion={};
for(n=1:size(r.Bus.Vpu.val,2))
    Excursion{n} = find(r.Bus.Vpu.val(:,n) > limits(2) | r.Bus.Vpu.val(:,n) < limits(1));
end

%find bus indices in which excursions occur
iExcur = find(~cellfun('isempty',Excursion));
if isempty(iExcur)
    EventLog{end+1} = 'Voltage excursions: No violations.';
end

%find load which relates to vBusN(iExcur)
iBusLoad=[];
l=1;
if(~isempty(iExcur))
    for(n=1:length(iExcur))
        bNam = BusNames{iExcur(n)}(1:7);
        i1 = find(~cellfun('isempty',regexp(LoadNames,bNam)));
        if(~isempty(i1))
            iBusLoad(l,1)=iExcur(n);
            iBusLoad(l,2)=i1;
            l=l+1;
        end
    end
else
    iBusLoad=[];
end

%find gen which relates to vBusN(iExcur)
iBusGen=[];
l=1;
if(~isempty(iExcur))
    for(n=1:length(iExcur))
        bNam = BusNames{iExcur(n)}(1:7);
        i1 = find(~cellfun('isempty',regexp(GenNames,bNam)));
        if(~isempty(i1))
            iBusGen(l,1)=iExcur(n);
            iBusGen(l,2)=i1;
            l=l+1;
        end
    end
else
    iBusGen=[];
end

r.IA.VoltageExcursion.Excursion=Excursion;
r.IA.VoltageExcursion.iBusLoad=iBusLoad;
r.IA.VoltageExcursion.iBusGen=iBusGen;

if plotFlag == 1
    [y,varargout] = sg_plotFeeder(r,'c',0,'figno',fno);
    title('');
    set(gcf,'name','Feeder buses with voltage excursion');
    hold on;
    
    for n = 1:length(iExcur)
        idx = strfind(BusNames{iExcur(n)},'.');
        if ~isempty(idx)
            bName = BusNames{iExcur(n)}(1:idx(1)-1);
        else
            bName = BusNames{iExcur(n)};
        end
        idx = find(~cellfun('isempty',regexp(r.Bus.AllBusNames,bName)));
        if(~isempty(idx))
            plot(r.Bus.xy(idx,1), r.Bus.xy(idx,2),'s','MarkerFaceColor','y','MarkerSize',10);
            text(r.Bus.xy(idx,1),r.Bus.xy(idx,2)+0.2,r.Bus.AllBusNames(idx),'fontsize',fsText);
        end
    end
    
    hold off;
end

% Event log update
EventLog{end+1} = 'Voltage excursions plot. Done.';
r.EventLog = EventLog;

