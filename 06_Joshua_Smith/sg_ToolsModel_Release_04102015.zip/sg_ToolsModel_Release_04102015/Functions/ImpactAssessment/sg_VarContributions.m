function r = sg_VarContributions(varargin)
% Computes reactive power contributions.
% function r = sg_VarContributions(r)
%
% This function obtains the reactive power contribution by voltage
% regulation devices (SCB and PVs) over the entire simulation time.
% This function can also calculate the reactive power contribution by the
% substation. The user will need to specify the name of the bus at which
% the substation is located. If one of the devices doesn�t exist,
% the function returns an empty struct for those values and displays that
% such device does not exist.
%
% Inputs: r 		... data structure
%		'SubName'	... Substation name
%		'plot'		... 0-no(default), 1-yes
%		'fno'		... figure number (default 60)
%		'elements'	... option to plot by each device (default 1)
%
% Outputs: r.	... updated results structure
%			.IA.VarContr.	... var contribution substructure
% 					.SubStation.
%					.Generator.
%					.Capacitor.
%							.names		... bus names
% 							.S1			... Phase A vars
% 							.S2			... Phase B vars
% 							.S3			... Phase C vars
% 							.sum		... Sum of vars contributed
% 							.total		... Total sum of vars contributed
% 							.mean		... Mean value of the vars contributed
% 							.max		... Maximun value of the vars contributed
% 							.min		... Minimun value of the vars contributed
% 							.variance	... Variance of the vars contributed
%
% Example Call(s):
% r = sg_VarContributions(r,'plot',1,'fno',30,'elements',0);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under
% Awards DE-EE0002063 and DE-EE0004682
%

%% Setup/defaults
r = varargin{1};
opts=struct('SubName','','plot',0,'fno',70,'elements',1);
opts=sg_updateOpts(opts,varargin,1);

% in case of no substation name specified: try to locate in data structure
try
    if ~isempty(r.Bus.SubStation.name)
        opts.SubName = r.Bus.SubStation.name;
    end
catch
    % noop in case sub-structure does not exit
end
flagD = 1;
DispFlag = 0;           % Console display of messages
VarContr = struct();    % Create struct for Vars contribution function results
EventLog = {};          % event information

%-------------------------------------------------------------------------%
%---------------Calculating PV Generators Vars contributions--------------%
%-------------------------------------------------------------------------%
if isfield(r.Generator,'BusNames')
    flagGen = isempty(r.Generator.BusNames);
else
    flagGen = 1;
end
if (flagGen == 0)
    genBusName = r.Generator.BusNames;  % Generator bus name
    nameGen = r.Generator.S1.names;     % Generator names
    
    % The following function extracts reactive power information from
    % results structure of the PV generators
    varsGenS1v = abs(imag(r.Generator.S1.val));
    varsGenS2v = abs(imag(r.Generator.S2.val));
    varsGenS3v = abs(imag(r.Generator.S3.val));
    varsGenv = varsGenS1v + varsGenS2v + varsGenS3v; % Returns a n-by-m matrix of each Generator 3-phase vars over time
    
    % The following sums the Vars contributed by each Generator
    % and groups them in a n-by-1 matrix for each phase
    varsGenS1 = sum(varsGenS1v,2); % Total phase A Vars
    varsGenS2 = sum(varsGenS2v,2); % Total phase B Vars
    varsGenS3 = sum(varsGenS3v,2); % Total phase C Vars
    varsGent = varsGenS1+varsGenS2+varsGenS3;   % Returns a n-by-1 matrix of the total 3-phase vars over time
    
    varsGenT = sum(varsGent);       % Returns the total vars contributed
    varsGenMean = mean(varsGenv);   % Calculates the mean value of the vars contributed by each Generator
    varsGenMax = max(varsGenv);     % Calculates the maximum value of the vars contributed by each Generator
    varsGenMin = min(varsGenv);     % Calculates the minimum value of the vars contributed by each Generator
    varsGenVariance = var(varsGenv);% Calculates the variances of the vars contributed by each Generator
    
else
    % No PV generators data available
    if DispFlag, fprintf('No pv generator on the feeder.\n'); end;
    %     disp('NO PV GENERATOR ON THE FEEDER');
    genBusName = {}
    nameGen = {};
    varsGenS1v = {};
    varsGenS2v = {};
    varsGenS3v = {};
    varsGenv = {};
    varsGent = {};
    varsGenT = {};
    varsGenMean = 0;
    varsGenMax = 0;
    varsGenMin = 0;
    varsGenVariance = 0;
end

VarContr.Generator.BusName = genBusName;        % PV Generator Bus name
VarContr.Generator.names = nameGen;             % PV Generator names
VarContr.Generator.S1 = varsGenS1v;             % Phase A vars
VarContr.Generator.S2 = varsGenS2v;             % Phase B vars
VarContr.Generator.S3 = varsGenS3v;             % Phase C vars
VarContr.Generator.varsGenv = varsGenv;         % 3-phase vars of each PV Generator
VarContr.Generator.sum = varsGent;              % Sum of the vars contributed (vectorized)
VarContr.Generator.total = varsGenT;            % Total sum of the vars contributed
VarContr.Generator.mean = varsGenMean;          % Mean value of the vars contributed
VarContr.Generator.max = varsGenMax;            % Maximun value of the vars contributed
VarContr.Generator.min = varsGenMin;            % Minimun value of the vars contributed
VarContr.Generator.variance = varsGenVariance;  % Variance of the vars contributed

%-------------------------------------------------------------------------%
%-----------------Calculating Capacitors Vars contributions---------------%
%-------------------------------------------------------------------------%
flagCap = isempty(r.Capacitor.names);
if (flagCap == 0)
    nameCap = r.Capacitor.names;    % Capacitor names
    
    % The following function extracts reactive power information from
    % results structure of the capacitor banks
    varsCapS1v = abs(imag(r.Capacitor.S1.val));
    varsCapS2v = abs(imag(r.Capacitor.S2.val));
    varsCapS3v = abs(imag(r.Capacitor.S3.val));
    varsCapv = varsCapS1v + varsCapS2v + varsCapS3v; % Returns a n-by-m matrix of each Capacitor bank 3-phase vars over time
    
    % The following sums the Vars contributed by each Capacitor bank
    % and groups them in a n-by-1 matrix for each phase
    varsCapS1 = sum(varsCapS1v,2); % Phase A Vars
    varsCapS2 = sum(varsCapS2v,2); % Phase B Vars
    varsCapS3 = sum(varsCapS3v,2); % Phase C Vars
    varsCapt = varsCapS1+varsCapS2+varsCapS3;   % Returns a n-by-1 matrix of the total 3-phase vars over time
    
    varsCapT = sum(varsCapt);      % Returns the total vars contributed
    varsCapMean = mean(varsCapv);  % Calculates the mean value of the vars contributed
    varsCapMax = max(varsCapv);    % Calculates the maximum value of the vars contributed
    varsCapMin = min(varsCapv);    % Calculates the minimum value of the vars contributed
    varsCapVariance = var(varsCapv); % Calculates the variances of the vars contributed
else
    % No capacitor bank data available
    if DispFlag, fprintf('No capacitor banks on the feeder.\n'); end;
    %     disp('NO CAPACITOR BANKS ON THE FEEDER');
    nameCap = 0;
    varsCapS1v = {};
    varsCapS2v = {};
    varsCapS3v = {};
    varsCapv = {};
    varsCapt = {};
    varsCapT = {};
    varsCapMean = 0;
    varsCapMax = 0;
    varsCapMin = 0;
    varsCapVariance = 0;
end


VarContr.Capacitor.names = nameCap;             % Capacitor banks names
VarContr.Capacitor.S1 = varsCapS1v;             % Phase A vars
VarContr.Capacitor.S2 = varsCapS2v;             % Phase B vars
VarContr.Capacitor.S3 = varsCapS3v;             % Phase C vars
VarContr.Capacitor.varsCapv = varsCapv;         % 3-phase vars of each capacitor
VarContr.Capacitor.sum = varsCapt;              % Sum of the vars contributed vectorized
VarContr.Capacitor.total = varsCapT;            % Total sum of the vars contributed
VarContr.Capacitor.mean = varsCapMean;          % Mean value of the vars contributed
VarContr.Capacitor.max = varsCapMax;            % Maximun value of the vars contributed
VarContr.Capacitor.min = varsCapMin;            % Minimun value of the vars contributed
VarContr.Capacitor.variance = varsCapVariance;  % Variance of the vars contributed

%-------------------------------------------------------------------------%
%---------------Calculating Sub Station Vars contributions----------------%
%-------------------------------------------------------------------------%
flagSrc = isempty(opts.SubName);
if (flagSrc == 0)
    nameSrc = opts.SubName; % Source name
    % Attempt to find Sub Station data location
    i1 = find(~cellfun(@isempty,strfind(r.Transformer.names,nameSrc)));
    i2 = find(~cellfun(@isempty,strfind(r.Line.S1.names,nameSrc)));
    
    if (isempty(i1) == 0)
        % The following function extracts reactive power information from
        % results structure of the Sub Station
        varsSrcS1v = abs(imag(r.Transformer.S1.val(:,i1)));
        varsSrcS2v = abs(imag(r.Transformer.S2.val(:,i1)));
        varsSrcS3v = abs(imag(r.Transformer.S3.val(:,i1)));
        flagD = 0;
    elseif (isempty(i2) == 0)
        % The following function extracts reactive power information from
        % results structure of the Sub Station
        varsSrcS1v = abs(imag(r.Line.S1.val(:,i2)));
        varsSrcS2v = abs(imag(r.Line.S2.val(:,i2)));
        varsSrcS3v = abs(imag(r.Line.S3.val(:,i2)));
        flagD = 0;
    else
        if DispFlag, fprintf('Substation data not found. Check substation name provided.\n'); end
        %         disp('SUB STATION DATA NOT FOUND. PLEASE CHECK SUB STATION NAME PROVIDED')
        varsSrcS1v = {};
        varsSrcS2v = {};
        varsSrcS3v = {};
    end
    
    if (flagD == 0);
        varsSrct = varsSrcS1v+varsSrcS2v+varsSrcS3v;   % Returns a n-by-1 matrix of the total 3-phase vars over time
        
        varsSrcT = sum(varsSrct);      % Returns the total vars contributed
        varsSrcMean = mean(varsSrct);  % Calculates the mean value of the vars contributed
        varsSrcMax = max(varsSrct);    % Calculates the maximum value of the vars contributed
        varsSrcMin = min(varsSrct);    % Calculates the minimum value of the vars contributed
        varsSrcVariance = var([varsSrcS1v varsSrcS2v varsSrcS3v]); % Calculates the variances of the vars contributed
    else
        varsSrct = {};
        varsSrcT = {};
        varsSrcMean = 0;
        varsSrcMax = 0;
        varsSrcMin = 0;
        varsSrcVariance = 0;
    end
    
else
    % No Sub Station data available
    if DispFlag, fprintf('Substation name not provided.\n'); end
    %     disp('SUB STATION NAME NOT PROVIDED');
    varsSrcS1v = {};
    varsSrcS2v = {};
    varsSrcS3v = {};
    varsSrct = {};
    varsSrcT = {};
    varsSrcMean = 0;
    varsSrcMax = 0;
    varsSrcMin = 0;
    varsSrcVariance = 0;
end
VarContr.SubStation.names = {nameSrc};          % Sub Station bus names
VarContr.SubStation.S1 = varsSrcS1v;            % Phase A vars
VarContr.SubStation.S2 = varsSrcS2v;            % Phase B vars
VarContr.SubStation.S3 = varsSrcS3v;            % Phase C vars
VarContr.SubStation.sum = varsSrct;             % Sum of vars contributed
VarContr.SubStation.total = varsSrcT;           % Total sum of vars contributed
VarContr.SubStation.mean = varsSrcMean;         % Mean value of the vars contributed
VarContr.SubStation.max = varsSrcMax;           % Maximun value of the vars contributed
VarContr.SubStation.min = varsSrcMin;           % Minimun value of the vars contributed
VarContr.SubStation.variance = varsSrcVariance; % Variance of the vars contributed

r.IA.VarContr = VarContr; % Appending the results to the base structure (r)

%-------------------------------------------------------------------------%
%-------------------Plotting Vars contributions results-------------------%
%-------------------------------------------------------------------------%
if(opts.plot>0)
    fn = opts.fno-1;
    frmt='-djpeg';
    fontname='Arial';
    fontsize=12;
    %legfontsize=10;
    markersize=10;
    linewidth=1.5;
    layout=1;
    LOC = 'Best';
    if(layout==1)
        figureposition=[.1 .01 .65 .85];
    else
        figureposition=[.01 .3 .75 .6];
    end
    colorv={'k','b','r','m','g','k:','b:','r:','m:','g:','k--','b--','r--','m--','g--'};
    time = r.t/60/60/24;    % Convert time from seconds to days
    
    % Overall contributions
    fn = fn + 1;
    figure(fn)
    varct=(sum(VarContr.SubStation.mean)+sum(VarContr.Capacitor.mean)+sum(VarContr.Generator.mean))/100;
    varc=[ {(VarContr.SubStation.mean)./varct} ; {(VarContr.Capacitor.mean)./varct} ; {(VarContr.Generator.mean)./varct}];
    varcn = max(cellfun(@length,varc));
    f = @(x) (sg_VarContributions1_zeropad(x,varcn));
    varc = cellfun(f,varc,'UniformOutput',false);
    varcx = cat(1,varc{:});
    bar(varcx);
    grid on;
    set(gca,'XTickLabel',{'SubStation','Capacitor Banks','PV Systems'});
    title('VAR contributions')
    ylabel('Percentage of VAR contributed during simulation in %')
    set(gcf,'name','VAR contributions')
    
    % Plotting PV Generators Vars info
    if opts.elements
        if (flagGen == 0)
            ntemp = size(r.IA.VarContr.Generator.names);
            n = ntemp(1);
            for ii = 1:n
                fn = fn + 1;
                figure(fn);
                plot(time,r.IA.VarContr.Generator.varsGenv(:,ii),'MarkerSize',markersize,'LineWidth',linewidth);
                xlabel('t (days)','FontName',fontname,'FontSize',fontsize);
                ylabel('Reactive Power (kvar)','FontName',fontname,'FontSize',fontsize);
                grid on;
                legendtext = r.Generator.S1.names(ii);
                legend(legendtext,'Location',LOC,'FontName',fontname,'FontSize',fontsize);
                title('Generator','FontName',fontname,'FontSize',fontsize);
                set(gcf,'name',['Generator VAR: ' r.IA.VarContr.Generator.names{ii}]);
            end
        end
        
        % Plotting Capacitor Vars info
        if (flagCap == 0)
            ntemp = size(r.IA.VarContr.Capacitor.names);
            n = ntemp(1);
            for ii = 1:n
                fn = fn + 1;
                figure(fn);
                plot(time,r.IA.VarContr.Capacitor.varsCapv(:,ii),'MarkerSize',markersize,'LineWidth',linewidth);
                xlabel('t (days)','FontName',fontname,'FontSize',fontsize);
                ylabel('Reactive Power (kvar)','FontName',fontname,'FontSize',fontsize);
                grid on;
                legendtext = r.Capacitor.S1.names(ii);
                legend(legendtext,'Location',LOC,'FontName',fontname,'FontSize',fontsize);
                title('Capacitor','FontName',fontname,'FontSize',fontsize);
                set(gcf,'name',['Capacitor VAR: ' r.IA.VarContr.Capacitor.names{ii}]);
            end
        end
        
        % Plotting Sub Station Vars info
        if (flagD == 0)
            ntemp = size(r.IA.VarContr.SubStation.names);
            n = ntemp(1);
            for ii = 1:n
                fn = figure(fn+1);
                plot(time,r.IA.VarContr.SubStation.sum,'MarkerSize',markersize,'LineWidth',linewidth);
                xlabel('t (days)','FontName',fontname,'FontSize',fontsize);
                ylabel('Reactive Power (kvar)','FontName',fontname,'FontSize',fontsize);
                grid on;
                legendtext = r.IA.VarContr.SubStation.names;
                legend(legendtext,'Location',LOC,'FontName',fontname,'FontSize',fontsize);
                title('Substation','FontName',fontname,'FontSize',fontsize);
                set(gcf,'name',['SubStation VAR: ' r.IA.VarContr.SubStation.names{ii}]);
            end
        end
    end
end

% Event log update
EventLog{end+1} = 'VAR contributions. Done.';
r.EventLog = EventLog;
end

function r = sg_VarContributions1_zeropad(x,N)
Nadd=N-length(x);
Npre=round(Nadd/2);
Npost=Nadd-Npre;
r=[zeros(1,Npre) x zeros(1,Npost)];
end