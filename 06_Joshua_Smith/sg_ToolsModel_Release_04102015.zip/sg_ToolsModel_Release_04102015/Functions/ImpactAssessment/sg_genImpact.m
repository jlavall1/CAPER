function r = sg_genImpact(varargin)
% Determines Generation Impact Indices
% function r = sg_genImpact(varargin)
%
% This function calculates modified Impact indices SAIDI, CAIDI, SAIFI-> SAGII, CAGII, SAGIFI
%
% Inputs: r			... the results (.mat) file output of the OpenDSS simulation loaded into workspace
%		'limits' 	... per unit lower and upper limits of voltage
%		'plot'		... 0-no, 1-yes (default)
%		'fno'		... figure number (default 16)
%
% Outputs: r.		... data (results) structure
%			.IA.genImpact.	... gen impact substructure:
% 						.SAGII	... System Average GEN Impact Index 
% 						.CAGII	... Customer Average GEN Impact Index
% 						.SAGIFI	... System Average GEN Impact Frequency Index
%
% Example Call(s):
% 		r = sg_genImpact(r,'limits',[0.85 1.24],'plots',0);
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%% Defaults
plotFlag = 1;    % plot: yes
fno      = 16;   % figure number used
fsText   = 10;    % font size for labels/text
DispFlag = 0;    % turn on/off console display (0/1)
limits = [0.95 1.05]; % per unit lower and upper limits of voltage

r.status   = 0;    % success status (0/1)
r.EventLog = {};   % keeps track of warning/error messages (cell array)

if isempty(varargin) || (length(varargin) == 1 && ~isstruct(varargin{1}))
    r.EventLog{end+1} = sprintf('Error: PV Impact Indicies: Need data structure as input.');
    if DispFlag,
        fprintf('%s\n',r.EventLog{end});
    end
    return
end
if isstruct(varargin{1})
    r = varargin{1};
    argIdx = 2;
else
    argIdx = 1;
end

%% Handle options
if length(varargin) > 1
    for ii = argIdx:2:length(varargin)
        switch varargin{ii}
            case {'data','d'}
                r = varargin{ii+1};
            case 'plot'
                plotFlag = varargin{ii+1};
            case 'fno'
                fno = varargin{ii+1};
            case 'limits'
                limits = varargin{ii+1};
            otherwise
                fprintf(' Unknown option: %s\n',varargin{ii});
        end
    end
end

%% Compute indices
r=sg_findVoltageExcursion('data',r,'limits',limits,'plot',0);
if r.status
    r.status   = 0;
    r.EventLog = {};
else
    return
end

if (isempty(r.IA.VoltageExcursion.iBusGen))
    r.IA.genImpact.SAGII=0;
    r.IA.genImpact.CAGII=0;
    r.IA.genImpact.SAGIFI=0;
else
    iE = r.IA.VoltageExcursion.Excursion(r.IA.VoltageExcursion.iBusGen(:,1));

    vBusN=r.Bus.Vpu.names(r.IA.VoltageExcursion.iBusGen(:,1));

    Ni=zeros(size(vBusN));
    Nt=Ni;
    dt=r.t(2)-r.t(1);
    
    %Total Energy over all Load buses
    Stot=r.Generator.S1.val+r.Generator.S2.val+r.Generator.S3.val;
    Ntot=trapz(real(Stot))*dt;
    
    for n=1:length(vBusN)
        pGen=Stot(:,r.IA.VoltageExcursion.iBusGen(n,2));
        p=zeros(size(pGen));
		p(iE{n})=real(pGen(iE{n}));
        Ni(n)=trapz(p)*dt;
        Nt(n)=trapz(real(pGen))*dt;
    end

	r.IA.genImpact.SAGII=abs(sum(Ni)/sum(Ntot));
    
        if(isnan(r.IA.genImpact.SAGII) || isinf(r.IA.genImpact.SAGII))
            r.IA.loadImpact.SAGII=0;
        end

	r.IA.genImpact.CAGII=abs(sum(Ni)/sum(Nt));
    
        if(isnan(r.IA.genImpact.CAGII) || isinf(r.IA.genImpact.CAGII))
            r.IA.loadImpact.CAGII=0;
        end

	r.IA.genImpact.SAGIFI=abs(r.IA.genImpact.SAGII/r.IA.genImpact.CAGII);
    
        if(isnan(r.IA.genImpact.SAGIFI) || isinf(r.IA.genImpact.SAGIFI))
            r.IA.loadImpact.SAGIFI=0;
        end
end

%% Display as figure/table
if(plotFlag==1)
    figure(fno)
    clf;
    set(gca,'position',[0 0 1 1]);
    set(gca,'xtick',[])
    set(gca,'ytick',[])
    set(gcf,'name','PV Impact Indices');
    
    Names = fieldnames(r.IA.genImpact);
    desc={'System Average PV Gen Impact Index';...
        'Customer Average PV Gen Impact Index';...
        'System Average PV Gen Impact Frequency Index'};
    Rtext = cell(length(Names),3);
    for ii = 1:length(Names)
        Rtext{ii,1} = sprintf('%s: ',strrep(Names{ii},'_',' '));
        Rtext{ii,2} = sprintf('%.5f %s',r.IA.genImpact.(Names{ii}));
        Rtext{ii,3} = num2str(desc{ii});
        text(.2,length(Names)-ii/2+1,Rtext{ii,1},'fontsize',fsText,'HorizontalAlignment','right');
        text(.25,length(Names)-ii/2+1,Rtext{ii,2},'fontsize',fsText,'HorizontalAlignment','center');
        text(.3,length(Names)-ii/2+1,Rtext{ii,3},'fontsize',fsText,'HorizontalAlignment','left');
    end
    text(.5,length(Names)+1,'PV Impact Indices:','fontsize',fsText,...
        'HorizontalAlignment','center','color',[0 0 1]);
    xlim([0 1]);
    ylim([0 length(Names)+2]);
end

r.status   = 1;
