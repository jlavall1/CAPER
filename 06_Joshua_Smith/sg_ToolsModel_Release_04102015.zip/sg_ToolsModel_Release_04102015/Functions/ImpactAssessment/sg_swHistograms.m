function r = sg_swHistograms(varargin)
% Component state analysis using histograms.
% function r = sg_swHistograms(varargin)
%
% Computes and plots information concerning switching events. Note: Function
% as written only returns results in case at least one full switching
% cycle, i.e., three switching events, is detected. Default data bins are
% provided that focus analysis on fast switching events (e.g., component's state
% changes every time, every other time, etc.)
%
% Inputs: 'sig','s'  ... signal vector or matrix, binary (i.e.,
%                        status information, 0-off, 1-on)
%                        If not specified: Defaults to r.Capacitor.State.val
%         'names'    ... cell array of text strings for component names
%         'plot'     ... 0-no, 1-yes (default)
%         'subplot'  ... 0-no, 1-yes (default)
%         'fno'      ... figure number (default: 100)
%         'data'     ... results data structure, .Capacitor.State.val will
%                        be analyzed
%   'binchoice','bc' ... choice of bins for histograms:
%                        1 - [1 2 5 10 20 50 100 max] (default)
%                        2 - log10-spaced between minimum and maximum
%         'bins','b' ... custom bins, note: will automatically add lower bound
%                        of zero, and add a small offset (1e-3) to other edges.
%
% Outputs: r.        ... data (results) structure
%          .IA.sw.		... switching states substructure
%				.Toff  		... off-times/durations (s)
%          		.Ton   		...
%          		.TCyc  		...
%          		.hf    		... figure handle
%          		.ytlNoCust 	... numeric custom Y-tick labels (used in the plot)
%
% Example Call(s):
%      r = sg_swHistograms('data',r,'subplot',1);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%% Defaults
plotFlag = 1;    % plot: yes
subFlag  = 0;    % subplots: no
subFigs  = 6;    % number of device-plots per sub-figure
fno      = 100;  % figure number used
t        = [];   % based on 'points'
level    = 0.5;  % switching level
sw       = [];   % computed data (structure)
r        = [];   % will add to results structure if provided
S        = [];   % status signals to be analyzed
names    = {};   % component names (if to be displayed)
BinChoice= 1;    % use selected bins that focus on 'fast' switching: BinsSW
Bins     = [];   % time steps (duration) data bins
binRate  = 2;    % choice between fast and slow switching analysis setup
BinsSW_fs  = [0 [1 2 5 10 20 50 100]+1e-3];   % time steps data bins (limited to bins of concern
%                                         with respect to short time intervals between switching)
MinPerDay = 60*24; % minutes per day
BinsSW_sl  = [0 [1 2 5 10 30 90]*MinPerDay+1e-3];   % for slower, daily operations
rWidth   = 0.9;  % relative bar width (gap helps recognize bins)
fsText   = 8;    % font size for labels/text
xOff     = 1.025;
EventLog = {};    % event information

%% Handle options
for ii = 1:2:length(varargin)
    switch varargin{ii}
        case {'sig','s'}
            S = varargin{ii+1};
        case {'names','n'}
            names = varargin{ii+1};
        case {'binchoice','bc'}
            BinChoice = varargin{ii+1};
        case {'bins','b'}
            Bins = [0 varargin{ii+1}+1e-3];
            BinChoice = 3;
        case {'binRate','br'}
            binRate = varargin{ii+1};
        case {'data','d'}
            r = varargin{ii+1};
            S = r.Capacitor.State.val;
            names = r.Capacitor.names;
        case {'time','t'}
            t = varargin{ii+1}/60;
            xlabelTxt = 'time (min)';
        case 'plot'
            plotFlag = varargin{ii+1};
        case 'subplot'
            subFlag = varargin{ii+1};
        case 'fno'
            fno = varargin{ii+1};
        otherwise
            fprintf(' Unknown option: %s\n',varargin{ii});
    end
end
% time vector
if isempty(t)
    t = [1:1:size(S,1)];
    xlabelTxt = 'points';
end
% binRate: fast or slow
if binRate == 1
    BinsSW = BinsSW_fs;
else
    BinsSW = BinsSW_sl;
end

if length(t) < 2
    EventLog{end+1} = 'Only one time step: no switching data available.';
    r.EventLog = EventLog;
    return
end

% Convert time choices (which are in minutes) to number of steps (as used
% below in the analysis)
% if r.t(2) ~= 60 % profile data not in 1 minutes steps?
    MinPerStep = r.t(2)/60;
    BinsSW = floor(BinsSW / MinPerStep);
    idx = find(BinsSW == 0);
    BinsSW = BinsSW(idx(end):end);
    BinsSWmin = BinsSW * MinPerStep;
% end

%% Compute switching information (iterating over individual components
% (columns))
swEvents = diff(S); % matrix with 0=no event, -1=turn off, +1=turn on
DataCount = 0; % counts devices that have full cycle of switching
for ii = 1:size(S,2)
    idx = find(swEvents(:,ii) ~= 0) + 1;
    if ~isempty(idx) & length(idx)>2
        DataCount = DataCount + 1;
        if swEvents(idx(1),ii) == 1
            % was initially off, turned on
            sw(ii).Tcyc = idx(3:2:end)-idx(1:2:end-2);
            sw(ii).Ton  = idx(2:2:end)-idx(1:2:end-1);
            sw(ii).Toff = idx(3:2:end)-idx(2:2:end-1);
        else
            % was initially on, turned off
            sw(ii).Tcyc = idx(3:2:end)-idx(1:2:end-2);
            sw(ii).Ton  = idx(3:2:end)-idx(2:2:end-1);
            sw(ii).Toff = idx(2:2:end)-idx(1:2:end-1);
        end
        if BinChoice == 1
            if max(BinsSW) <  max(sw(ii).Ton)
                sw(ii).Bon  = [BinsSW max(sw(ii).Ton)+1e-3];
            else
                sw(ii).Bon  = BinsSW;
            end
            if max(BinsSW) < max(sw(ii).Toff)
                sw(ii).Boff  = [BinsSW max(sw(ii).Toff)+1e-3];
            else
                sw(ii).Boff  = BinsSW;
            end
            if max(BinsSW) <  max(sw(ii).Tcyc)
                sw(ii).Bcyc  = [BinsSW max(sw(ii).Tcyc)+1e-3];
            else
                sw(ii).Bcyc  = BinsSW;
            end
        elseif BinChoice == 2
            if min(sw(ii).Ton) ~= max(sw(ii).Ton)
                sw(ii).Bon  = [0 round(logspace(log10(min(sw(ii).Ton)),log10(max(sw(ii).Ton)),10))+1e-3];
            else
                sw(ii).Bon  = round(min(sw(ii).Ton));
            end
            if min(sw(ii).Toff) ~= max(sw(ii).Toff)
                sw(ii).Boff = [0 round(logspace(log10(min(sw(ii).Toff)),log10(max(sw(ii).Toff)),10))+1e-3];
            else
                sw(ii).Boff  = round(min(sw(ii).Toff));
            end
            if min(sw(ii).Tcyc) ~= max(sw(ii).Tcyc)
                sw(ii).Bcyc  = [0 round(logspace(log10(min(sw(ii).Tcyc)),log10(max(sw(ii).Tcyc)),10))+1e-3];
            else
                sw(ii).Bcyc  = round(min(sw(ii).Tcyc));
            end
        else
            sw(ii).Bon   = Bins;
            sw(ii).Boff  = Bins;
            sw(ii).Bcyc  = Bins;
        end
        sw(ii).Hon  = histc(sw(ii).Ton,sw(ii).Bon);
        sw(ii).Hoff = histc(sw(ii).Toff,sw(ii).Boff);
        sw(ii).Hcyc = histc(sw(ii).Tcyc,sw(ii).Bcyc);
    else
        sw(ii).Tcyc = [];
        sw(ii).Ton  = [];
        sw(ii).Toff = [];
        sw(ii).Hon  = [];
        sw(ii).Hoff = [];
        sw(ii).Bon  = [];
        sw(ii).Boff = [];
        sw(ii).Tcyc = [];
        sw(ii).Bcyc = [];
    end
end


%% Histograms
figCount = 0;
rowCount = 0;
subFigs = min(subFigs,DataCount);
if binRate == 1
    BinTimeUnit = ', time unit: min';
else
    BinTimeUnit = ', time unit: day';
end
if plotFlag
    for ii = 1:size(S,2)
        if ~isempty(sw(ii).Tcyc)
            % only show if full cycle is detected
            rowCount = rowCount + 1;
            figCount = figCount + 1;
            % on-times (based on time steps)
            if ~subFlag
                sw(ii).hf = figure(fno+figCount-1);
                clf
            else
                if rowCount == subFigs
                    rowCount == 1;
                end
                if rowCount == 1
                    sw(ii).hf = figure(fno+ceil(figCount/subFigs/3)-1);
                    clf
                end
                if DataCount >= subFigs
                    sfpos = rem(figCount-1,3*subFigs) + 1;
                    subplot(subFigs,3,sfpos);
                else
                    sfpos = rem(figCount-1,3*DataCount) + 1;
                    subplot(DataCount,3,sfpos);
                end
            end
            h1 = bar((1:length(sw(ii).Hon)-1)-0.5,sw(ii).Hon(1:end-1),'barwidth',rWidth);
            if isempty(names)
                xlabel(['turn-ons' BinTimeUnit],'fontsize',fsText)
            else
                xlabel([names{ii} ': ' 'turn-ons' BinTimeUnit],'fontsize',fsText)
            end
            ylabel('Events')
            ylims = ylim;
            
            % 2nd version: using x-axis tick labels
            Astr{1} = '0';
            for jj = 2:length(sw(ii).Hon)
                if binRate == 1
                    Astr{jj} = ['<' num2str(sw(ii).Bon(jj)*MinPerStep,'%.0f')];
                else
                    Astr{jj} = ['<' num2str(sw(ii).Bon(jj)*MinPerStep/MinPerDay,'%.0f')];
                end
            end
            xlim([0 length(sw(ii).Hon)-1]);            
            set(gca,'xtick',[0:length(sw(ii).Hon)-1]);
            set(gca,'xticklabel',Astr);
            
            ylim([ylims(1) ylims(2)+diff(ylims)/15])
            set(gcf,'name',[names{ii} ' : On']);
            % off-times (based on time steps)
            figCount = figCount + 1;
            if ~subFlag
                sw(ii).hf = figure(fno+figCount-1);
            else
                if DataCount >= subFigs
                    sfpos = rem(figCount-1,3*subFigs) + 1;
                    subplot(subFigs,3,sfpos);
                else
                    sfpos = rem(figCount-1,3*DataCount) + 1;
                    subplot(DataCount,3,sfpos);
                end
            end
            %             clf
            h2 = bar((1:length(sw(ii).Hoff)-1)-0.5,sw(ii).Hoff(1:end-1),'barwidth',rWidth);
            if isempty(names)
                xlabel(['turn-offs' BinTimeUnit],'fontsize',fsText)
            else
                xlabel([names{ii} ': ' 'turn-offs' BinTimeUnit],'fontsize',fsText)
            end
            ylabel('Events')
            ylims = ylim;
			
            % 2nd version: using x-axis tick labels
            Astr{1} = '0';
            for jj = 2:length(sw(ii).Hoff)
                if binRate == 1
                    Astr{jj} = ['<' num2str(sw(ii).Boff(jj)*MinPerStep,'%.0f')];
                else
                    Astr{jj} = ['<' num2str(sw(ii).Boff(jj)*MinPerStep/MinPerDay,'%.0f')];
                end
            end
            xlim([0 length(sw(ii).Hoff)-1]);            
            set(gca,'xtick',[0:length(sw(ii).Hoff)-1]);
            set(gca,'xticklabel',Astr);
            ylim([ylims(1) ylims(2)+diff(ylims)/15])
            set(gcf,'name',[names{ii} ' : Off']);
            % cycle-times (based on time steps)
            figCount = figCount + 1;
            if ~subFlag
                sw(ii).hf = figure(fno+figCount-1);
            else
                if DataCount >= subFigs
                    sfpos = rem(figCount-1,3*subFigs) + 1;
                    subplot(subFigs,3,sfpos);
                else
                    sfpos = rem(figCount-1,3*DataCount) + 1;
                    subplot(DataCount,3,sfpos);
                end
            end
            %             clf
            h1 = bar((1:length(sw(ii).Hcyc)-1)-0.5,sw(ii).Hcyc(1:end-1),'barwidth',rWidth);
            if isempty(names)
                xlabel(['Cycles' ],'fontsize',fsText)
            else
                xlabel([names{ii} ': ' 'Cycles' BinTimeUnit],'fontsize',fsText)
            end
            ylabel('Events')
            ylims = ylim;

            % 2nd version: using x-axis tick labels
            Astr{1} = '0';
            for jj = 2:length(sw(ii).Hcyc)
                if binRate == 1
                    Astr{jj} = ['<' num2str(sw(ii).Bcyc(jj)*MinPerStep,'%.0f')];
                else
                    Astr{jj} = ['<' num2str(sw(ii).Bcyc(jj)*MinPerStep/MinPerDay,'%.0f')];
                end
            end
            xlim([0 length(sw(ii).Hcyc)-1]);            
            set(gca,'xtick',[0:length(sw(ii).Hcyc)-1]);
            set(gca,'xticklabel',Astr);
            ylim([ylims(1) ylims(2)+diff(ylims)/15])
            set(gcf,'name',[names{ii} ' : Cycle']);
        else
            sw(ii).hf = [];
        end
    end
end

%% Return structure
r.IA.sw = sw;

% Event log update
EventLog{end+1} = 'Switching histogram(s). Done.';
r.EventLog = EventLog;
