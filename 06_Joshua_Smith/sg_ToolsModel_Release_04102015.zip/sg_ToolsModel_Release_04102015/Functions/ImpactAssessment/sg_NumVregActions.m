function r = sg_NumVregActions(varargin)
% Function to calculate number of switching actions.
% function r = sg_NumVregActions(r)
%
% This function calculates the number of operations for each voltage
% controllable device (capacitor banks and transformers) over the entire
% simulation period.
%
% Input: r		... data structure with power flow/time series results.
%		'fno'	... figure number (to start with)
%       'daily'	... show switching operations per day (default 0)
%
% Output:   r.	... data (results) structure
%           .VRegOp.CapOp.names  	... cell array of capacitor names
%           .VRegOp.CapOp.val    	... vector of sum of switching actions
%           .VRegOp.CapOp.total  	... sum of switching actions
%           .VRegOp.XFMROp.names 	... cell array of transformer names
%           .VRegOp.XFMROp.val   	... vector of sum of switching actions
%           .VRegOp.XFMROp.total  	... sum of switching actions
%
% Example Call(s):
%		r = sg_NumVregActions(r,'daily',1);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%% Setup/Defaults
DispFlag = 0;     % command-line display flag
EventLog = {};    % event information

fno  = 99;       % (starting) figure number
opts = struct('fno',fno,'daily',0,'Tinit',0);
opts = sg_updateOpts(opts,varargin,1);

r = varargin{1};

iuse=find(r.t>=opts.Tinit);

%% Calculating Capacitor switching operations
if ~isempty(r.Capacitor.names)
    r.VRegOp.CapOp.names = r.Capacitor.names;
    r.VRegOp.CapOp.val   = sum(abs(diff(r.Capacitor.State.val(iuse,:))));
else
    txt = sprintf('Switching operations: No capacitor bank found.');
    EventLog{end+1} = txt;
    if DispFlag
        fprintf(' %s\n',txt);
    end
    r.VRegOp.CapOp.names = {};
    r.VRegOp.CapOp.val   = [];
end
r.VRegOp.CapOp.total = sum(r.VRegOp.CapOp.val);

%% Calculating Tap changer transformer switching operations
if ~isempty(r.RegControl.names)
    r.VRegOp.XFMROp.names = r.RegControl.names;
    r.VRegOp.XFMROp.val   = sum(diff(r.RegControl.TapNum.val(iuse,:))~=0);
else
    txt = sprintf('Switching operations: No SVR found.');
    EventLog{end+1} = txt;
    if DispFlag
        fprintf(' %s\n',txt);
    end
    r.VRegOp.XFMROp.names = {};
    r.VRegOp.XFMROp.val   = [];
end
r.VRegOp.XFMROp.total = sum(r.VRegOp.XFMROp.val);

r.EventLog = EventLog;

%% figure
if opts.fno > 0
    varc=[ {r.VRegOp.CapOp.val} ; {r.VRegOp.XFMROp.val} ];
    varcn = max(cellfun(@length,varc));
    f = @(x) (sg_VarContributions1_zeropad(x,varcn));
    varc = cellfun(f,varc,'UniformOutput',false);
    varcx = cat(1,varc{:});
    if opts.daily
        varcx = varcx / ((r.t(end)-r.t(1)) /60/60/24);
    end
    if ~isempty(varcx)
        figure(opts.fno)
        bar(varcx);
        set(gca,'XTickLabel',{'Capacitor Banks','Step Voltage Regulator'});
        set(gcf,'name','Number of switching operations')
        if opts.daily
            ylabel('Number of switching operations/day')
        else
            ylabel('Number of switching operations')
        end
    end
end

% Event log update
EventLog{end+1} = 'Switching operations plot. Done.';
r.EventLog = EventLog;
end


function r = sg_VarContributions1_zeropad(x,N)
Nadd=N-length(x);
Npre=round(Nadd/2);
Npost=Nadd-Npre;
r=[zeros(1,Npre) x zeros(1,Npost)];
end


