function r = sg_PlotSwCapacitors(varargin)
% Plots switching event of capacitors vs. time.
% function r = sg_PlotSwCapacitors(varargin)
%
% Plots capacitor state information (vs. time): individually, number of
% capacitors turned-on, and cumulative turn-on count for each capacitor.
%
% Inputs:  r.         ... results data structure
%          'fno'      ... figure number (default: 30), plots if fno > 0
%
% Outputs: r.         ... data (results) structure
%           .Capacitor.SwCount ... individual turn-on counts
%           .EventLog ... string array with event messages
%
% Example Call(s):
%      r = sg_PlotSwCapacitors('data',r);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%% Defaults
fno      = 30;   % figure number used
DispFlag = 0;    % command line display flag (0/1), default: off
lWidth   = 2;    % line width in plots
daySec   = 60*60*24; % seconds/day
EventLog = {};   % event information
r.status   = 0;  % success status (0/1)

%% Handle options
if ~isempty(varargin)
    if isstruct(varargin{1})
        r = varargin{1};
        ArgIdx = 2;
    else
        ArgIdx = 1;
    end
    for ii = ArgIdx:2:length(varargin)
        switch varargin{ii}
            case {'data','d'}
                r = varargin{ii+1};
            case 'subplot'
                subFlag = varargin{ii+1};
            case 'fno'
                fno = varargin{ii+1};
            otherwise
                fprintf(' Unknown option: %s\n',varargin{ii});
        end
    end
else
    if DispFlag
        fprintf('\n Need at least results structure as input.\n');
    end
    EventLog{end+1} = 'Error: No input data to sg_PlotSwCapacitors().';
    r.EventLog = EventLog;
    return
end

%% Names
names  = r.Capacitor.names;
NoCaps = length(names);
for ii = 1:NoCaps
    names{ii} = names{ii}(11:end);
end

if NoCaps == 0
    r.EventLog{end+1} = 'No capacitors found--no capacitor states data.';
    return
end

%% Count turn-on events for each capacitor
SwEvents = diff(r.Capacitor.State.val);
r.Capacitor.SwCount  = zeros(size(r.Capacitor.State.val));
for ii = 1:size(SwEvents,1)
    TurnOn = (SwEvents(ii,:) > 0);
    r.Capacitor.SwCount(ii+1,:) = r.Capacitor.SwCount(ii,:) + TurnOn;
end

%% Figure(s)
if fno > 0
    % individual states
    figure(fno);
    clf
    plot(r.t/daySec,0.9*r.Capacitor.State.val+ones(r.n,1)*[1:NoCaps],'linewidth',lWidth);
    grid on
    ylabel('Capacitor state(s)');
    xlabel('time (days)');
    ylim([0.9 NoCaps+1])
    set(gca,'ytick',[1:NoCaps]);
    set(gcf,'name',['Capacitor states vs. time']);
    legend(names,'location','bestoutside')
    
    % number of caps. turned-on
    fno = fno + 1;
    figure(fno);
    clf
    plot(r.t/daySec,sum(r.Capacitor.State.val,2),'linewidth',lWidth);
    grid on
    ylim([0 NoCaps])
    ylabel('No. of capacitor on');
    xlabel('time (days)');
    set(gcf,'name',['No. capacitors on vs. time']);
    set(gca,'ytick',[0:NoCaps]);
    
    % cumulative turn-on count
    fno = fno + 1;
    figure(fno);
    clf
    plot(r.t/daySec,r.Capacitor.SwCount,'linewidth',lWidth);
    grid on
    ylabel('turn-on count');
    xlabel('time (days)');
    set(gcf,'name',['Capacitor turn-on count vs. time']);
    legend(names,'location','best');
    
    % exit message
    EventLog{end+1} = 'Capacitor state(s) plot. Done.';
    r.EventLog = EventLog;
else
    EventLog{end+1} = 'Note: No capacitor in model.';
    r.EventLog = EventLog;
end

r.status   = 1;
