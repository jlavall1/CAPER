function varargout = sg_DispatchFct(varargin)
% Function Dispatcher (for executable version)
% function varargout = sg_DispatchFct(varargin)
%
% Inputs: 'FctName','fn'	... Function to be dispatched (default: sg_gui)
%    	'FctParameter','fp' ... List of function arguments (cell array)
%    							NOTE: If this function is called from the
%                            	Windows command line (i.e., the executable),
%                            	the parameter pair lists needs to be entered
%                            	as one (long) string, and double-quotes be
%                            	used to designate strings. Furthermore, the
%                            	double-quote needs to be escaped with a
%                            	backslash: \".  Example for Win-64bit:
%                            	sg_DERtool_64bit fn feeder fp \�fname\�,\�Result.mat\�
%	    'FctArguments','fa' ... results data structure                    
%    
% Outputs: (depends on function called)
% 		Supported functions:
%			sg_gui()                      ...
%   		sg_runModel()                 ...
%   		sg_plotMaxMinVoltageProfile() ...
%   		sg_plotFeeder()               ...
%   		sg_plotvoltageprofile         ...
%
% Example Call(s):
%	 	
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%% Default setup and handling of options
EventLog  = {};   % keeps track of warning/error messages (cell array)
DispFlag  = 0;    % turn on/off console display (0/1)
varargout = {};
FctName   = 'sg_gui';
FctArgs   = [];  % used for data structure
FctPara   = {};  % used for options (handled as strings in the calls to the excutable/dispatcher)
FctHandle = [];

%% Handle options
for ii = 1:2:length(varargin)
    switch lower(varargin{ii})
        case {'fctname','fn'}
            FctName = varargin{ii+1};
        case {'fctarguments','fa'}
            FctArgs = varargin{ii+1};
        case {'fctparam','fp'}
            FctPara = varargin{ii+1};
    end
end

%% Create function handle and call
switch lower(FctName)
    case {'sg_gui','gui'}
        % open GUI
        if isempty(FctArgs)
            FctHandle = @() sg_gui();
        else
            % no arguments
            FctString = ['@() sg_gui()'];
            FctHandle = eval(FctString);
        end
        r = FctHandle();
    case {'sg_runmodel','run'}
        % power flow/time series computations
        if isempty(FctArgs) & isempty(FctPara)
            FctHandle = @() sg_runModel();
        elseif isempty(FctPara)
            % Argument is a data structure
            FctString = ['@() sg_runModel(FctArgs)'];
            FctHandle = eval(FctString);
        elseif isempty(FctArgs)
            % Parameters is a string with option choices
            FctString = ['@() sg_runModel(' FctPara ')'];
            FctString = strrep(FctString,'"','''');
            FctHandle = eval(FctString);
        else
            % Both
            FctString = ['@() sg_runModel(FctArgs,' FctPara ')'];
            FctString = strrep(FctString,'"','''');
            FctHandle = eval(FctString);
        end
        r = FctHandle();
    case {'sg_plotmaxminvoltageprofile','mmv'}    
        % extreme voltage profiles experienced
        if isempty(FctArgs) & isempty(FctPara)
            FctHandle = @() sg_plotMaxMinVoltageProfile();
        elseif isempty(FctPara)
            % Argument is a data structure
            FctString = ['@() sg_plotMaxMinVoltageProfile(FctArgs)'];
            FctHandle = eval(FctString);
        elseif isempty(FctArgs)
            % Parameters is a string with option choices
            FctString = ['@() sg_plotMaxMinVoltageProfile(' FctPara ')'];
            FctString = strrep(FctString,'"','''');
            FctHandle = eval(FctString);
        else
            % Both
            FctString = ['@() sg_plotMaxMinVoltageProfile(FctArgs,' FctPara ')'];
            FctString = strrep(FctString,'"','''');
            FctHandle = eval(FctString);
        end
        [y,r] = FctHandle();
    case {'sg_plotvoltageprofile','vp'}    
        % extreme voltage profiles experienced
        if isempty(FctArgs) & isempty(FctPara)
            FctHandle = @() sg_plotVoltageProfile();
        elseif isempty(FctPara)
            % % Argument is a data structure
            FctString = ['@() sg_plotVoltageProfile(FctArgs)'];
            FctHandle = eval(FctString);
        elseif isempty(FctArgs)
            % Parameters is a string with option choices
            FctString = ['@() sg_plotVoltageProfile(' FctPara ')'];
            FctString = strrep(FctString,'"','''');
            FctHandle = eval(FctString);
        else
            % Both
            FctString = ['@() sg_plotVoltageProfile(FctArgs,' FctPara ')'];
            FctString = strrep(FctString,'"','''');
            FctHandle = eval(FctString);
        end
        [y,r] = FctHandle();
    case {'sg_plotFeeder','feeder'}
        % feeder structure and status (at first point in time)
        if isempty(FctArgs) & isempty(FctPara)
            FctHandle = @() sg_plotFeeder();
        elseif isempty(FctPara)
            % Argument is a data structure
            FctString = ['@() sg_plotFeeder(FctArgs)'];
            FctHandle = eval(FctString);
        elseif isempty(FctArgs)
            % Parameters is a string with option choices
            FctString = ['@() sg_plotFeeder(' FctPara ')'];
            FctString = strrep(FctString,'"','''');
            FctHandle = eval(FctString);
        else
            % Both
            FctString = ['@(r) sg_plotFeeder(FctArgs,' FctPara ')'];
            FctString = strrep(FctString,'"','''');
            FctHandle = eval(FctString);
        end
        [y,r] = FctHandle();
    otherwise
        if DispFlag
            fprintf(' Unknown option: %s\n',varargin{ii});
        end
        EventLog{end+1} = sprintf('Error: sg_DispatchFct: Unknown option %s',varargin{ii});
end
if isfield(r,'EventLog')
    if isempty(r.EventLog)
        r.EventLog = EventLog;
    else
        r.EventLog = [r.EventLog EventLog];
    end
end
varargout{1} = r;
