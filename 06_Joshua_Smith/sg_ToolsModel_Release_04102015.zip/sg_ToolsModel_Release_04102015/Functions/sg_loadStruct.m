function y=sg_loadStruct(filename)

y=struct();

fid=fopen(filename);
try
    while 1
        str1=fgetl(fid);
        if(~ischar(str1)) break; end
        str2 = sprintf('y.%s',str1);
        eval(str2);
    end
end

fclose(fid);