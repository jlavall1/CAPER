function [xf,b,a]=sg_qfilt(varargin)
% Quick Filter
% function [xf,b]=qfilt(t,x,fc)
%
%
%
% Inputs: 	t	... time array
%			x 	... array of values to be filtered
%			fc  ... cutoff frequency (Hz)
%
% Outputs: 	xf 		... filtered values
%			[b,a]	... 
%
% Example Call(s):
%		[xf,b,a] = sg_qfilt(t,x,100);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%%
t=varargin{1};
x=varargin{2};
fc=varargin{3};

opts=struct('n',1);
opts=sg_updateOpts(opts,varargin,3);


fs=1/(t(2)-t(1));

fn=fs/2;

wn=fc/fn;

[b,a]=butter(opts.n,wn);
xf=filter(b,a,x-mean(x))+mean(x);