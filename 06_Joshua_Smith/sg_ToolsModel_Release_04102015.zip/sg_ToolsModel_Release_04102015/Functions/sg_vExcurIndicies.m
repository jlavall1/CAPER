% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
function [vExcur,iBus_Load] = sg_vExcurIndicies(varargin)

r = varargin{1};

opts=struct('limits',[0.95 1.05]);
opts=sg_updateOpts(opts,varargin,1);

vLow = opts.limits(1);
vHigh = opts.limits(2);

vBus = r.Bus.Vpu.val;
vBusN = r.Bus.Vpu.names;
loadN = r.Load.names;

%find total instances of voltage excursion per bus
vExcur={};
for(n=1:size(vBus,2))
    vExcur{n} = find(vBus(:,n) > vHigh | vBus(:,n) < vLow);
end

%find bus indices in which excursions occur
iExcur = find(~cellfun('isempty',vExcur));

%find load which relates to vBusN(iExcur)
iBusLoad=[];
l=1;
if(~isempty(iExcur))
    for(n=1:length(iExcur))
        bNam = vBusN{iExcur(n)}(1:7);
        i1 = find(~cellfun('isempty',regexp(loadN,bNam)));
        if(~isempty(i1))
            iBus_Load(l,1)=iExcur(n);
            iBus_Load(l,2)=i1;
            l=l+1;
        end
    end
else
    iBus_Load=0;
end
