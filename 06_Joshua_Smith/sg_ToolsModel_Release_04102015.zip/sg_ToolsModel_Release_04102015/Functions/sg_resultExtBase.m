function y = sg_resultExtBase(varargin)
% Base function for results extraction from OpenDSS simulations (local structure).
% function y = sg_resultExtBase(DSSObj,y,N)
%
% Data extraction (after every power flow solution step).
%
% Inputs: DSSObj		... OpenDSS COM interface connection.
%    	  	y			... the structure of results being updated 
%         					(can be an arbitrary scalar on the first call 
%							to the function.)						
%    	  	N			... the total number of runs to be executed 
%							(used to allocate storage).
%    	'BusExpr'		... a string containing a regular expression pattern 
%      						to use to filter bus names to be included in the 
%      						results structure (default = '.*', indicating that 
%							all buses should be included).
%    	'LineExpr'		... a string containing a regular expression pattern 
%      						to use to filter line names to be included in the 
%      						results structure (default = '.*', indicating that 
%							all lines should be included).
%   'LineMeasPoint'		... an integer indicating the end of the line at which to
%      						measure power flow (default = 1, indicating the sending end).
%   'GeneratorExpr' 	...	a string containing a regular expression pattern 
%      						to use to filter generator names to be included in 
%      						the results structure (default = '.*', indicating 
%							that all generators should be included).
%   'TransformerExpr'	... a string containing a regular expression pattern 
%      						to use to filter transformer names to be included in 
%      						the results structure(default = '.*', indicating that all 
%							transformers should be included).
%'TransformerMeasPoint'	... an integer indicating the windings at which to
%      						measure power flow (default = 1).
%    	'LoadExpr' 		...	a string containing a regular expression pattern to use to
%      						filter load names to be included in the results structure
%      						(default = '.*', indicating that all loads should be included).
%    'CapacitorExpr' 	... a string containing a regular expression pattern to use to
%      						filter capacitor names to be included in the results structure
%      						(default = '.*', indicating that all capacitors should be included).
%    'RegControlExpr' 	... a string containing a regular expression pattern to use to
%      						filter voltage regulator control names to be included in the 
%      						results structure (default = '.*', indicating that all voltage 
%							regulator controls should be included).
%
% Outputs: y.		... data (results) structure
%
%
% Example Call(s):
%		r = 
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%%
DSSObj = varargin{1};
y = varargin{2};
N = varargin{3};

opts = struct('BusExpr','.*','LineExpr','.*','LineMeasPoint',1,'GeneratorExpr','.*',...
    'TransformerExpr','.*','TransformerMeasPoint',1,'LoadExpr','.*',...
    'CapacitorExpr','.*','RegControlExpr','.*','Vmag',1);
opts = sg_updateOpts(opts,varargin,3);

DSSCircuit  =  DSSObj.ActiveCircuit;

% parameters
Qeps = 1e-3; % reactive power level for capacitor status (kVAr)

% if(isstruct(y)==0)
if isempty(y)
    y = struct();
    
    % Run number.
    y.n = 0;
    
    %  Bus voltage values.
    y.Bus = struct();
    y.Bus.V1 = struct();
    y.Bus.V2 = struct();
    y.Bus.V3 = struct();
    
    % Substation bus name (assuming default name)
    y.Bus.SubStation.name = DSSCircuit.CktElements('Vsource.source').BusNames{1};
    
    % system-wide data
    y.sys.Losses     = zeros(N,2); % DSSCircuit.Losses;
    y.sys.LineLosses = zeros(N,2); % DSSCircuit.LineLosses;
    y.sys.NumCktElements = DSSCircuit.NumCktElements;
    y.sys.NumBuses   = DSSCircuit.NumBuses;
    y.sys.NumNodes   = DSSCircuit.NumNodes;
    
    xx = DSSCircuit.AllNodeDistances;
    
    nodev = DSSCircuit.AllNodeNames;
    y.Bus.AllNodeNames = nodev;
    y.Bus.AllNodeNames1 = DSSCircuit.AllNodeNamesByPhase(1);
    y.Bus.AllNodeNames2 = DSSCircuit.AllNodeNamesByPhase(2);
    y.Bus.AllNodeNames3 = DSSCircuit.AllNodeNamesByPhase(3);
    y.Bus.AllBusNames = DSSCircuit.AllBusNames;
    y.Bus.AllBusDistances = DSSCircuit.AllBusDistances;
    y.Bus.xy = zeros(length(y.Bus.AllBusNames),2);
    for ii = 1:length(y.Bus.AllBusNames)
        y.Bus.xy(ii,:) = [DSSCircuit.Buses(y.Bus.AllBusNames{ii}).x DSSCircuit.Buses(y.Bus.AllBusNames{ii}).get('y')];
    end
    % Check for 0/0 coordinates and fix because 0/0 means no xy-data was
    % provided for a bus
    idx = find(y.Bus.xy(:,1) == 0 & y.Bus.xy(:,2) == 0);
    if length(idx)==1 && length(idx)==1
        % one execption: fix to small value
        y.Bus.xy(idx,[1 2]) = [1e-6 1e-6];
    end
    idx = find(y.Bus.xy(:,1) == 0 & y.Bus.xy(:,2) ~= 0);
    if ~isempty(idx)
        % one of the two coordinates is zero
        y.Bus.xy(idx,[1 2]) = y.Bus.xy(idx,[1 2])+1e-6;
    end
    idx = find(y.Bus.xy(:,1) ~= 0 & y.Bus.xy(:,2) == 0);
    if ~isempty(idx)
        % one of the two coordinates is zero
        y.Bus.xy(idx,[1 2]) = y.Bus.xy(idx,[1 2])+1e-6;
    end
    
    i0 = sg_rgrep(opts.BusExpr,nodev);
       
    i0ph1 = sg_rgrep(opts.BusExpr,y.Bus.AllNodeNames1);
    i0ph2 = sg_rgrep(opts.BusExpr,y.Bus.AllNodeNames2);
    i0ph3 = sg_rgrep(opts.BusExpr,y.Bus.AllNodeNames3);
    
    i1 = sg_rgrep('.+\.1$',nodev(i0));
    i1ph1 = sg_rgrep('.+\.1$',y.Bus.AllNodeNames1(i0ph1));
    i1ph2 = sg_rgrep('.+\.2$',y.Bus.AllNodeNames2(i0ph2));
    i1ph3 = sg_rgrep('.+\.3$',y.Bus.AllNodeNames3(i0ph3));
    
    y.Bus.V1.index = i0(i1);
    y.Bus.V1pu.index = i0ph1(i1ph1);
    y.Bus.V1.names = nodev(y.Bus.V1.index);
    y.Bus.V1.val = zeros(N,length(y.Bus.V1.index));
    y.Bus.V1.distance = xx(y.Bus.V1.index);
    %y.Bus.V1pu.val = zeros(N,length(y.Bus.V1.index));
    y.Bus.V1pu.val = zeros(N,length(y.Bus.V1pu.index));
    
    i1 = sg_rgrep('.+\.2$',nodev(i0));
    y.Bus.V2.index = i0(i1);
    y.Bus.V2pu.index = i0ph2(i1ph2);
    y.Bus.V2.names = nodev(y.Bus.V2.index);
    y.Bus.V2.val = zeros(N,length(y.Bus.V2.index));
    y.Bus.V2.distance = xx(y.Bus.V2.index);
    %y.Bus.V2pu.val = zeros(N,length(y.Bus.V2.index));
    y.Bus.V2pu.val = zeros(N,length(y.Bus.V2pu.index));
    
    i1 = sg_rgrep('.+\.3$',nodev(i0));
    y.Bus.V3.index = i0(i1);
    y.Bus.V3pu.index = i0ph3(i1ph3);
    y.Bus.V3.names = nodev(y.Bus.V3.index);
    y.Bus.V3.val = zeros(N,length(y.Bus.V3.index));
    y.Bus.V3.distance = xx(y.Bus.V3.index);
    %y.Bus.V3pu.val = zeros(N,length(y.Bus.V3.index));
    y.Bus.V3pu.val = zeros(N,length(y.Bus.V3pu.index));
    
    y.Bus.distance = xx;
    
    if(opts.Vmag==1)
        y.Bus.Vpu = struct();
        y.Bus.Vpu.names = nodev(i0);
        y.Bus.Vpu.val = zeros(N,length(i0));
        y.Bus.Vpu.index = i0;
        y.Bus.Vpu.distance = xx(y.Bus.Vpu.index);
        y.Bus.Vpu.VbkV = 1e-3*DSSCircuit.AllBusVmag(y.Bus.Vpu.index)./DSSCircuit.AllBusVmagPu(y.Bus.Vpu.index);
    end
    
    %  Line power values.
    y.Line = struct();
    linev = DSSCircuit.Lines.AllNames;
    i0 = sg_rgrep(opts.LineExpr,linev);
    y.Line.S1.names = linev(i0);
    y.Line.S1.index = i0;
    y.Line.S1.val = zeros(N,length(i0));
    y.Line.S1.incl = zeros(1,length(i0));
    y.Line.I1.val = zeros(size(y.Line.S1.val));
    y.Line.V11.val = zeros(size(y.Line.S1.val));
    y.Line.V12.val = zeros(size(y.Line.S1.val));
    y.Line.kVbase = zeros(1,length(i0));
    y.Line.lengths = zeros(1,length(i0));
    y.Line.Distance1 = zeros(2,length(i0));
    y.Line.Distance2 = zeros(2,length(i0));
    y.Line.LVflag   = zeros(1,length(i0));
    
    y.Line.S2.names = linev(i0);
    y.Line.S2.index = i0;
    y.Line.S2.val = zeros(N,length(i0));
    y.Line.S2.incl = zeros(1,length(i0));
    y.Line.I2.val = zeros(size(y.Line.S2.val));
    y.Line.V21.val = zeros(size(y.Line.S2.val));
    y.Line.V22.val = zeros(size(y.Line.S2.val));
    
    y.Line.S3.names = linev(i0);
    y.Line.S3.index = i0;
    y.Line.S3.val = zeros(N,length(i0));
    y.Line.S3.incl = zeros(1,length(i0));
    y.Line.I3.val = zeros(size(y.Line.S3.val));
    y.Line.V31.val = zeros(size(y.Line.S3.val));
    y.Line.V32.val = zeros(size(y.Line.S3.val));
    
    for n = 1:length(y.Line.S1.names)
        x = DSSCircuit.CktElements(['Line.' y.Line.S1.names{n}]);
        if x.Enabled
            xx = x.get('NodeOrder');
            Nxx = length(xx);
            if(opts.LineMeasPoint==1)
                xx((Nxx/2+1):end) = zeros(1,Nxx/2);
            else
                xx(1:(Nxx/2)) = zeros(1,Nxx/2);
            end
            %  xx = xx(1:(length(xx)/2));
            % note: checking for connections is not general to work for all
            % possibilities: covers default line and single-phase
            % connections
            i1 = find(xx==1 | xx==5);
            if ~isempty(i1)
                y.Line.S1.incl(n) = i1;
            end
            i1 = find(xx==2 | xx==6);
            if ~isempty(i1)
                y.Line.S2.incl(n) = i1;
            end
            i1 = find(xx==3 | xx==7);
            if ~isempty(i1)
                y.Line.S3.incl(n)=i1;
            end
            % determine base kV for line
            bn = x.BusNames{1};
            idx = strfind(bn,'.');
            if ~isempty(idx)
                bn = bn(1:idx(1)-1);
            end
            y.Line.kVbase(n) = DSSObj.ActiveCircuit.Buses(bn).kVBase;
            bn2 = x.BusNames{2};
            idx = strfind(bn2,'.');
            if ~isempty(idx)
                bn2 = bn2(1:idx(1)-1);
            end
            
            % distances and Low Voltage flag
            abus = DSSCircuit.Buses(bn);
            y.Line.LVflag(n) = abus.kVBase < 1;
            y.Line.Distance(1,n) = abus.Distance;
            abus = DSSCircuit.Buses(bn2);
            y.Line.LVflag(n) = y.Line.LVflag(n) || abus.kVBase < 1;
            y.Line.Distance(2,n) = abus.Distance;
            
            switch lower(x.Properties('units').val)
                case {'none','mi'}
                    u2mi = 1;
                case {'km'}
                    u2mi = 1/1.609344;
                case {'m'}
                    u2mi = 1/1609.344;
                case {'kft'}
                    u2mi = 1/5.280;
                case {'ft'}
                    u2mi = 1/5280;
                case {'in'}
                    u2mi = 1/63360;
                case {'cm'}
                    u2mi = 1/160934.4;
                otherwise
                    % should never happen
                    u2mi = 1;
            end
            y.Line.lengths(n) = str2num(x.Properties('length').val) * u2mi;
        else
            % disabled lines cause memory access violations
        end
    end
    
    % Line section indices for voltage profiles
    DSSlines = DSSCircuit.Lines;
    flag = DSSlines.first;
    y.Line.buslist = [];
    y.Line.busidx  = [];
    lineidx = 1;
    while flag
        y.Line.buslist = [y.Line.buslist; {DSSlines.Bus1} {DSSlines.Bus2}];
        % remove nodes from names in buslist
        idx1 = strfind(y.Line.buslist{end,1},'.');
        idx2 = strfind(y.Line.buslist{end,2},'.');
        if ~isempty(idx1)
            y.Line.buslist{end,1} = y.Line.buslist{end,1}(1:idx1(1)-1);
        end
        if ~isempty(idx2)
            y.Line.buslist{end,2} = y.Line.buslist{end,2}(1:idx2(1)-1);
        end
            
        lvflag = 0;
        for ii = 1:length(y.Bus.AllBusNames)
            idx1 = strcmp(y.Bus.AllBusNames{ii},y.Line.buslist{end,1});
            idx2 = strcmp(y.Bus.AllBusNames{ii},y.Line.buslist{end,2});
            if idx1
                y.Line.busidx(lineidx,1) = ii;
                %abus = DSSCircuit.Buses(DSSlines.Bus1);
                abus = DSSCircuit.Buses(y.Line.buslist{end,1});
                lvflag = lvflag | abus.kVBase < 1;
            end
            if idx2
                y.Line.busidx(lineidx,2) = ii;
                %abus = DSSCircuit.Buses(DSSlines.Bus2);
                abus = DSSCircuit.Buses(y.Line.buslist{end,2});
                lvflag = lvflag | abus.kVBase < 1;
            end
        end
        y.Line.busidx(lineidx,3) = lvflag;
        y.Line.busidx(lineidx,4) = abus.kVBase;
        flag = DSSlines.Next;
        lineidx = lineidx + 1;
    end
    
    %  Generator power values.
    y.Generator = struct();
    genv = DSSCircuit.Generators.AllNames;
    if ~strcmpi(genv{1},'none')
        i0 = sg_rgrep(opts.GeneratorExpr,genv);
    else
        i0 = [];
    end
    y.Generator.S1.names = genv(i0);
    y.Generator.S1.index = i0;
    y.Generator.S1.val = zeros(N,length(i0));
    y.Generator.S1.incl = zeros(1,length(i0));
    y.Generator.I1.val = zeros(size(y.Generator.S1.val));
    
    y.Generator.S2.names = genv(i0);
    y.Generator.S2.index = i0;
    y.Generator.S2.val = zeros(N,length(i0));
    y.Generator.S2.incl = zeros(1,length(i0));
    y.Generator.I2.val = zeros(size(y.Generator.S2.val));
    
    y.Generator.S3.names = genv(i0);
    y.Generator.S3.index = i0;
    y.Generator.S3.val = zeros(N,length(i0));
    y.Generator.S3.incl = zeros(1,length(i0));
    y.Generator.I3.val = zeros(size(y.Generator.S3.val));
    
    for n = 1:length(y.Generator.S1.names)
        x = DSSCircuit.CktElements(['Generator.' y.Generator.S1.names{n}]);
        xx = x.get('NodeOrder');
        i1 = find(xx==1);
        if ~isempty(i1)
            y.Generator.S1.incl(n) = i1;
        end
        i1=find(xx==2);
        if ~isempty(i1)
            y.Generator.S2.incl(n) = i1;
        end
        i1 = find(xx==3);
        if ~isempty(i1)
            y.Generator.S3.incl(n) = i1;
        end
        y.Generator.BusNames(n) = DSSObj.ActiveCircuit.CktElements(['Generator.' y.Generator.S1.names{n}]).BusNames;
    end
    
    %  Transformer information.
    y.Transformer = struct();
    tranv = DSSCircuit.Transformers.AllNames;
    if ~strcmpi(tranv{1},'none')
        i0 = sg_rgrep(opts.TransformerExpr,tranv);
    else
        i0 = [];
    end  
    y.Transformer.names = tranv(i0);
    y.Transformer.S1.names = tranv(i0);
    y.Transformer.S1.index = i0;
    y.Transformer.S1.val = zeros(N,length(i0));
    y.Transformer.S1.incl = zeros(1,length(i0));
    y.Transformer.I1.val = zeros(size(y.Transformer.S1.val));
    y.Transformer.V11.val = zeros(size(y.Transformer.S1.val));
    y.Transformer.V12.val = zeros(size(y.Transformer.S1.val));
    y.Transformer.kVbase = zeros(2,length(i0));
    y.Transformer.LVflag = zeros(1,length(i0));
    y.Transformer.Distance = zeros(1,length(i0));
    y.Transformer.x1.val = zeros(1,length(i0));
    
    y.Transformer.S2.names = tranv(i0);
    y.Transformer.S2.index = i0;
    y.Transformer.S2.val = zeros(N,length(i0));
    y.Transformer.S2.incl = zeros(1,length(i0));
    y.Transformer.I2.val = zeros(size(y.Transformer.S2.val));
    y.Transformer.V21.val = zeros(size(y.Transformer.S2.val));
    y.Transformer.V22.val = zeros(size(y.Transformer.S2.val));
    y.Transformer.x2.val = zeros(1,length(i0));
    
    y.Transformer.S3.names = tranv(i0);
    y.Transformer.S3.index = i0;
    y.Transformer.S3.val = zeros(N,length(i0));
    y.Transformer.S3.incl = zeros(1,length(i0));
    y.Transformer.I3.val = zeros(size(y.Transformer.S3.val));
    y.Transformer.V31.val = zeros(size(y.Transformer.S3.val));
    y.Transformer.V32.val = zeros(size(y.Transformer.S3.val));
    y.Transformer.x3.val = zeros(1,length(i0));
    
    for n = 1:length(y.Transformer.S1.names)
        x = DSSCircuit.CktElements(['Transformer.' y.Transformer.S1.names{n}]);
        xx = x.get('NodeOrder');
        Nxx = length(xx);
        if(opts.TransformerMeasPoint==1)
            xx((Nxx/2+1):end) = zeros(1,Nxx/2);
        else
            xx(1:(Nxx/2)) = zeros(1,Nxx/2);
        end
        i1 = find(xx==1 | xx==5);
        if ~isempty(i1)
            y.Transformer.S1.incl(n) = i1(1); % first Phase-A
        end
        i1 = find(xx==2 | xx==6);
        if ~isempty(i1)
            y.Transformer.S2.incl(n) = i1(1);
        end
        i1 = find(xx==3 | xx==7);
        if ~isempty(i1)
            y.Transformer.S3.incl(n) = i1(1);
        end
        
        % distances and Low Voltage flag
        BusNames = x.BusNames;
        y.Transformer.LVflag(n) = 0;
        for ii = 1:length(BusNames)
            idx = strfind(BusNames{ii},'.');
            if ~isempty(idx)
                BusNames{ii} = BusNames{ii}(1:idx(1)-1);
            end
            abus = DSSCircuit.Buses(BusNames{ii});
            y.Transformer.LVflag(n) = y.Transformer.LVflag(n) || abus.kVBase < 1;
        end
        y.Transformer.Distance(n) = abus.Distance;
    end
    
    y.Transformer.Tap = struct();
    y.Transformer.Tap.names = tranv(i0);
    y.Transformer.Tap.val = zeros(N,length(i0));
    
    % Transformer indices for voltage profile
    flag = DSSCircuit.FirstPDElement;
    y.Transformer.buslist1 = {};
    y.Transformer.busidx1  = [];
    transidx  = 0;
    transidx1 = 0;
    transidx2 = 0;
    transidx3 = 0;
    while flag
        aElem = DSSCircuit.ActiveElement;
        if strfind(aElem.get('Name'),'Transformer.')
            transidx = transidx + 1;
            bnames = aElem.get('BusNames');
            for ii=1:length(bnames)
                idx = strfind(bnames{ii},'.');
                if ~isempty(idx)
                    bnames{ii} = bnames{ii}(1:idx(1)-1);
                end
            end
            % phase 1
            y.Transformer.buslist1(transidx,1) = {bnames{1}};
            y.Transformer.buslist1(transidx,2) = {bnames{2}};
            lvflag = 0;
            idx1 = []; idx2 = [];
            for ii = 1:length(y.Bus.AllNodeNames1)
                if isempty(idx1)
                    idx1 = strfind(y.Bus.AllNodeNames1{ii},y.Transformer.buslist1{transidx,1});
                    if ~isempty(idx1), idx1 = ii; end
                end
                if isempty(idx2)
                    idx2 = strfind(y.Bus.AllNodeNames1{ii},y.Transformer.buslist1{transidx,2});
                    if ~isempty(idx2), idx2 = ii; end
                end
            end
            if idx1 & idx2
                transidx1 = transidx1 + 1;
                y.Transformer.busidx1(transidx1,1) = idx1;
                abus = DSSCircuit.Buses(bnames{1});
                lvflag = lvflag | abus.kVBase < 1;
                y.Transformer.busidx1(transidx1,2) = idx2;
                abus = DSSCircuit.Buses(bnames{2});
                lvflag = lvflag | abus.kVBase < 1;
                y.Transformer.busidx1(transidx1,3) = lvflag;
                y.Transformer.busidx1(transidx1,4) = abus.kVBase;
            end
            % phase 2
            y.Transformer.buslist2(transidx,1) = {bnames{1}};
            y.Transformer.buslist2(transidx,2) = {bnames{2}};
            lvflag = 0;
            idx1 = []; idx2 = [];
            for ii = 1:length(y.Bus.AllNodeNames2)
                if isempty(idx1)
                    idx1 = strfind(y.Bus.AllNodeNames2{ii},y.Transformer.buslist2{transidx,1});
                    if ~isempty(idx1), idx1 = ii; end
                end
                if isempty(idx2)
                    idx2 = strfind(y.Bus.AllNodeNames2{ii},y.Transformer.buslist2{transidx,2});
                    if ~isempty(idx2), idx2 = ii; end
                end
            end
            if idx1 & idx2
                transidx2 = transidx2 + 1;
                y.Transformer.busidx2(transidx2,1) = idx1;
                abus = DSSCircuit.Buses(bnames{1});
                lvflag = lvflag | abus.kVBase < 1;
                y.Transformer.busidx2(transidx2,2) = idx2;
                abus = DSSCircuit.Buses(bnames{2});
                lvflag = lvflag | abus.kVBase < 1;
                y.Transformer.busidx2(transidx2,3) = lvflag;
                y.Transformer.busidx2(transidx2,4) = abus.kVBase;
            end
            % phase 3
            y.Transformer.buslist3(transidx,1) = {bnames{1}};
            y.Transformer.buslist3(transidx,2) = {bnames{2}};
            lvflag = 0;
            idx1 = []; idx2 = [];
            for ii = 1:length(y.Bus.AllNodeNames3)
                if isempty(idx1)
                    idx1 = strfind(y.Bus.AllNodeNames3{ii},y.Transformer.buslist3{transidx,1});
                    if ~isempty(idx1), idx1 = ii; end
                end
                if isempty(idx2)
                    idx2 = strfind(y.Bus.AllNodeNames3{ii},y.Transformer.buslist3{transidx,2});
                    if ~isempty(idx2), idx2 = ii; end
                end
            end
            if idx1 & idx2
                transidx3 = transidx3 + 1;
                y.Transformer.busidx3(transidx3,1) = idx1;
                abus = DSSCircuit.Buses(bnames{1});
                lvflag = lvflag | abus.kVBase < 1;
                y.Transformer.busidx3(transidx3,2) = idx2;
                abus = DSSCircuit.Buses(bnames{2});
                lvflag = lvflag | abus.kVBase < 1;
                y.Transformer.busidx3(transidx3,3) = lvflag;
                y.Transformer.busidx3(transidx3,4) = abus.kVBase;
            end
        end
        flag = DSSCircuit.NextPDElement;
    end
    
    %  Load information.
    y.Load = struct();
    loadv = DSSCircuit.Loads.AllNames;
    i0 = sg_rgrep(opts.LoadExpr,loadv);
    y.Load.names = loadv(i0);
    y.Load.S1.names = loadv(i0);
    y.Load.S1.index = i0;
    y.Load.S1.val = zeros(N,length(i0));
    y.Load.S1.incl = zeros(1,length(i0));
    
    y.Load.S2.names = loadv(i0);
    y.Load.S2.index = i0;
    y.Load.S2.val = zeros(N,length(i0));
    y.Load.S2.incl = zeros(1,length(i0));
    
    y.Load.S3.names = loadv(i0);
    y.Load.S3.index = i0;
    y.Load.S3.val = zeros(N,length(i0));
    y.Load.S3.incl = zeros(1,length(i0));
    
    for n = 1:length(y.Load.S1.names)
        x = DSSCircuit.CktElements(['Load.' y.Load.S1.names{n}]);
        xx = x.get('NodeOrder');
        i1 = find(xx==1);
        if ~isempty(i1)
            y.Load.S1.incl(n) = i1;
        end
        i1 = find(xx==2);
        if ~isempty(i1)
            y.Load.S2.incl(n) = i1;
        end
        i1 = find(xx==3);
        if ~isempty(i1)
            y.Load.S3.incl(n) = i1;
        end
    end
    
    %  Capacitor information.
    y.Capacitor = struct();
    capv = DSSCircuit.Capacitors.AllNames;
    if ~strcmpi(capv{1},'none')
        i0 = sg_rgrep(opts.CapacitorExpr,capv);
    else
        i0 = [];
    end   
    y.Capacitor.names = capv(i0);
    y.Capacitor.S1.names = capv(i0);
    y.Capacitor.S1.index = i0;
    y.Capacitor.S1.val = zeros(N,length(i0));
    y.Capacitor.S1.incl = zeros(1,length(i0));
    
    y.Capacitor.S2.names = capv(i0);
    y.Capacitor.S2.index = i0;
    y.Capacitor.S2.val = zeros(N,length(i0));
    y.Capacitor.S2.incl = zeros(1,length(i0));
    
    y.Capacitor.S3.names = capv(i0);
    y.Capacitor.S3.index = i0;
    y.Capacitor.S3.val = zeros(N,length(i0));
    y.Capacitor.S3.incl = zeros(1,length(i0));
    
    for n = 1:length(y.Capacitor.S1.names)
        x = DSSCircuit.CktElements(['Capacitor.' y.Capacitor.S1.names{n}]);
        xx = x.get('NodeOrder');
        i1 = find(xx==1);
        if ~isempty(i1)
            y.Capacitor.S1.incl(n) = i1;
        end
        i1 = find(xx==2);
        if ~isempty(i1)
            y.Capacitor.S2.incl(n) = i1;
        end
        i1 = find(xx==3);
        if ~isempty(i1)
            y.Capacitor.S3.incl(n) = i1;
        end
    end
    
    y.Capacitor.State = struct();
    y.Capacitor.State.names = capv(i0);
    y.Capacitor.State.val  = zeros(N,length(i0));
    y.Capacitor.State.val2 = zeros(N,length(i0));
    
    % Capacitor indices voltage profiles
    flag = DSSCircuit.FirstPDElement;
    y.Capacitor.buslist = {};
    y.Capacitor.busidx  = [];
    capsidx  = 0;
    while flag
        aElem = DSSCircuit.ActiveElement;
        if strfind(aElem.get('Name'),'Capacitor.')
            capsidx = capsidx + 1;
            y.Capacitor.names{capsidx} = aElem.get('Name');
            idx = strfind(y.Capacitor.names{capsidx},'.');
            bnames = aElem.get('BusNames');
            y.Capacitor.buslist(capsidx,1) = {bnames{1}};
            % using first bus of capacitor, assuming three-phase caps., using
            % Phase A to find location
            idx1 = [];
            for ii = 1:length(y.Bus.AllNodeNames1)
                if isempty(idx1)
                    idx1 = strfind(y.Bus.AllNodeNames1{ii},y.Capacitor.buslist{capsidx,1});
                    if ~isempty(idx1), y.Capacitor.busidx(capsidx,1) = ii; break; end
                end
            end
        end
        flag = DSSCircuit.NextPDElement;
    end
    
    %  Voltage regulator control information.
    y.RegControl = struct();
    vregv = DSSCircuit.RegControl.AllNames;
    if ~strcmpi(vregv{1},'none')
        i0 = sg_rgrep(opts.RegControlExpr,vregv);
    else
        i0 = [];
    end    
    y.RegControl.names = vregv(i0);
    y.RegControl.TapNum.names = vregv(i0);
    y.RegControl.TapNum.val = zeros(N,length(i0));
end

y.n = y.n+1;
x = DSSCircuit.AllBusVolts;
xr = x(1:2:(end-1));
xi = x(2:2:end);
x = xr+1i*xi;
y.Bus.V1.val(y.n,:) = x(y.Bus.V1.index);
y.Bus.V2.val(y.n,:) = x(y.Bus.V2.index);
y.Bus.V3.val(y.n,:) = x(y.Bus.V3.index);
v = DSSCircuit.AllNodeVmagPUByPhase(1);
y.Bus.V1pu.val(y.n,:) = v(y.Bus.V1pu.index);
v = DSSCircuit.AllNodeVmagPUByPhase(2);
y.Bus.V2pu.val(y.n,:) =  v(y.Bus.V2pu.index);
v = DSSCircuit.AllNodeVmagPUByPhase(3);
y.Bus.V3pu.val(y.n,:) =  v(y.Bus.V3pu.index);

if(opts.Vmag==1)
    y.Bus.Vpu.val(y.n,:) = DSSCircuit.AllBusVmagPu(y.Bus.Vpu.index);
end

% update losses
y.sys.Losses(y.n,:)     = DSSCircuit.Losses;
y.sys.LineLosses(y.n,:) = DSSCircuit.LineLosses;

%  Update line power flows.
for n = 1:length(y.Line.S1.names)
    x = DSSCircuit.CktElements(['Line.' y.Line.S1.names{n}]);
    if x.Enabled
        xx = x.get('Powers');
        xxI = x.get('Currents');
        xxV = x.get('Voltages');
        
        % determine base kV for line: moved above
       
        ix = y.Line.S1.incl(n);
        ix = 2*ix-1;
        if(ix>0)
            y.Line.S1.val(y.n,n) = xx(ix)+1i*xx(ix+1);
            y.Line.I1.val(y.n,n) = xxI(ix)+1i*xxI(ix+1);
            y.Line.V11.val(y.n,n) = xxV(ix)+1i*xxV(ix+1);
            y.Line.V12.val(y.n,n) = xxV(ix+2*x.NumPhases)+1i*xxV(ix+1+2*x.NumPhases);
        end
        ix = y.Line.S2.incl(n);
        ix = 2*ix-1;
        if(ix>0)
            y.Line.S2.val(y.n,n) = xx(ix)+1i*xx(ix+1);
            y.Line.I2.val(y.n,n) = xxI(ix)+1i*xxI(ix+1);
            y.Line.V21.val(y.n,n) = xxV(ix)+1i*xxV(ix+1);
            y.Line.V22.val(y.n,n) = xxV(ix+2*x.NumPhases)+1i*xxV(ix+1+2*x.NumPhases);
        end
        ix = y.Line.S3.incl(n);
        ix = 2*ix-1;
        if(ix>0)
            y.Line.S3.val(y.n,n) = xx(ix)+1i*xx(ix+1);
            y.Line.I3.val(y.n,n) = xxI(ix)+1i*xxI(ix+1);
            y.Line.V31.val(y.n,n) = xxV(ix)+1i*xxV(ix+1);
            y.Line.V32.val(y.n,n) = xxV(ix+2*x.NumPhases)+1i*xxV(ix+1+2*x.NumPhases);
        end
    end
end

%  Update generator power values.
for n = 1:length(y.Generator.S1.names)
    x = DSSCircuit.CktElements(['Generator.' y.Generator.S1.names{n}]);
    xx = x.get('Powers');
    xxI = x.get('Currents');
    ix = y.Generator.S1.incl(n);
    if(ix~=0)
        y.Generator.S1.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Generator.I1.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
    end
    ix = y.Generator.S2.incl(n);
    if(ix~=0)
        y.Generator.S2.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Generator.I2.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
    end
    ix = y.Generator.S3.incl(n);
    if(ix~=0)
        y.Generator.S3.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Generator.I3.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
    end
end

%  Update transformer power values.
for n = 1:length(y.Transformer.S1.names)
    x = DSSCircuit.CktElements(['Transformer.' y.Transformer.S1.names{n}]);
    xx = x.get('Powers');
    xxI = x.get('Currents');
    xxV = x.get('Voltages');
    % determine base kVs
    bn1 = x.BusNames{1};
    idx = strfind(bn1,'.');
    if ~isempty(idx)
        bn1 = bn1(1:idx(1)-1);
    end
    y.Transformer.kVbase(1,n) = DSSObj.ActiveCircuit.Buses(bn1).kVBase;
    bn2 = x.BusNames{2};
    idx = strfind(bn2,'.');
    if ~isempty(idx)
        bn2 = bn2(1:idx(1)-1);
    end
    y.Transformer.kVbase(2,n) = DSSObj.ActiveCircuit.Buses(bn2).kVBase;
    AutoTrans = strcmpi(bn1,bn2); % assumption: autotransformer implementation only has one bus
    
    % single/three-phase units and autotransformers
    ix = y.Transformer.S1.incl(n);
    if (ix~=0) && (AutoTrans == 0)
        if y.n == 1, y.Transformer.x1.val(1,n) = DSSCircuit.Buses(bn1).Distance; end
        y.Transformer.S1.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Transformer.I1.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
        if x.NumPhases == 3 && x.NumConductors == 3
            y.Transformer.V11.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
            y.Transformer.V12.val(y.n,n) = xxV(2*ix-1+6)+1i*xxV(2*ix+6);
        elseif x.NumPhases == 3 && x.NumConductors == 4
            y.Transformer.V11.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
            y.Transformer.V12.val(y.n,n) = xxV(2*ix-1+8)+1i*xxV(2*ix+8);
        else
            y.Transformer.V11.val(y.n,n) = xxV(1)+1i*xxV(2);
            y.Transformer.V12.val(y.n,n) = xxV(5)+1i*xxV(6);
        end
    elseif (AutoTrans == 1) && x.NodeOrder(end) == 1
        ix = 4;
        if y.n == 1, y.Transformer.x1.val(1,n) = DSSCircuit.Buses(bn1).Distance; end;
        y.Transformer.S1.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Transformer.I1.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
        y.Transformer.V11.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
        y.Transformer.V12.val(y.n,n) = xxV(1)+1i*xxV(2);
    end
    ix = y.Transformer.S2.incl(n);
    if (ix~=0)  && (AutoTrans == 0)
        if y.n == 1, y.Transformer.x2.val(1,n) = DSSCircuit.Buses(bn1).Distance; end;
        y.Transformer.S2.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Transformer.I2.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
        if x.NumPhases == 3 && x.NumConductors == 3
            y.Transformer.V21.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
            y.Transformer.V22.val(y.n,n) = xxV(2*ix-1+6)+1i*xxV(2*ix+6);
        elseif x.NumPhases == 3 && x.NumConductors == 4
            y.Transformer.V21.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
            y.Transformer.V22.val(y.n,n) = xxV(2*ix-1+8)+1i*xxV(2*ix+8);
        else
            y.Transformer.V21.val(y.n,n) = xxV(1)+1i*xxV(2);
            y.Transformer.V22.val(y.n,n) = xxV(5)+1i*xxV(6);
        end
    elseif (AutoTrans == 1) && x.NodeOrder(end) == 2
        ix = 4;
        if y.n == 1, y.Transformer.x2.val(1,n) = DSSCircuit.Buses(bn1).Distance; end;
        y.Transformer.S2.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Transformer.I2.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
        y.Transformer.V21.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
        y.Transformer.V22.val(y.n,n) = xxV(1)+1i*xxV(2);
    end
    ix = y.Transformer.S3.incl(n);
    if (ix~=0) && (AutoTrans == 0)
        if y.n == 1, y.Transformer.x3.val(1,n) = DSSCircuit.Buses(bn1).Distance; end;
        y.Transformer.S3.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Transformer.I3.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
        if x.NumPhases == 3 && x.NumConductors == 3
            y.Transformer.V31.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
            y.Transformer.V32.val(y.n,n) = xxV(2*ix-1+6)+1i*xxV(2*ix+6);
        elseif x.NumPhases == 3 && x.NumConductors == 4
            y.Transformer.V31.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
            y.Transformer.V32.val(y.n,n) = xxV(2*ix-1+8)+1i*xxV(2*ix+8);
        else
            y.Transformer.V31.val(y.n,n) = xxV(1)+1i*xxV(2);
            y.Transformer.V32.val(y.n,n) = xxV(5)+1i*xxV(6);
        end
    elseif (AutoTrans == 1) && x.NodeOrder(end) == 3
        ix = 4;
        if y.n == 1, y.Transformer.x3.val(1,n) = DSSCircuit.Buses(bn1).Distance; end;
        y.Transformer.S3.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
        y.Transformer.I3.val(y.n,n) = xxI(2*ix-1)+1i*xxI(2*ix);
        y.Transformer.V31.val(y.n,n) = xxV(2*ix-1)+1i*xxV(2*ix);
        y.Transformer.V32.val(y.n,n) = xxV(1)+1i*xxV(2);
    end
    
    %  Update tap setting.
    y.Transformer.Tap.val(y.n,n) = str2double(x.Properties('tap').val);
end

%  Update load power values.
for n = 1:length(y.Load.S1.names)
    x = DSSCircuit.CktElements(['Load.' y.Load.S1.names{n}]);
    xx = x.get('Powers');
    ix = y.Load.S1.incl(n);
    if(ix~=0)
        y.Load.S1.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
    end
    ix = y.Load.S2.incl(n);
    if(ix~=0)
        y.Load.S2.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
    end
    ix = y.Load.S3.incl(n);
    if(ix~=0)
        y.Load.S3.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
    end
end

%  Update capacitor power values.
for n = 1:length(y.Capacitor.S1.names)
    x = DSSCircuit.CktElements(['Capacitor.' y.Capacitor.S1.names{n}]);
    xx = x.get('Powers');
    ix = y.Capacitor.S1.incl(n);
    if(ix~=0)
        y.Capacitor.S1.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
    end
    ix = y.Capacitor.S2.incl(n);
    if(ix~=0)
        y.Capacitor.S2.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
    end
    ix = y.Capacitor.S3.incl(n);
    if(ix~=0)
        y.Capacitor.S3.val(y.n,n) = xx(2*ix-1)+1i*xx(2*ix);
    end
    
    % Update state information.
    y.Capacitor.State.val2(y.n,n) = bin2dec(x.Properties('states').val(2:end-1)); % C-step(s) status
    y.Capacitor.State.val(y.n,n) = abs(imag(y.Capacitor.S1.val(y.n,n))) > Qeps;
end

%  Update voltage regulator control status.
for n = 1:length(y.RegControl.names)
    x = DSSCircuit.CktElements(['RegControl.' y.RegControl.names{n}]);
    y.RegControl.TapNum.val(y.n,n) = str2double(x.Properties('tapnum').Val);
end