function [Plf,Phf]=sg_separateProfile(varargin)
% Separates a power profile into high frequency and low frequency components.
% function [Plf,Phf] = sg_separateProfile(t,P)
%
% Inputs:   t  		        ... time array (s)
%           P  		        ... power array
%			'fc'	        ... Cutoff frequency for low-pass filter (default = 1.736e-4 Hz)
%	        'zeroThreshold' ... Power threshold below which to consider zero (default = 0.01)
%
% Outputs: 	Plf	... Low frequency component.
%			Phf ... High frequency component.
%
% Example Call(s):
%      
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%%
t=varargin{1};
P=varargin{2};

Tday=3600*24;
opts=struct('fc',15/Tday,'zeroThreshold',0.01,'zeroEdges',-1);
opts=sg_updateOpts(opts,varargin,2);

t=t-t(1);  %  Start time at t=0.
dt=t(2)-t(1);  %  Obtain time-resolution.

Pf=sg_qfilt(t,P,opts.fc,'n',2);  %  Filtered power.

%  Attempt to compensate for the phase shift of the filter in the largest,
%  non-DC component.
[f,XP]=sg_DTFS(t,P-mean(P));  % Spectrum of P.
[f,XPf]=sg_DTFS(t,Pf-mean(Pf));  % Spectrum of Pf.
df=f-(1/Tday);  %  Difference between each frequency in the spectrum and the daily frequency.
fmin=min(abs(df));
i1=min(find(df==fmin));  %  Index corresponding to the fundamental (daily) frequency component.
thetaP=angle(XP(i1));  %  Angle of the original signal at the fundamental frequency.
thetaPf=angle(XPf(i1));  %  Angle of the original signal at the fundamental frequency.
dtheta=thetaP-thetaPf;
if(dtheta<0) dtheta=dtheta+2*pi; end
tshift=dtheta*(1/f(i1))/(2*pi);
Nshift=round(tshift/dt);
Pf=circshift(Pf,-Nshift);

%  Attempt to zero out periods of low power.
if(opts.zeroEdges<0)
    i1=find(P<opts.zeroThreshold*max(P));
    P(i1)=0;
    Pf(i1)=0;
else
    tedge=(t(end)-t(1))*opts.zeroEdges; 
    i1=find(t<tedge);
    P(i1)=0;
    Pf(i1)=0;
    i1=find(t>(t(end)-tedge));
    P(i1)=0;
    Pf(i1)=0;
end

Plf=Pf;  %  Low frequency component.
Phf=P-Plf;  %  High frequency component.
