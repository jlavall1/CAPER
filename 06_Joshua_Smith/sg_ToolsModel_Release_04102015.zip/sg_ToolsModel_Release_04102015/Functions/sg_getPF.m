function y = sg_getPF(S,varargin)
% 'Continuous' power factor for better visualization.
% function y = sg_getPF(S,varargin)
%
% Computes and plots the power factor using measured complex power. The
% power factor is continuous at 1, avoiding discontinuities due to
% inductive/capacitive reactive power.
%
% Inputs: S          ... complex power
%         'plot'     ... 0 (no) / 1 (yes)
%         'fno'      ... figure number (default: 1)
%         'time','t' ... time vector (s)
%
% Outputs: y.          ... data structure
%          .PF.val     ... power factor
%          .PF.valCont ... continuous power factor (for plotting) mapping PF<0 (0 - -1) to 1 - 2
%          .hf         ... figure handle
%          .ytlNoCust  ... numeric custom Y-tick labels (used in the plot)
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

% Defaults
plotFlag = 1;
fno      = 1;
t        = [];
PF       = [];

% Handle options
for ii = 1:2:length(varargin)
    switch varargin{ii}
        case 'plot'
            plotFlag = varargin{ii+1};
        case 'fno'
            fno = varargin{ii+1};
        case {'time','t'}
            t = varargin{ii+1}/60;
            xlabelTxt = 'time (min)';
        otherwise
            fprintf(' Unknown option: %s\n',varargin{ii});
    end
end
% time vector
if isempty(t)
    t = [1:1:size(S,1)];
    xlabelTxt = 'points';
end

% Compute power factor
phi = atan(imag(S)./real(S));
y.PF.val     = cos(phi).*sign(phi);
y.PF.valCont = cos(phi).*sign(phi);
idx = find(y.PF.val < 0);
if ~isempty(idx)
    y.PF.valCont(idx) = y.PF.valCont(idx) + 2;
end

% Plot: shift negative power factor for continous plots
y.hf = figure(fno);
clf
plot(t, y.PF.valCont,'-x','linewidth',1)
xlabel(xlabelTxt)
ylabel('power factor')
% Custom Y-tick labels
ah = gca;
ytlNo = get(ah,'ytick')';
y.ytlNoCust = ytlNo;
idx = find(ytlNo > 1);
if ~isempty(idx)
    y.ytlNoCust(idx,1) = y.ytlNoCust(idx,1) - 2;
    set(ah,'yticklabel',num2str(y.ytlNoCust));
end