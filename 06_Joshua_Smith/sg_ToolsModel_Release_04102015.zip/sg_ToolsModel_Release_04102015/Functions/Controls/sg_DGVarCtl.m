%  sg_DGVarCtl Class
%  This class implements reactive power control functions for distributed generation.
%  Objects from this class are intended to be used with the sg_RunOpenDSSSim() function.
%  The class supports a constructor for configuration, and supports a single method, operate(), which
%  is called by sg_RunOpenDSSSim().
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
classdef sg_DGVarCtl < handle
    properties
        equipment;  % Full name of the generator to be controlled.
        pf; % Power factor of generator
        kvar; % kvar of generator
        kv; %base voltage
%         Maxkvar; %limit of VAR
%         Minkvar; %limit of VAR
        mode; %type of VAR control
            %Mode 1: constant pf
            %Mode 2: constant var
            %Mode 3: German LV-curve (P-pf, always lagging)
            %Mode 4: Volt-var curve
            %Mode 5: Volt-pf curve
        XsetPt; % vector of x-axis setpoints in pu (either voltage or power)
        YsetPt; % vector of y-axis setpoints in pu (either pf or kvar)
        pvSb; % rated complex power
        pvPb; % rated real power
        init; %Initially set to 1, and then set to 0 after initialized.
        busName;  %  Name of the bus to which the generator is connected.
        indexNode;  %  Index (or indices) of associated node.

	end
    methods
		%  Constructor for the class.
		% Inputs: equipment		... a string indicating the fully qualified name of the
		%                           generator being controlled (e.g. 'Generator.B30020P')
		% Options: 
		%         'pf'      ... Reference power factor to be used for the generator (if using 
		%                       constant power factor mode) (default = 1).
		%         'kvar'    ... Reference reactive power to be used for the generator (if using
		%                       constant reactive power mode) (default=0).
		%		  'kv'		... Rated voltage (kV) of generator.
		%		  'mode'    ... The mode of reactive power control to be employed (default=1):
		%                         1 - Constant power factor.
		%                         2 - Constant reactive power.
		%                         3 - Power - Power Factor control
		%                         4 - Volt-Var control
		%                         5 - Volt - Power Factor control
		% 		  'XsetPt' 	... Vector of x-axis points for the control characteristic (if required). 
		% 		  'YsetPt' 	... Vector of y-axis points for the control characteristic (if required). 
		%         'pvSb'    ... The rated apparent power (kVA) of the generator (default = 1).
		%         'pvPb'    ... The rated power (kW) of the generator (default = 1).
		
        function obj=sg_DGVarCtl(varargin)
            obj.equipment=varargin{1};
            opts=struct('pf',1,'kvar',0,'kv',0.48,...
                'mode',1,'XsetPt',[],'YsetPt',[],'pvSb',1,'pvPb',1);
            opts=sg_updateOpts(opts,varargin,1);
			obj.pf=opts.pf;
            obj.kvar=opts.kvar;
			obj.kv=opts.kv;
            obj.mode=opts.mode;
            obj.XsetPt=opts.XsetPt;
            obj.YsetPt=opts.YsetPt;
            obj.pvSb=opts.pvSb;
            obj.pvPb=opts.pvPb;
            obj.init=1;
        end
        function operate(obj,DSSobj,t)
%             If t=0, set the init pf Min/Max kvar
             if(obj.init==1)
                initPF=obj.pf; 
                
                n2 = sprintf('%s.kv',obj.equipment);
                obj.kv = str2num(sg_getParam(DSSobj,n2));
                
                %  Obtain the bus name and associated indices (used to
                %  obtain the voltage at the terminals of the generator).
                str1=sprintf('%s.bus1',obj.equipment);
                obj.busName=sg_getParam(DSSobj,str1);
                %  If needed, remove the .0 at the end of the name.
                if(strcmp(obj.busName([end-1,end]),'.0')==1)
                    obj.busName=obj.busName(1:(end-2)); 
                end

                obj.indexNode=sg_rgrep(obj.busName,DSSobj.ActiveCircuit.AllNodeNames);
               
                obj.init=0;
             end
                         
            pvPb=obj.pvPb;
            pvVb=obj.kv*1e3;

            i1=2*obj.indexNode-1;
            Vr=DSSobj.ActiveCircuit.AllBusVolts(i1);
            Vi=DSSobj.ActiveCircuit.AllBusVolts(i1+1);
            if(length(obj.indexNode)>1)
                Vpu=(1/3)*sqrt(3)*(abs(Vr(1)+j*Vi(1))+abs(Vr(2)+j*Vi(2))+abs(Vr(3)+j*Vi(3)))/pvVb;
            else
                Vpu=abs(Vr+j*Vi)/pvVb;
            end

            str1=sprintf('%s.kW',obj.equipment);
            P=str2num(sg_getParam(DSSobj,str1));
            
            Ppu=P/pvPb;
            xxx=1;

            switch obj.mode
                 case 1%constant pf
                     kvarr=P*sqrt((1/obj.pf)^2-1);
                case 2%constant var
                    kvarr=obj.kvar;
                case 3%German LV-curve
                    if(Ppu<0.5)
                        obj.pf=1.0;
                    else
                        obj.pf=interp1(obj.XsetPt,obj.YsetPt,Ppu,'linear');
                    end
                    if(obj.pf>1)
                        obj.pf = -1*(2-obj.pf); 
                    end
                    kvarr=sign(obj.pf)*P*sqrt((1/obj.pf)^2-1);
               
                case 4%Volt-var curve
                    kvarr=0;
                    if(Vpu>obj.XsetPt(end))
                        kvarr=obj.YsetPt(end);
                    elseif(Vpu<obj.XsetPt(1))
                        kvarr=obj.YsetPt(1);
                    else
                        kvarr=interp1(obj.XsetPt,obj.YsetPt,Vpu,'linear');
                    end
                    kvarr=kvarr*obj.pvPb;
                                   
                case 5%Volt-pf curve
                    if(Vpu>obj.XsetPt(end))
                        obj.pf=obj.YsetPt(end);
                    elseif(Vpu<obj.XsetPt(1))
                        obj.pf=obj.YsetPt(1);
                    else
                        obj.pf=interp1(obj.XsetPt,obj.YsetPt,Vpu,'linear');
                    end
                    if(obj.pf>1)
                        obj.pf = -1*(2-obj.pf); 
                    end
                    kvarr=sign(obj.pf)*P*sqrt((1/obj.pf)^2-1);
            end
            %  If the requested P and Q exceed the maximum S, limit the Q.
            St=abs(P+j*kvarr);
            if(St>obj.pvSb)
                skv=sign(kvarr);
                 kvarr=skv*sqrt(obj.pvSb^2-P^2);
            end
            str1 = sprintf('edit %s kvar = %d',obj.equipment,kvarr);
            DSSobj.Text.Command = str1;
        end
    end
end
        