%  sg_CapCtl_pf_Q Class
%  This class implements power factor control for capacitor banks, including a reactive power
%  restraint.  Objects from this class are intended to be used with the sg_RunOpenDSSSim() function.
%  The class supports a constructor for configuration, and supports a single method, operate(), which
%  is called by sg_RunOpenDSSSim().
%
% Florida State University 
% Center for Advanced Power Systems 
% Sunshine State Solar Grid Initiative (SUNGRIN) 
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
classdef sg_CapCtl_pf_Q < handle
    properties
        equipment;  % Full name of the capacitor to be controlled.
        line;  %  Name of the line to be monitored.
        pfoff;  %  Power factor below which to switch out the capacitor.
        pfon; % Power factor below which to switch in the capacitor.
        delay;  %  Pickup time for switching in the capacitor (s).
        delayoff;  % Pickup time for switching out the capacitor (s).
        kvarmin;  %  Minimum kvar value below which capacitor switching should be restrained.
        tel;  %  Elapsed time on pickup timer (s).
        state;  %  Current state of capacitor.
        init;  %  Initially set to 1, and then set to 0 after initialized.
        t0;  %  Previous time.
        disable;  %  Option to disable controls.
    end
    methods
	    %  Constructor for the class.
		% Inputs: equipment		... a string indicating the fully qualified name of the
		%                           capacitor bank being controlled (e.g. 'Capacitor.B30020P')
		%         line			...	a string indicating the unqualified name of the line being 
		%						being monitored (flow used for control of the capacitor bank)
		%						(e.g. 'B30000P_B30010P')
		% Options:
		% 		  'pfoff' 		... Power factor at which to switch out capacitor (negative value
		%                       indicates reactive power flow out of the feeder (default = -0.99).
		% 		  'pfon' 		... Power factor at which to switch in capacitor (negative value
		%                       indicates reactive power flow out of the feeder (default = 0.99).
		% 		  'delay' 		... Pickup time (s) for switching in capacitor (default = 60).
		% 		  'delayoff' 	... Pickup time (s) for switching out capacitor (default = 60).
		% 		  'kvarmin' 	... Reactive power magnitude (kVAR) below which to disable capacitor 
		%							switching (default = 0).
		% 		  'state' 		... Initial state of capacitor (0 - off, 1 - on) (default=0).
		% 		  'disable' 	... Option to disable (1) or enable (0) the capacitor controls
		%							(default = 0).
        function obj=sg_CapCtl_pf_Q(varargin)
            obj.equipment=varargin{1};
            obj.line=varargin{2};
            opts=struct('pfoff',-.99,'pfon',.99,'delay',60,'delayoff',60,...
                'kvarmin',0,'state',0,'disable',0);
            opts=sg_updateOpts(opts,varargin,2);
            obj.pfoff=opts.pfoff;
            obj.pfon=opts.pfon;
            obj.delay=opts.delay;
            obj.delayoff=opts.delayoff;
            obj.kvarmin=opts.kvarmin;
            obj.state=opts.state;
            obj.init=1;
            obj.tel=0;
            obj.t0=0;
            obj.disable=opts.disable;
            
            if(obj.pfoff<0)
                obj.pfoff=2+obj.pfoff; 
            end
            if(obj.pfon<0)
                obj.pfon=2+obj.pfon; 
            end
        end
        function operate(obj,DSSobj,t)
             %  If t=0, set the state to the initial state.
             if(obj.init==1)
                 str1 = sprintf('edit %s states = %d',obj.equipment,obj.state);
                 DSSobj.Text.Command = str1; 
                 obj.init=0;
             end
             
             if(obj.disable==0)
                 %  Obtain power flow information and calculate the power
                 %  factor.
                 r=sg_getLineFlow(DSSobj,'LineExpr',obj.line,'caseSensitive',0);
                 S1=r.Line.S1.val+r.Line.S2.val+r.Line.S3.val;
                 P1=real(S1);
                 Q1=imag(S1);
                 pf=sign(Q1)*abs(P1)/abs(S1);
                 if(pf<0)
                     pf=2+pf; 
                 end

                 %  Compute time elapsed since the previous time-step.
                 dt=t-obj.t0;
                 obj.t0=obj.t0+dt;

                 %  Conduct comparisons and update the timer.
                 if(obj.state==1)
                      if((pf>obj.pfoff)&(abs(Q1)>obj.kvarmin))
                          obj.tel=obj.tel+dt;
                          if(obj.tel>obj.delayoff)  % If timer expires, switch out capacitor.
                              str1 = sprintf('edit %s states = 0',obj.equipment);
                              DSSobj.Text.Command = str1;
                              obj.tel=0;
                              obj.state=0;
                          end
                      else
                          obj.tel=0;
                      end
                 else
                      if((pf<obj.pfon)&(abs(Q1)>obj.kvarmin))
                          obj.tel=obj.tel+dt;
                          if(obj.tel>obj.delay)  % If timer expires, switch capacitor in.
                              str1 = sprintf('edit %s states = 1',obj.equipment);
                              DSSobj.Text.Command = str1;
                              obj.tel=0;
                              obj.state=1;
                          end
                      else
                          obj.tel=0;
                      end
                 end
             end
             
        end
    end
end
        