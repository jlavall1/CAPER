function val=sg_getParam(varargin)
% Get Value of Parameter of OpenDSS Model
% function val = sg_getParam(DSSObj,param)
%
% 
%
% Inputs: DSSObj	... a connection to an OpenDSS object with a loaded model
%    	  param 	... a string specifying the name of the
%      				  	parameter for which a value is to be scaled.
% 
% Outputs: val 		... the value of the parameter as a string.
%
% Example Call(s):
%		val = sg_getParam(DSSObj,'Generator.B30082P_1');
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%%
DSSObj=varargin{1};
param=varargin{2};


% opts=struct('scale',1,'verify',1);
% opts=sg_updateOpts(opts,varargin,3);
% 
% messages={};
% Nmessages=0;


str1 = sprintf('? %s',param);
DSSObj.Text.Command = str1;
val=DSSObj.Text.Result;


