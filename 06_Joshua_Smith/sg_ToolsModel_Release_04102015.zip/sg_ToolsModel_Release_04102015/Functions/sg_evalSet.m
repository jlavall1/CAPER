function sg_evalSet(varargin)

%  evalSet(D,f,basefn)
%  

D=varargin{1};
f=varargin{2};
basefn=varargin{3};

opts=struct('overwrite',1,'Niterations',1,'dVmax',-1,'Npts',-1,'v',1,...
    'configConstants',0,'capControls','','Nruns',-1);
opts=sg_updateOpts(opts,varargin,3);

if(ischar(D))
    D=sg_loadTable(D,'num',0); 
end

Dact=D;

paramNmV=fieldnames(Dact);
Nruns=length(Dact.(paramNmV{1}));

if(opts.Nruns>0)
    Nruns=opts.Nruns; 
end


for(n=1:Nruns)
    fn=sprintf('%s_%d.mat',basefn,n);
    if((opts.overwrite==1)||(exist(fn)==0))
        tic;
        x=sg_sliceStruct(D,n);
        if(opts.v==1) fprintf(1,'Running test number %d.\n',Dact.Number{n}); end
        r=f(x,'profilePoints',opts.Npts,'Niterations',opts.Niterations,...
            'dVmax',opts.dVmax,'configConstants',opts.configConstants,...
            'capControls',opts.capControls);
        save(fn,'r');
        Tel=toc;
        if(opts.v==1) fprintf(1,'Time Elapsed (min):  %f\n',Tel/60); end
    end
end


