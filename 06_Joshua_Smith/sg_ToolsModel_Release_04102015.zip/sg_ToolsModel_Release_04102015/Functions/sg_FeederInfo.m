function r = sg_FeederInfo(varargin)
% Feeder circuit summary.
% function r = sg_FeederInfo(varargin)
%
% Determines, returns and displays basic feeder circuit and element information.
%
% Inputs: 'plot'     ... 0-no, 1-yes (default)
%         'fno'      ... figure number (default: 10)
%         'data'     ... results data structure
%
% Outputs: r. 	... data (results) structure with added fields:
%          			for names (.n.) and units (.u.)
%          .FI.n.	... names substructure:
%		   .FI.u.	... units substructure:
%          		.Lines		       
%          		.Capacitors  
%          		.Generators  
%          		.Loads        
%          		.TapControls
%          		.Transformers
%          		.Length
%          		.Substation_Voltage_kV
%
% Example Call(s):
%    	r = sg_FeederInfo(r);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%% Defaults
plotFlag = 1;          % plot: yes
fno      = 10;         % figure number used
fsText   = 10;         % font size for labels/text
DispFlag = 0;          % turn on/off console display (0/1)
km2mi    = 1/1.609344; % converts km to miles

r.status   = 0;    % success status (0/1)
EventLog = {};     % keeps track of warning/error messages (cell array)

if isempty(varargin) || (length(varargin) == 1 && ~isstruct(varargin{1}))
    r.EventLog{end+1} = sprintf('Error: Feeder Information: Need data structure as input.');
    if DispFlag,
        fprintf('%s\n',r.EventLog{end});
    end
    return
end
if length(varargin) == 1
    r = varargin{1};
end


%% Handle options
if length(varargin) > 1
    for ii = 1:2:length(varargin)
        switch varargin{ii}
            case {'data','d'}
                r = varargin{ii+1};
            case 'plot'
                plotFlag = varargin{ii+1};
            case 'fno'
                fno = varargin{ii+1};
            otherwise
                fprintf(' Unknown option: %s\n',varargin{ii});
        end
    end
end

%% returning data as structure: defaults
r.FI = struct();
r.FI.n.Buses = 0;
r.FI.n.Nodes = 0;
r.FI.n.MV_Nodes = 0;
r.FI.n.LV_Nodes = 0;
r.FI.n.Lines = 0;
r.FI.n.Loads = 0;
r.FI.n.Capacitors  = 0;
r.FI.n.Generators  = 0;
r.FI.n.Tap_Controls = 0;
r.FI.n.Transformers = 0;
r.FI.n.Length = 0;
r.FI.n.Substation_Voltage = 0;

% units (if applicable)
r.FI.u.Buses = '';
r.FI.u.Nodes = '';
r.FI.u.MV_Nodes = '';
r.FI.u.LV_Nodes = '';
r.FI.u.Lines = '';
r.FI.u.Loads = '';
r.FI.u.Capacitors  = '';
r.FI.u.Generators  = '';
r.FI.u.Tap_Controls = '';
r.FI.u.Transformers = '';
r.FI.u.Length = 'mi';
r.FI.u.Substation_Voltage = 'kV';

% compute substation voltage level
idx = find(~isempty(strfind(r.Bus.V1.names,r.Bus.SubStation.name)));
Vsub = abs(r.Bus.V1.val(1,idx(1)))*sqrt(3)/r.Bus.V1pu.val(1,idx(1));
% update
r.FI.n.Buses = length(r.Bus.AllBusNames);
r.FI.n.Nodes = length(r.Bus.AllNodeNames);
r.FI.n.Lines = size(r.Line.busidx,1);
if ~isempty(r.Load.names)
    r.FI.n.Loads = length(r.Load.names);
else
    r.FI.n.Loads = 0;
end
if ~isempty(r.Capacitor.names)
    r.FI.n.Capacitors  = length(r.Capacitor.names);
else
    r.FI.n.Capacitors  = 0;
end
if ~isempty(r.Generator.S1.names)
    r.FI.n.Generators  = length(r.Generator.S1.names);
else
    r.FI.n.Generators  = 0;
end
if ~isempty(r.RegControl.names)
    r.FI.n.Tap_Controls = length(r.RegControl.names);
else
    r.FI.n.Tap_Controls = 0;
end
if ~isempty(r.Transformer.names)
    r.FI.n.Transformers = length(r.Transformer.names);
else
    r.FI.n.Transformers = 0;
end
r.FI.n.Length = max(r.Bus.distance) * km2mi;
r.FI.n.Substation_Voltage = Vsub/1e3;
r.FI.n.MV_Nodes = sum(r.Bus.Vpu.VbkV > 1);
r.FI.n.LV_Nodes = sum(r.Bus.Vpu.VbkV <= 1);

if plotFlag
    % display as figure/table
    figure(fno)
    clf;
    set(gca,'position',[0 0 1 1]);
    set(gca,'xtick',[])
    set(gca,'ytick',[])
    set(gcf,'name','Feeder Information');
    
    Names = fieldnames(r.FI.n);
    FItext = [];
   
    for ii = 1:length(Names)
        FItext1{ii} = sprintf('%s: ',strrep(Names{ii},'_',' '));
        FItext2{ii} = num2str(r.FI.n.(Names{ii}));
        FItext3{ii} = [' ' num2str(r.FI.u.(Names{ii}))];
        text(.5,length(Names)-ii/2+1,FItext1{ii},'fontsize',fsText,'HorizontalAlignment','right');
        text(.55,length(Names)-ii/2+1,[FItext2{ii} FItext3{ii}],'fontsize',fsText,'HorizontalAlignment','left');
    end
    text(.5,length(Names)+1,'Feeder information:','fontsize',fsText,...
        'HorizontalAlignment','center','color',[0 0 1]);
    xlim([0 1]);
    ylim([0 length(Names)+2]);
end

% Event log update
EventLog{end+1} = 'Feeder information. Done.';
r.EventLog = EventLog;

