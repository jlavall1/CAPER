function r = sg_plotVarContributionsVsTime(varargin)
% Plots reative power contributions vs. time.
% function r = sg_plotVarContributionsVsTime(varargin)
%
% Plots substation, capacitor, and generator reactive power flows vs. time.
%
% Inputs:  r.         ... results data structure
%          'fno'      ... figure number (default: 35)
%
% Outputs: r.         ... data (results) structure
%           .EventLog ... string array with event messages
%			.IA.VarContr.	... var contribution substructure
% 					.SubStation.
%					.Generator.
%				        .Qbins ... data bins for reactive flows
%                       .Qper  ... %-time of flows (within bin values)
%                       .Qdur  ... %-duration flow is above level 
%
% Example Call(s):
%      r = sg_plotVarContributionsVsTime('data',r);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%% Defaults
fno      = 54;   % figure number used
DispFlag = 0;    % command line display flag (0/1), default: off
lWidth   = 1;    % line width in plots
daySec   = 60*60*24; % seconds/day
EventLog = {};   % event information
npHist   = 21;   % histogram bins and minimum number of points before histogram and duration curves are computed
roundQ   = 50;   % round reactive power to nearest roundQ (histgram and duration curves)
rWidth  = 0.9;   % relative bar width (gap helps recognize bins)

%% Handle options
if ~isempty(varargin)
    if isstruct(varargin{1})
        r = varargin{1};
        ArgIdx = 2;
    else
        ArgIdx = 1;
    end
    for ii = ArgIdx:2:length(varargin)
        switch varargin{ii}
            case {'data','d'}
                r = varargin{ii+1};
            case 'fno'
                fno = varargin{ii+1};
            otherwise
                fprintf(' Unknown option: %s\n',varargin{ii});
        end
    end
else
    if DispFlag
        fprintf('\n Need at least results structure as input.\n');
    end
    EventLog{end+1} = 'Error: No input data to sg_PlotSwCapacitors().';
    r.EventLog = EventLog;
    return
end

%% Figure(s)
% substation
try
    if ~isempty(r.Bus.SubStation.name)
        SubName = r.Bus.SubStation.name;
    end
catch
    SubName = [];
end
if ~isempty(SubName)
    % Attempt to find Sub Station data: from connected transformer or line
    i1 = find(~cellfun(@isempty,strfind(r.Transformer.names,SubName)));
    i2 = find(~cellfun(@isempty,strfind(r.Line.S1.names,SubName)));
    if ~isempty(i1)
        Qs = imag(r.Transformer.S1.val(:,i1) + r.Transformer.S2.val(:,i1) + r.Transformer.S3.val(:,i1));
    elseif ~isempty(i2)
        Qs = imag(r.Line.S1.val(:,i2) + r.Line.S2.val(:,i2) + r.Line.S3.val(:,i2));
    else
        Qs = [];
    end
    
    % reactive power flow
    if ~isempty(Qs)
        fno = fno + 1;
        figure(fno);
        clf
        plot(r.t/daySec,Qs,'linewidth',lWidth);
        grid on
        ylabel('reactive power (kvar)');
        xlabel('time (days)');
        set(gcf,'name',['Substation reactive power flow vs. time']);
    end
       
    if length(r.t) >= npHist
        % reactive flows histogram
        npQ = length(Qs);
        Qmin = floor(min(Qs)/roundQ)*roundQ;
        Qmax = ceil(max(Qs)/roundQ)*roundQ;
        Qstep = (Qmax - Qmin) / npHist;
        Qbins = [Qmin:Qstep:Qmax-Qstep,Qmax+1e-3];
        [Qcount,Qidx] = histc(Qs,Qbins);
        Qper = Qcount(1:end-1)/npQ*100;
        Qdur = [0; cumsum(flipud(Qper))];
        
        r.IA.VarContr.SubStation.Qbins = Qbins;
        r.IA.VarContr.SubStation.Qper = Qper;
        r.IA.VarContr.SubStation.Qdur = Qbins;
        
        fno = fno + 1;
        figure(fno);
        clf
        bar(Qbins(1:end-1)+diff(Qbins)/2,Qper,'barwidth',rWidth);
        xlabel('reactive power (kvar)')
        ylabel('occurance (%)')
        xlim([Qmin Qmax])
        set(gca,'XTick',round(Qbins))
        set(gcf,'name','Substation reactive power histogram')       
        
        % reactive flow duration curve
        fno = fno + 1;
        figure(fno);
        clf
        plot(Qdur,fliplr(round(Qbins)),'linewidth',lWidth*2);
        xlabel('duration (%)')
        ylabel('reactive power (kvar)')
        ylim([Qmin Qmax])
        grid on
        set(gca,'YTick',round(Qbins(1:2:end)))
        set(gcf,'name','Substation reactive power duration curve')
    end
end

% capacitors
if ~isempty(r.Capacitor.S1.val)
    names  = r.Capacitor.names;
    NoCaps = length(names);
    for ii = 1:NoCaps
        Cnames{ii} = names{ii}(11:end);
    end
    fno = fno + 1;
    figure(fno);
    clf
    plot(r.t/daySec,-imag(r.Capacitor.S1.val+r.Capacitor.S2.val+r.Capacitor.S3.val),'linewidth',lWidth);
    grid on
    ylabel('reactive power (kvar)');
    xlabel('time (days)');
    set(gcf,'name',['Capacitor reactive power contributions vs. time']);
    legend(Cnames,'location','bestoutside')
end

% generators
if ~isempty(r.Generator.S1.val)
    Qg = -imag(r.Generator.S1.val+r.Generator.S2.val+r.Generator.S3.val);
    
    fno = fno + 1;
    figure(fno);
    clf
    plot(r.t/daySec,Qg,'linewidth',lWidth);
    grid on
    ylabel('reactive power (kvar)');
    xlabel('time (days)');
    set(gcf,'name',['Genrator reactive power contributions vs. time']);
    legend(r.Generator.BusNames,'location','bestoutside')
    
    if length(r.t) >= npHist
        Qg = sum(Qg,2); % sum of all sites
        
        % reactive flows histogram
        npQ = length(Qg);
        Qmin = floor(min(Qg)/roundQ)*roundQ;
        Qmax = ceil(max(Qg)/roundQ)*roundQ;
        Qgtep = (Qmax - Qmin) / npHist;
        Qbins = [Qmin:Qgtep:Qmax-Qgtep,Qmax+1e-3];
        [Qcount,Qidx] = histc(Qg,Qbins);
        Qper = Qcount(1:end-1)/npQ*100;
        Qdur = [0; cumsum(flipud(Qper))];
        
        r.IA.VarContr.Generator.Qbins = Qbins;
        r.IA.VarContr.Generator.Qper = Qper;
        r.IA.VarContr.Generator.Qdur = Qbins;
        
        fno = fno + 1;
        figure(fno);
        clf
        bar(Qbins(1:end-1)+diff(Qbins)/2,Qper,'barwidth',rWidth);
        xlabel('reactive power (kvar)')
        ylabel('occurance (%)')
        xlim([Qmin Qmax])
        set(gca,'XTick',round(Qbins))
        set(gcf,'name','Generation reactive power histogram')       
        
        % reactive flow duration curve
        fno = fno + 1;
        figure(fno);
        clf
        plot(Qdur,fliplr(round(Qbins)),'linewidth',lWidth*2);
        xlabel('duration (%)')
        ylabel('reactive power (kvar)')
        ylim([Qmin Qmax])
        grid on
        set(gca,'YTick',round(Qbins(1:2:end)))
        set(gcf,'name','Generation reactive power duration curve')
    end
end

% exit message
EventLog{end+1} = 'Reactive power contributions plot. Done.';
r.EventLog = EventLog;
