function [y,varargout] = sg_plotFeeder(varargin)
% Plot feeder power flow information
% function y = sg_plotFeeder(varargin)
%
% Plot feeder power flow information. Requires x/y-coordinates within
% data structure r. Showing lines, transformers, capacitors, and PV.
%
% Input: r         ... feeder data structure (as first argument)
%        'data'    ... data structure to be used
%        'fname'   ... full file name (with path) of data file (*.mat), which
%                      contains results data structure
%        'figno'   ... figure number for plot (default = 12)
%        'index'   ... index into result matrices/vectors to be plotted 
%					   (e.g., for animations), default: 1
%        'animate' ... 0-no/1-yes
%        'pause'   ... pause time in seconds between plot updates
%        'avi'     ... frame rate for exporting animation to avi-file, 0-no avi, 
%					   default: 0
%        'clf'     ... clear figure before starting to plot, default: 1
%        'c'       ... add capacitor status (off/on) along feeder, color code: 
%					   red-on/energized, green-off/not energized
%       'cdistoff' ... shifting x-position of capacitor labels by this amount, 
%					   default: zero-vector
%
% Outputs:
%
% Examples:
%   	y = sg_plotFeeder(r); % plots one (first) power flow results
%		...
%   	y = sg_plotFeeder(r,'animate',1,'index',1:r.n,'figno',10);
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682
%

%% defaults
figNo    = 12;  % figure number
index    = 1;  % index into results matrix to be plotted (use, e.g., to down-sample in animations)
animate  = 0;  % animate figures (allows for pause between updates)
pausev   = 0;  % time to pause (s)
aviRate  = 0;  % save sequence of figure as avi-video file if >0, frame rate per second (e.g., 4)
clfFlag  = 1;  % clear plot
Cstatus  = 0;  % >0: display info based on component status
DispFlag = 1;  % message display flag (0/1)
y        = [];
r        = [];
EventLog = {}; % event messages
nout = max(nargout,1)-1;
if nout == 1
    varargout{1} = [];
end
fname    = '';  % path\file name to data file (*.mat)

% Plot options: line styles
linecolor   = {'b' 'r' 'k'};
linestyle   = {'-' ':' '-.'};
ConCol      = [1 0 0];  % red (energized)
CoffCol     = [0 .5 0]; % green (not energized)

cudir = pwd;
 
%% Options
if isempty(varargin)
    %% Use GUI in case of no data
    fsc = filesep;
    % select data file using GUI
    [filename,pathname] = uigetfile('*.mat','Select a SUNGRIN results file ...');
    if pathname == 0
        if DispFlag
            fprintf('\n You must select a valid (*.mat) file! Terminating.\n');
        end
        EventLog{end+1} = 'Error: No valid data file selected.';
        y.EventLog = EventLog;
        if nout == 1
            r.EventLog = EventLog;
            varargout{1} = r;
        end
        return
    end
    cd(pathname);
    r = load(filename);
%     cd(cudir);
    strName = fieldnames(r);
    r = r.(strName{1});
    
    % update feeder info if necesary
    fsc = filesep;
    if isfield(r,'Feeder')
        if isstruct(r.Feeder)
            idx = strfind(r.Feeder.model,fsc);
            if ~isempty(idx)
                r.Feeder.model = [pathname r.Feeder.model(idx(end)+1:end)];
            else
                r.Feeder.model = [pathname r.Feeder.model];
            end
        elseif ischar(r.Feeder)
            r.Feeder.model = [pathname r.Feeder];
        end
        if isfield(r.Feeder,'profile')
            idx = strfind(r.Feeder.profile,fsc);
            if isempty(idx)
                FeederProfile = r.Feeder.profile;
            else
                FeederProfile = r.Feeder.profile(idx(end)+1:end);
            end
        else
            r.Feeder.profile = '';
        end
    else
        r.Feeder.model = [pathname filename];
    end
elseif isstruct(varargin{1})
    r = varargin{1};
    if length(varargin) > 1
        varargin = varargin(2:end);
    else
        varargin = [];
    end
end
if ~isempty(varargin)
    for ii=1:2:length(varargin)
        switch lower(varargin{ii})
            case 'figno'
                figNo = varargin{ii+1};
            case 'data'
                r = varargin{ii+1};
            case 'fname'
                fname = varargin{ii+1};
            case 'limits'
                vlimits = varargin{ii+1};
            case 'vfeeder'
                vfeeder = varargin{ii+1};
            case 'index'
                index = varargin{ii+1};
            case 'animate'
                animate = varargin{ii+1};
            case 'pause'
                pausev = varargin{ii+1};
            case 'vscale'
                vscale = varargin{ii+1};
            case 'avi'
                aviRate = varargin{ii+1};
            case 'clf'
                clfFlag = varargin{ii+1};
            case 'c'
                Cstatus = varargin{ii+1};
            case 'cdistoff'
                CDistOff = varargin{ii+1};
            case 'dispflag'
                DispFlag = varargin{ii+1};
        end
    end
end
if ~isempty(fname)
    try
        r = load(fname,'-mat');
        strName = fieldnames(r);
        r = r.(strName{1});
    catch
        le = lasterror;
        EventLog{end+1} = sprintf('Error: Plotting feeder:  %s, File: %s, Line: %.0f',le.message,le.stack(1).name,le.stack(1).line);
        if DispFlag
            fprintf('\n Error loading results data:\n  %s\n',le.message);
            fprintf('\n File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
        end
        y.EventLog = EventLog;
        r.EventLog = EventLog;
        if nout == 1
            varargout{1} = r;
        end
        return
    end
end
if isempty(r)
    % e.g., empty string --> load using GUI
    fsc = filesep;
    % select data file using GUI
    [filename,pathname] = uigetfile('*.mat','Select a SUNGRIN results file ...');
    if pathname == 0
        if DispFlag
            fprintf('\n You must select a valid (*.mat) file! Terminating.\n');
        end
        EventLog{end+1} = 'Error: No valid data file selected.';
        y.EventLog = EventLog;
        if nout == 1
            varargout{1} = r;
        end
        r.EventLog = EventLog;
        return
    end
    cudir = pwd;
    cd(pathname);
    r = load(filename);
    cd(cudir);
    strName = fieldnames(r);
    r = r.(strName{1});
    r.EventLog = {};
end
                
% Check bus coordinates (all zeros if not properly set/loaded)
try
    if sum(sum(r.Bus.xy)) == 0
        if DispFlag
            fprintf(' All xy-bus coordinates are zero. Returning.\n');
        end
        y.h = []; % empty figure handle
        return
    end
catch
    le = lasterror;
    EventLog{end+1} = sprintf('Error: Plotting feeder:  %s, File: %s, Line: %.0f',le.message,le.stack(1).name,le.stack(1).line);
    if DispFlag
        fprintf('\n Error extracting result data:\n  %s\n',le.message);
        fprintf('\n File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
    end
    y.EventLog = EventLog;
    r.EventLog = EventLog;
    if nout == 1
        varargout{1} = r;
    end
    return
end
% Check for 0/0 coordinates and fix
idx = find(r.Bus.xy(:,1) == 0 & r.Bus.xy(:,2) == 0);
if length(idx)==1 && length(idx)==1
    % one execption: fix to small value
    r.Bus.xy(idx,[1 2]) = [1e-6 1e-6];
end
idx = find(r.Bus.xy(:,1) == 0 & r.Bus.xy(:,2) ~= 0);
if ~isempty(idx)
    % one of the two coordinates is zero
    r.Bus.xy(idx,[1 2]) = r.Bus.xy(idx,[1 2])+1e-6;
end
idx = find(r.Bus.xy(:,1) ~= 0 & r.Bus.xy(:,2) == 0);
if ~isempty(idx)
    % one of the two coordinates is zero
    r.Bus.xy(idx,[1 2]) = r.Bus.xy(idx,[1 2])+1e-6;
end


try
    %% Plot voltages along feeder
    h = figure(figNo);
    set(gcf,'Name','Feeder structure');
    % result taken from OpenDSS/MATLAB study, data in structure format
    Th = floor(r.t/3600); % expecting time in seconds, starting at zero
    Tm = round((r.t-Th*3600)/60);
    idx = find(Tm >= 60);
    if ~isempty(idx)
        Th(idx) = Th(idx) + 1;
        Tm(idx) = Tm(idx) - 60;
    end
    Td = floor(Th/24)+1;
    Th = Th - 24*(Td-1);
    if clfFlag
        clf;
        xlims = [];
        ylims = [];
    else
        xlims = xlim;
        ylims = ylim;
    end
    if aviRate
        vidObj = VideoWriter('Feeder.avi','Motion JPEG AVI');
        vidObj.FrameRate = aviRate; % frames per second
        open(vidObj);
    end
    
    % plot boundaries
    idx1 = find(r.Bus.xy(:,1) ~= 0);
    idx2 = find(r.Bus.xy(:,2) ~= 0);
    xmin = min(r.Bus.xy(idx1,1));
    xmax = max(r.Bus.xy(idx1,1));
    ymin = min(r.Bus.xy(idx2,2));
    ymax = max(r.Bus.xy(idx2,2));
    dx = xmax - xmin;
    dy = ymax - ymin;
    
    xlim([xmin-dx/40 xmax+dx/40])
    ylim([ymin-dy/40 ymax+dy/40])
    
    for jj = 1:length(index)
        hold on
        % Lines: single-phase plots
        for ii = 1:size(r.Line.busidx,1)
            if r.Bus.xy(r.Line.busidx(ii,1),1)~=0 && r.Bus.xy(r.Line.busidx(ii,2),1)~=0 && ...
                r.Bus.xy(r.Line.busidx(ii,1),2)~=0 && r.Bus.xy(r.Line.busidx(ii,2),2)~=0
                if ~r.Line.busidx(ii,3)
                    plot([r.Bus.xy(r.Line.busidx(ii,1),1) r.Bus.xy(r.Line.busidx(ii,2),1)],...
                        [r.Bus.xy(r.Line.busidx(ii,1),2) r.Bus.xy(r.Line.busidx(ii,2),2)],...
                        'LineWidth',2,'Color',linecolor{1},'LineStyle',linestyle{1})
                else
                    plot([r.Bus.xy(r.Line.busidx(ii,1),1) r.Bus.xy(r.Line.busidx(ii,2),1)],...
                        [r.Bus.xy(r.Line.busidx(ii,1),2) r.Bus.xy(r.Line.busidx(ii,2),2)],...
                        'LineWidth',2,'Color',linecolor{3},'LineStyle',linestyle{1})
                end
            end
        end
        % Transformers
        for ii = 1:size(r.Transformer.buslist1,1)
            idx1 = strmatch(r.Transformer.buslist1{ii,1},r.Bus.AllBusNames);
            idx2 = strmatch(r.Transformer.buslist1{ii,2},r.Bus.AllBusNames);
            if r.Bus.xy(idx1,1)~=0 && r.Bus.xy(idx2,1)~=0 && r.Bus.xy(idx1,2)~=0 && r.Bus.xy(idx2,2)~=0
                plot([r.Bus.xy(idx1,1) r.Bus.xy(idx2,1)],[r.Bus.xy(idx1,2) r.Bus.xy(idx2,2)],...
                    'LineWidth',2,'Color',linecolor{3},'LineStyle',linestyle{1})
            end
        end
        % Capacitors
        for ii = 1:size(r.Capacitor.buslist,1)
            idx1 = strmatch(r.Capacitor.buslist{ii},r.Bus.AllBusNames);
            if Cstatus
                if r.Capacitor.State.val(index(jj),ii)
                    text(r.Bus.xy(idx1,1),r.Bus.xy(idx1,2),['C' num2str(ii)],'Color',ConCol);
                else
                    text(r.Bus.xy(idx1,1),r.Bus.xy(idx1,2),['C' num2str(ii)],'Color',CoffCol);
                end
            else
                text(r.Bus.xy(idx1,1),r.Bus.xy(idx1,2),['C' num2str(ii)],'Color',[0 0 0]);
            end
        end
        % Generator (PV)
        if length(r.Generator.S1.names) > 0
            for ii = 1:length(r.Generator.BusNames)
                idx1 = strmatch(r.Generator.BusNames{ii},r.Bus.AllBusNames);
                if Cstatus
                    if abs(r.Generator.S1.val(index(jj),ii)+r.Generator.S3.val(index(jj),ii)+r.Generator.S3.val(index(jj),ii)) > 0.1 % > 100VA?
                        text(r.Bus.xy(idx1,1),r.Bus.xy(idx1,2),['PV' num2str(ii)],'Color',ConCol);
                    else
                        text(r.Bus.xy(idx1,1),r.Bus.xy(idx1,2),['PV' num2str(ii)],'Color',CoffCol);
                    end
                else
                    text(r.Bus.xy(idx1,1),r.Bus.xy(idx1,2),['PV' num2str(ii)],'Color',[0 0 0]);
                end
            end
        end
        % Substation symbol
        idx = strmatch(r.Bus.SubStation.name,r.Bus.AllBusNames);
        if r.Bus.xy(idx,1)~=0 && r.Bus.xy(idx,2)~=0
            plot(r.Bus.xy(idx,1), r.Bus.xy(idx,2),'s',...
                'MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',10);
            text(r.Bus.xy(idx,1)+(xmax-xmin)/40,r.Bus.xy(idx,2)+(ymax-ymin)/40,['Sub'],'Color',[0 0 0]);
        end
        
        % 'zoom-in' to just below and above plotted data
        % ylim([floor(ymin*100)/100 ceil(ymax*100)/100])
        
        hold off
        xlabel('blue: Medium Voltage lines, black: Low Voltage lines (\leq1kV) and transformers')
        titlestr = ['Day ' num2str(Td(index(jj))) ':  ' num2str(Th(index(jj)),'%02.0f') ':' num2str(Tm(index(jj)),'%02.0f')];
        if Cstatus
            % if based on status: display time info
            title(titlestr)
        end
        grid on
        drawnow;
        if aviRate
            % add/save current figure to movie
            try
                currFrame = getframe(gcf);
                writeVideo(vidObj,currFrame);
            catch
                lasterr
            end
        end
        if animate & (jj~=length(index))
            % multiple figures/animation: allow for pause between plot updates
            if pausev
                pause(pausev)
            end
            clf;
        end
    end
    
    % close avi-file
    if aviRate
        close(vidObj);
    end
    
    y.h = h; % figure handle
catch
    % plotting failed: providing error message
    le = lasterror;
    EventLog{end+1} = sprintf('Error: Plotting feeder:\n  %s\nFile: %s, Line: %.0f\n',le.message,le.stack(1).name,le.stack(1).line);
    if DispFlag
        fprintf('\n Error plotting feeder:\n  %s\n',le.message);
        fprintf('\n File: %s, Line: %.0f\n',le.stack(1).name,le.stack(1).line);
    end
end
y.EventLog = EventLog;
r.EventLog = EventLog;
if nout == 1
    varargout{1} = r;
end