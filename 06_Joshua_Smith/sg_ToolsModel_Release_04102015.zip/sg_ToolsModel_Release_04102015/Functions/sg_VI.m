function VI=sg_VI(t1,R,t2,GHI)

% Computes Variability Index
% function r = sg_hfVI(t,P)
%
% Computes Variability Index as defined by [1]
%
% Inputs:  t1     ... Time array for irradiance (s)
%          R      ... Irradiance (W/m^2)
%          t2     ... Time array for GHI
%          GHI    ... Global horizontal irradiance (W/m^2)
%
% Outputs: VI   ... Variability index.
%
% Examples(s):
%		VI = sg_I(t1,R,t2,GHI);
%
%  [1]  Joshua Stein, Clifford Hansen, and Matthew J Reno. The 
%       variability index: A new and novel metric for quantifying 
%       irradiance and PV output variability. Technical report, 
%       Sandia National Laboratories (SNL-NM), Albuquerque, NM 
%      (United States), 2012.
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

dt1=diff(t1/60);
dR=diff(R);
l1=sum(sqrt(dR.^2+dt1.^2));

dt2=diff(t2/60);
dGHI=diff(GHI);
l2=sum(sqrt(dGHI.^2+dt2.^2));

VI=l1/l2;