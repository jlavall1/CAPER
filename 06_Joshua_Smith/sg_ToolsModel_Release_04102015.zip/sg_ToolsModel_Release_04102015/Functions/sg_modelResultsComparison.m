function r = sg_modelResultsComparison(varargin)
% Result Comparison of two OpenDSS models.
% r = sg_modelResultsComparison(FullModel,ReducedModel)
% 
% Performs a comparison of results from two OpenDSS models (Model_A and
% Model_B) for which the model specified by Model_B is assumed
% to be similar to (or composed of a subset of buses) to Model_A. This situation 
% may apply to models used in parametric studies or model reduction.
% 
% Inputs: Model_A		... a string specifying the name of an OpenDSS model.
%		  Model_B ... a string specifying the name of an OpenDSS model which
%      						is assumed to be comparable to Model_A.
%    	  'DSSObj'		... OpenDSS COM interface connection 
%      						(default = '' indicating that a new connection 
%							should be created).    
%		  'plot'		... an integer specifying the number with which 
%							to begin numbering generated
%      	  'figures'		... (default = 0, indicating that plots should be suppressed).
%
% Outputs: r.  ... data (results) structure of information for comparison.
%                  (voltages/differences, Power losses/differences, Line
%                  losses/difference)
%
% Example Call(s):
%     r = sg_modelResultsComparison('FullPathToModel_A','FullPathToModel_B')
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under 
% Awards DE-EE0002063 and DE-EE0004682

%%
Model_A=varargin{1};
Model_B=varargin{2};

opts=struct('DSSObj','','plot',0);
opts=sg_updateOpts(opts,varargin,2);

[r1,DSSObj]=sg_runOpenDSSSim(Model_A,'DSSObj',opts.DSSObj);
DSSObj.Text.Command = 'clear';
r2=sg_runOpenDSSSim(Model_B,'DSSObj',DSSObj);

fontsize=14;
markersize=14;
lwd=2;

r=struct();  %  Structure of comparison quantities to be returned.
Nplot=opts.plot;  %  Next plot number.

%  Return voltage values deviations and summary statistics.
r.Voltage=struct();
i1=find(ismember(r1.Bus.Vpu.names,r2.Bus.Vpu.names));
i2=1:length(r2.Bus.Vpu.names);
r.Voltage.NodeNames=r1.Bus.Vpu.names(i1);
idx = zeros(length(i1),1);
for ii = 1:length(i1)
    idx(ii) = find(strcmp(r2.Bus.Vpu.names,r.Voltage.NodeNames{ii}));
end
r.Voltage.Val1=r1.Bus.Vpu.val(i1);
r.Voltage.Val2=r2.Bus.Vpu.val(idx);
r.Voltage.Deviation=r.Voltage.Val1-r.Voltage.Val2;
r.Voltage.Index1=i1;
r.Voltage.Index2=i2;

%% Bus distance check: reduced feeder buses should be at the same distance
Bidx = zeros(length(r2.Bus.Vpu.names),1);
for ii = 1:length(r2.Bus.Vpu.names)
    Bidx(ii) = find(strcmp(r2.Bus.Vpu.names{ii},r1.Bus.Vpu.names));
end
if(opts.plot>0)
    figure(Nplot+1);
    plot(r2.Bus.Vpu.distance/1.6,r1.Bus.Vpu.distance(Bidx)/1.6,'rx',...
        [0 max(r2.Bus.Vpu.distance)]/1.6,[0 max(r2.Bus.Vpu.distance)]/1.6,'b-');
    xlabel('distance (mi)')
    ylabel('distance (mi)')
    set(gcf,'name','distance comparison')
end

% node voltage plot (using markers): compare A vs. B
if(opts.plot>0)
    figure(Nplot);
    sg_plotStandard(r.Voltage.Index2,{r.Voltage.Val1,r.Voltage.Val2},...
        'new',0,'xlab','Node','ylab','Voltage (pu)','colorv','bx;rx',...
        'legendText','Full Model;Reduced Model','layout',0,...
        'fontsize',fontsize,'markersize',markersize,'lwd',lwd);
    Nplot=Nplot+1;
    set(gcf,'name','Node voltage comparison')
end

%  Return a value comparing system losses.
r.Sys=struct();
r.Sys.Ploss1=r1.sys.Losses(1);
r.Sys.Qloss1=r1.sys.Losses(2);
r.Sys.Ploss2=r2.sys.Losses(1);
r.Sys.Qloss2=r2.sys.Losses(2);

r.Sys.PlineLoss1=r1.sys.LineLosses(1);
r.Sys.QlineLoss1=r1.sys.LineLosses(2);
r.Sys.PlineLoss2=r2.sys.LineLosses(1);
r.Sys.QlineLoss2=r2.sys.LineLosses(2);

r.Sys.PlossDeviation=r.Sys.Ploss1-r.Sys.Ploss2;
r.Sys.QlossDeviation=r.Sys.Qloss1-r.Sys.Qloss2;

r.Sys.PlineLossDeviation=r.Sys.PlineLoss1-r.Sys.PlineLoss2;
r.Sys.QlineLossDeviation=r.Sys.QlineLoss1-r.Sys.QlineLoss2;
