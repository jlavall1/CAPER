function [DSSObj,varargout] = sg_startOpenDSS(varargin)
% Open connection to OpenDSS and configure settings for batch processing/studies.
% function DSSObj = sg_startOpenDSS()
%
% Inputs:  'DispFlag'  ... display flag (0/1), default: 1
%
% Florida State University
% Center for Advanced Power Systems
% Sunshine State Solar Grid Initiative (SUNGRIN)
% Developed with the support of U.S. Dept. of Energy under Awards DE-EE0002063 and DE-EE0004682
%
% October 30, 2014

EventLog = {};
DSSObj   = [];
DispFlag = 1;

for ii = 1:2:length(varargin)
    switch lower(varargin{ii})
        case {'dispflag'}
            DispFlag = varargin{ii+1};
    end
end

%% COM interface
try
    DSSObj = actxserver('OpenDSSEngine.DSS');
catch
    EventLog{end+1} = 'Error: Unable to connect to OpenDSS';
    if DispFlag
        fprintf('\n Unable to connect to OpenDSS.\n');
    end
    varargout{1} = EventLog;
    return
end
DSSStartOK = DSSObj.Start(0);
if ~DSSStartOK,
    EventLog{end+1} = 'Error: Unable to connect to OpenDSS';
    if DispFlag
        fprintf('\n Unable to connect to OpenDSS.\n');
    end
    varargout{1} = EventLog;
    return
end
EventLog{end+1} = 'Started OpenDSS Engine';
DSSObj.Reset();
DSSObj.AllowForms = 0;

%% Recent changes in OpenDSS (e.g., NodeOrder property): version warning
minStr = '7.6.3.22';
minNum = verStr2num(minStr);
verText = DSSObj.version;
verStr = regexp(verText,'(\d+([.]\d+)*)','tokens');
verStr = verStr{1}{:};
verNum = verStr2num(verStr);
EventLog{end+1} = sprintf('Found OpenDSS (version %s).',verStr);
if verNum < minNum 
    EventLog{end+1} = sprintf('Warning: Using older OpenDSS version (%s). Expecting %s and above.\n',verStr,minStr);
    if DispFlag
        fprintf('\n Warning: Using older OpenDSS version (%s). Expecting %s and above.\n',verStr,minStr);
    end
end
varargout{1} = EventLog;
return

function xNum = verStr2num(xStr)
% Helper function to convert version string to number
dig = 100; % each 'digit' limited to 0-99

idx = strfind(xStr,'.');
n = zeros(1,length(idx)+1);

if length(n) > 1
    n(1) = str2double(xStr(1:idx(1)));
else
    xNum = str2double(xStr);
    return
end

for ii = 2:length(idx)
    n(ii) = str2double(xStr(idx(ii-1)+1:idx(ii)-1)) / dig^(ii-1);
end
n(end) = str2double(xStr(idx(end)+1:end)) / dig^(length(n)-1);

xNum = sum(n);
return
